"use strict";
(self["webpackChunkng"] = self["webpackChunkng"] || []).push([["main"],{

/***/ 3966:
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppRoutingModule: () => (/* binding */ AppRoutingModule),
/* harmony export */   COMPLAINT_PAGE: () => (/* binding */ COMPLAINT_PAGE),
/* harmony export */   COMPLIMENT_PAGE: () => (/* binding */ COMPLIMENT_PAGE),
/* harmony export */   CONFIRMATION_PAGE: () => (/* binding */ CONFIRMATION_PAGE),
/* harmony export */   ENTRY_PAGE: () => (/* binding */ ENTRY_PAGE),
/* harmony export */   GENERAL_INFO_PAGE: () => (/* binding */ GENERAL_INFO_PAGE),
/* harmony export */   LANGUAGE_ENGLISH: () => (/* binding */ LANGUAGE_ENGLISH),
/* harmony export */   LANGUAGE_FRENCH: () => (/* binding */ LANGUAGE_FRENCH),
/* harmony export */   LANGUAGE_PARAMETER: () => (/* binding */ LANGUAGE_PARAMETER),
/* harmony export */   REVIEW_PAGE: () => (/* binding */ REVIEW_PAGE),
/* harmony export */   SUGGESTION_PAGE: () => (/* binding */ SUGGESTION_PAGE)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/router */ 7947);
/* harmony import */ var _components_complaint_complaint_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./components/complaint/complaint.component */ 845);
/* harmony import */ var _components_compliment_compliment_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./components/compliment/compliment.component */ 5605);
/* harmony import */ var _components_entry_entry_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./components/entry/entry.component */ 6882);
/* harmony import */ var _components_general_information_general_information_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/general-information/general-information.component */ 3133);
/* harmony import */ var _components_suggestion_suggestion_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/suggestion/suggestion.component */ 7617);
/* harmony import */ var _components_review_review_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./components/review/review.component */ 3806);
/* harmony import */ var _components_confirmation_confirmation_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./components/confirmation/confirmation.component */ 2603);
/* harmony import */ var _services_guards_general_info_grard_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./services/guards/general-info-grard.service */ 4055);
/* harmony import */ var _services_guards_compliment_grard_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./services/guards/compliment-grard.service */ 4638);
/* harmony import */ var _services_guards_suggetion_grard_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./services/guards/suggetion-grard.service */ 2577);
/* harmony import */ var _services_guards_complaint_grard_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./services/guards/complaint-grard.service */ 7036);
/* harmony import */ var _services_guards_review_grard_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./services/guards/review-grard.service */ 3830);
/* harmony import */ var _services_guards_confirmation_grard_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./services/guards/confirmation-grard.service */ 8521);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 1699);
















const LANGUAGE_PARAMETER = 'lang';
const LANGUAGE_ENGLISH = 'en';
const LANGUAGE_FRENCH = 'fr';
const ENTRY_PAGE = 'entry';
const GENERAL_INFO_PAGE = 'generalinfo';
const COMPLAINT_PAGE = 'complaint';
const SUGGESTION_PAGE = 'suggestion';
const COMPLIMENT_PAGE = 'compliment';
const REVIEW_PAGE = 'review';
const CONFIRMATION_PAGE = 'confirmation';
const routes = [{
  path: ENTRY_PAGE,
  component: _components_entry_entry_component__WEBPACK_IMPORTED_MODULE_2__.EntryComponent,
  pathMatch: 'full'
}, {
  path: ENTRY_PAGE + "/:lang",
  component: _components_entry_entry_component__WEBPACK_IMPORTED_MODULE_2__.EntryComponent,
  pathMatch: 'full'
}, {
  path: GENERAL_INFO_PAGE,
  component: _components_general_information_general_information_component__WEBPACK_IMPORTED_MODULE_3__.GeneralInformationComponent,
  pathMatch: 'full',
  canActivate: [_services_guards_general_info_grard_service__WEBPACK_IMPORTED_MODULE_7__.GeneralInfoGrardService]
}, {
  path: COMPLAINT_PAGE,
  component: _components_complaint_complaint_component__WEBPACK_IMPORTED_MODULE_0__.ComplaintComponent,
  pathMatch: 'full',
  canActivate: [_services_guards_complaint_grard_service__WEBPACK_IMPORTED_MODULE_10__.ComplaintGrardService]
}, {
  path: SUGGESTION_PAGE,
  component: _components_suggestion_suggestion_component__WEBPACK_IMPORTED_MODULE_4__.SuggestionComponent,
  pathMatch: 'full',
  canActivate: [_services_guards_suggetion_grard_service__WEBPACK_IMPORTED_MODULE_9__.SuggetionGrardService]
}, {
  path: COMPLIMENT_PAGE,
  component: _components_compliment_compliment_component__WEBPACK_IMPORTED_MODULE_1__.ComplimentComponent,
  pathMatch: 'full',
  canActivate: [_services_guards_compliment_grard_service__WEBPACK_IMPORTED_MODULE_8__.ComplimentGrardService]
}, {
  path: REVIEW_PAGE,
  component: _components_review_review_component__WEBPACK_IMPORTED_MODULE_5__.ReviewComponent,
  pathMatch: 'full',
  canActivate: [_services_guards_review_grard_service__WEBPACK_IMPORTED_MODULE_11__.ReviewGrardService]
}, {
  path: CONFIRMATION_PAGE,
  component: _components_confirmation_confirmation_component__WEBPACK_IMPORTED_MODULE_6__.ConfirmationComponent,
  pathMatch: 'full',
  canActivate: [_services_guards_confirmation_grard_service__WEBPACK_IMPORTED_MODULE_12__.ConfirmationGrardService]
}, {
  path: ':lang',
  component: _components_entry_entry_component__WEBPACK_IMPORTED_MODULE_2__.EntryComponent,
  pathMatch: 'full'
}, {
  path: '',
  redirectTo: ENTRY_PAGE,
  pathMatch: 'full'
}, {
  path: '**',
  redirectTo: ENTRY_PAGE
}];
class AppRoutingModule {}
AppRoutingModule.ɵfac = function AppRoutingModule_Factory(t) {
  return new (t || AppRoutingModule)();
};
AppRoutingModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdefineNgModule"]({
  type: AppRoutingModule
});
AppRoutingModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdefineInjector"]({
  imports: [_angular_router__WEBPACK_IMPORTED_MODULE_14__.RouterModule.forRoot(routes, {
    preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_14__.PreloadAllModules
  }), _angular_router__WEBPACK_IMPORTED_MODULE_14__.RouterModule]
});
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵsetNgModuleScope"](AppRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_14__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_14__.RouterModule]
  });
})();

/***/ }),

/***/ 6401:
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppComponent: () => (/* binding */ AppComponent),
/* harmony export */   ERROR_HEADER_ID: () => (/* binding */ ERROR_HEADER_ID),
/* harmony export */   FORM_ERROR_HEADER_ID: () => (/* binding */ FORM_ERROR_HEADER_ID)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ 7947);
/* harmony import */ var _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @cra-arc/rccr-wet */ 399);



const FORM_ERROR_HEADER_ID = 'formErrorHeader';
const ERROR_HEADER_ID = 'errorHeader';
class AppComponent {}
AppComponent.ɵfac = function AppComponent_Factory(t) {
  return new (t || AppComponent)();
};
AppComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
  type: AppComponent,
  selectors: [["app-root"]],
  decls: 5,
  vars: 0,
  consts: [["role", "main", "property", "mainContentOfPage", 1, "container"]],
  template: function AppComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "rccr-wet-template");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "rccr-breadcrumb");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "main", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "router-outlet");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "rccr-transact-footer");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    }
  },
  dependencies: [_angular_router__WEBPACK_IMPORTED_MODULE_1__.RouterOutlet, _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_2__.WetTemplateComponent, _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_2__.BreadcrumbComponent, _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_2__.TransactFooterComponent],
  encapsulation: 2
});

/***/ }),

/***/ 8629:
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppModule: () => (/* binding */ AppModule),
/* harmony export */   TranslateLoaderFactory: () => (/* binding */ TranslateLoaderFactory)
/* harmony export */ });
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! @angular/common/http */ 4860);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! @angular/platform-browser */ 6480);
/* harmony import */ var _cra_arc_rccr_core__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! @cra-arc/rccr-core */ 838);
/* harmony import */ var _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! @cra-arc/rccr-wet */ 399);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! @ngx-translate/core */ 5939);
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app-routing.module */ 3966);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app.component */ 6401);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! @angular/forms */ 8849);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/environments/environment */ 553);
/* harmony import */ var _components_entry_entry_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/entry/entry.component */ 6882);
/* harmony import */ var _components_templates_text_area_text_area_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/templates/text-area/text-area.component */ 3521);
/* harmony import */ var _components_templates_back_next_buttongroup_back_next_buttongroup_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./components/templates/back-next-buttongroup/back-next-buttongroup.component */ 672);
/* harmony import */ var _services_result_result_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./services/result/result.service */ 1392);
/* harmony import */ var _services_validation_validation_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./services/validation/validation.service */ 1109);
/* harmony import */ var _components_templates_text_input_local_text_input_local_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./components/templates/text-input-local/text-input-local.component */ 6453);
/* harmony import */ var _components_general_information_general_information_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./components/general-information/general-information.component */ 3133);
/* harmony import */ var _components_templates_select_local_select_local_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./components/templates/select-local/select-local.component */ 1434);
/* harmony import */ var _components_templates_radio_button_group_radio_button_group_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./components/templates/radio-button-group/radio-button-group.component */ 5396);
/* harmony import */ var _components_templates_page_heading_local_page_heading_local_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./components/templates/page-heading-local/page-heading-local.component */ 3641);
/* harmony import */ var _components_templates_need_help_need_help_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./components/templates/need-help/need-help.component */ 5386);
/* harmony import */ var _components_templates_page_details_local_page_details_local_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./components/templates/page-details-local/page-details-local.component */ 9704);
/* harmony import */ var _components_templates_placeholder_text_input_placeholder_text_input_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./components/templates/placeholder-text-input/placeholder-text-input.component */ 5401);
/* harmony import */ var _components_templates_multiselect_button_group_multiselect_button_group_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./components/templates/multiselect-button-group/multiselect-button-group.component */ 8564);
/* harmony import */ var _components_templates_expand_collapse_expand_collapse_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./components/templates/expand-collapse/expand-collapse.component */ 3779);
/* harmony import */ var _components_templates_edit_icon_edit_icon_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./components/templates/edit-icon/edit-icon.component */ 776);
/* harmony import */ var _components_templates_help_icon_help_icon_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./components/templates/help-icon/help-icon.component */ 791);
/* harmony import */ var _components_templates_print_save_icon_print_save_icon_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./components/templates/print-save-icon/print-save-icon.component */ 6297);
/* harmony import */ var _components_templates_return_summary_link_return_summary_link_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./components/templates/return-summary-link/return-summary-link.component */ 9015);
/* harmony import */ var _components_complaint_complaint_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./components/complaint/complaint.component */ 845);
/* harmony import */ var _components_suggestion_suggestion_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./components/suggestion/suggestion.component */ 7617);
/* harmony import */ var _components_compliment_compliment_component__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./components/compliment/compliment.component */ 5605);
/* harmony import */ var _components_review_review_component__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./components/review/review.component */ 3806);
/* harmony import */ var _components_templates_yes_no_buttongroup_yes_no_buttongroup_component__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./components/templates/yes-no-buttongroup/yes-no-buttongroup.component */ 4615);
/* harmony import */ var _components_templates_denotes_required_denotes_required_component__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./components/templates/denotes-required/denotes-required.component */ 1284);
/* harmony import */ var _components_confirmation_confirmation_component__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./components/confirmation/confirmation.component */ 2603);
/* harmony import */ var _components_templates_captcha_app_review_captcha_component__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ./components/templates/captcha/app-review-captcha.component */ 4831);
/* harmony import */ var _components_templates_captcha_app_review_captcha_directive__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./components/templates/captcha/app-review-captcha.directive */ 5286);
/* harmony import */ var _services_app_configuration_service__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! ./services/app-configuration.service */ 3148);









































function TranslateLoaderFactory(http) {
  return new _cra_arc_rccr_core__WEBPACK_IMPORTED_MODULE_32__.RccrTranslateLoader({
    i18nAssetDirectories: [src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.production ? '/ebci/uisp/rc193/assets/i18n/' : './assets/i18n/']
  }, http);
}
class AppModule {}
AppModule.ɵfac = function AppModule_Factory(t) {
  return new (t || AppModule)();
};
AppModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_33__["ɵɵdefineNgModule"]({
  type: AppModule,
  bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_1__.AppComponent]
});
AppModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_33__["ɵɵdefineInjector"]({
  providers: [_services_result_result_service__WEBPACK_IMPORTED_MODULE_6__.ResultService, _services_validation_validation_service__WEBPACK_IMPORTED_MODULE_7__.ValidationService, {
    provide: _cra_arc_rccr_core__WEBPACK_IMPORTED_MODULE_32__.LogServiceConfig,
    useValue: {
      remoteServiceUrl: '/ebci/uisp/rc193/rest/api/log'
    }
  }, {
    provide: _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_34__.WetTemplateConfig,
    useValue: {
      languageRouteParamName: 'lang'
    }
  }, _cra_arc_rccr_core__WEBPACK_IMPORTED_MODULE_32__.LogService, {
    provide: _angular_core__WEBPACK_IMPORTED_MODULE_33__.APP_INITIALIZER,
    useFactory: configService => function () {
      return configService.getConfiguration();
    },
    deps: [_services_app_configuration_service__WEBPACK_IMPORTED_MODULE_31__.AppConfigurationService],
    multi: true
  }, _cra_arc_rccr_core__WEBPACK_IMPORTED_MODULE_32__.httpInterceptorProviders],
  imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_35__.BrowserModule, _app_routing_module__WEBPACK_IMPORTED_MODULE_0__.AppRoutingModule, _cra_arc_rccr_core__WEBPACK_IMPORTED_MODULE_32__.RccrCoreModule, _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_34__.RccrWetModule, _angular_forms__WEBPACK_IMPORTED_MODULE_36__.ReactiveFormsModule, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_37__.TranslateModule.forRoot({
    loader: {
      provide: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_37__.TranslateLoader,
      useFactory: TranslateLoaderFactory,
      deps: [_angular_common_http__WEBPACK_IMPORTED_MODULE_38__.HttpClient]
    }
  })]
});
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_33__["ɵɵsetNgModuleScope"](AppModule, {
    declarations: [_app_component__WEBPACK_IMPORTED_MODULE_1__.AppComponent, _components_entry_entry_component__WEBPACK_IMPORTED_MODULE_3__.EntryComponent, _components_templates_text_area_text_area_component__WEBPACK_IMPORTED_MODULE_4__.TextAreaComponent, _components_templates_yes_no_buttongroup_yes_no_buttongroup_component__WEBPACK_IMPORTED_MODULE_26__.YesNoButtongroupComponent, _components_templates_back_next_buttongroup_back_next_buttongroup_component__WEBPACK_IMPORTED_MODULE_5__.BackNextButtongroupComponent, _components_templates_text_input_local_text_input_local_component__WEBPACK_IMPORTED_MODULE_8__.TextInputLocalComponent, _components_general_information_general_information_component__WEBPACK_IMPORTED_MODULE_9__.GeneralInformationComponent, _components_templates_select_local_select_local_component__WEBPACK_IMPORTED_MODULE_10__.SelectLocalComponent, _components_templates_radio_button_group_radio_button_group_component__WEBPACK_IMPORTED_MODULE_11__.RadioButtonGroupComponent, _components_templates_page_heading_local_page_heading_local_component__WEBPACK_IMPORTED_MODULE_12__.PageHeadingLocalComponent, _components_templates_need_help_need_help_component__WEBPACK_IMPORTED_MODULE_13__.NeedHelpComponent, _components_templates_page_details_local_page_details_local_component__WEBPACK_IMPORTED_MODULE_14__.PageDetailsLocalComponent, _components_templates_placeholder_text_input_placeholder_text_input_component__WEBPACK_IMPORTED_MODULE_15__.PlaceholderTextInputComponent, _components_templates_multiselect_button_group_multiselect_button_group_component__WEBPACK_IMPORTED_MODULE_16__.MultiselectButtonGroupComponent, _components_templates_expand_collapse_expand_collapse_component__WEBPACK_IMPORTED_MODULE_17__.ExpandCollapseComponent, _components_templates_edit_icon_edit_icon_component__WEBPACK_IMPORTED_MODULE_18__.EditIconComponent, _components_templates_help_icon_help_icon_component__WEBPACK_IMPORTED_MODULE_19__.HelpIconComponent, _components_templates_print_save_icon_print_save_icon_component__WEBPACK_IMPORTED_MODULE_20__.PrintSaveIconComponent, _components_templates_return_summary_link_return_summary_link_component__WEBPACK_IMPORTED_MODULE_21__.ReturnSummaryLinkComponent, _components_templates_denotes_required_denotes_required_component__WEBPACK_IMPORTED_MODULE_27__.DenotesRequiredComponent, _components_complaint_complaint_component__WEBPACK_IMPORTED_MODULE_22__.ComplaintComponent, _components_suggestion_suggestion_component__WEBPACK_IMPORTED_MODULE_23__.SuggestionComponent, _components_compliment_compliment_component__WEBPACK_IMPORTED_MODULE_24__.ComplimentComponent, _components_review_review_component__WEBPACK_IMPORTED_MODULE_25__.ReviewComponent, _components_confirmation_confirmation_component__WEBPACK_IMPORTED_MODULE_28__.ConfirmationComponent, _components_templates_captcha_app_review_captcha_component__WEBPACK_IMPORTED_MODULE_29__.AppReviewCaptchaComponent, _components_templates_captcha_app_review_captcha_directive__WEBPACK_IMPORTED_MODULE_30__.AppReviewCaptchaDirective],
    imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_35__.BrowserModule, _app_routing_module__WEBPACK_IMPORTED_MODULE_0__.AppRoutingModule, _cra_arc_rccr_core__WEBPACK_IMPORTED_MODULE_32__.RccrCoreModule, _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_34__.RccrWetModule, _angular_forms__WEBPACK_IMPORTED_MODULE_36__.ReactiveFormsModule, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_37__.TranslateModule]
  });
})();

/***/ }),

/***/ 6608:
/*!************************************!*\
  !*** ./src/app/components/base.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   BaseComponent: () => (/* binding */ BaseComponent)
/* harmony export */ });
class BaseComponent {
  constructor(translate, infoService, windowService, metaService) {
    this.translate = translate;
    this.infoService = infoService;
    this.windowService = windowService;
    this.metaService = metaService;
    this.currentLang = 'en';
    this.currentLang = translate.currentLang;
    translate.onLangChange.subscribe(lang => {
      this.currentLang = lang.lang;
    });
    this.window = this.windowService.getWindow();
    this.window.adobeDataLayer = this.window.adobeDataLayer || [];
  }
  dateParser(dateFr) {
    if (this.currentLang == 'en') {
      dateFr = false;
    } else if (this.currentLang == 'fr') {
      dateFr = true;
    }
    return dateFr;
  }
  parseNumStr(currencyStr) {
    let regexpNumber = /[ 0-9]/;
    if (currencyStr == '0.00' || currencyStr == '0,00' || currencyStr == '0' || currencyStr == '') {
      return '0';
    }
    let newCurrencyStr = '';
    if (this.currentLang == 'en') {
      for (let i = 0; i < currencyStr.length; i++) {
        if (currencyStr.charAt(i) != ',') {
          newCurrencyStr += currencyStr.charAt(i);
        }
      }
    } else if (this.currentLang == 'fr') {
      for (let i = 0; i < currencyStr.length; i++) {
        if (currencyStr.charAt(i) == ',') {
          newCurrencyStr += '.';
        } else if (!regexpNumber.test(currencyStr.charAt(i))) {
          continue;
        } else {
          newCurrencyStr += currencyStr.charAt(i);
        }
      }
    }
    return newCurrencyStr;
  }
  adobeDLPush(title) {
    //this.log.debug("adobeDLPush()");
    this.window.adobeDataLayer.push({
      "event": "pageLoad",
      "page": {
        "title": title,
        "language": this.getLangStr()
      }
    });
  }
  getLangStr() {
    return this.currentLang.toLocaleLowerCase().startsWith('fr') ? 'fra' : 'eng';
  }
  updateMeta(title) {
    //this.log.debug("updateMeta()");
    this.metaService.updateTag({
      name: 'dcterms.title',
      content: title
    });
    this.metaService.updateTag({
      name: 'dcterms.language',
      content: this.getLangStr()
    });
  }
}

/***/ }),

/***/ 845:
/*!*************************************************************!*\
  !*** ./src/app/components/complaint/complaint.component.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ComplaintComponent: () => (/* binding */ ComplaintComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/forms */ 8849);
/* harmony import */ var _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @cra-arc/rccr-wet */ 399);
/* harmony import */ var src_app_model_complaint__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/model/complaint */ 3437);
/* harmony import */ var src_app_app_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/app.component */ 6401);
/* harmony import */ var src_app_util_AppFormHelper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/util/AppFormHelper */ 5664);
/* harmony import */ var _base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../base */ 6608);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var src_app_services_result_result_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/result/result.service */ 1392);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/router */ 7947);
/* harmony import */ var src_app_services_validation_validation_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/validation/validation.service */ 1109);
/* harmony import */ var _cra_arc_rccr_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @cra-arc/rccr-core */ 838);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ngx-translate/core */ 5939);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/platform-browser */ 6480);
/* harmony import */ var _templates_back_next_buttongroup_back_next_buttongroup_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../templates/back-next-buttongroup/back-next-buttongroup.component */ 672);
/* harmony import */ var _templates_page_details_local_page_details_local_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../templates/page-details-local/page-details-local.component */ 9704);
/* harmony import */ var _templates_denotes_required_denotes_required_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../templates/denotes-required/denotes-required.component */ 1284);


















const _c0 = function (a0, a1) {
  return {
    stepNum: a0,
    stepTotal: a1
  };
};
const _c1 = function () {
  return {
    "rows": "10",
    "cols": "130",
    "maxLength": "10000"
  };
};
class ComplaintComponent extends _base__WEBPACK_IMPORTED_MODULE_3__.BaseComponent {
  constructor(infoService, router, validationService, focusService, translateService, windowService, metaService) {
    super(translateService, infoService, windowService, metaService);
    this.router = router;
    this.validationService = validationService;
    this.focusService = focusService;
    this.translateService = translateService;
    infoService.generalInfo.subscribe(resp => {
      this.getGeneralInfo = resp;
    });
    infoService.complaint.subscribe(resp => {
      this.complaint = resp;
    });
  }
  ngOnInit() {
    this.updateMeta(this.translateService.instant('complaint.details.title'));
    this.adobeDLPush(this.translateService.instant('complaint.details.title'));
    this.form = new _angular_forms__WEBPACK_IMPORTED_MODULE_9__.UntypedFormGroup({
      complaintFeedback: new _angular_forms__WEBPACK_IMPORTED_MODULE_9__.UntypedFormControl({
        value: this.complaint.complaintFeedback,
        disabled: false
      }, {
        validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.maxLength(10000), this.validationService.feedbackDetailValidator()],
        updateOn: 'change'
      })
    });
  }
  get complaintFeedback() {
    return this.form.get('complaintFeedback');
  }
  getStepTotal() {
    var stepTotal = this.getGeneralInfo.feedbackType.split(",").length + 2;
    return stepTotal;
  }
  getStepNum() {
    var stepNum = 1;
    return stepNum;
  }
  getProceed() {
    var CompOrSugg = "";
    if (this.getGeneralInfo?.feedbackType?.split(",").includes('suggestion')) {
      CompOrSugg = 'proceedSuggestion';
    } else if (this.getGeneralInfo?.feedbackType?.split(",").includes('compliment')) {
      CompOrSugg = 'proceedCompliment';
    } else {
      CompOrSugg = 'next';
    }
    return CompOrSugg;
  }
  previous() {
    this.infoService.entry.value.hasStart = true;
    return '/generalinfo';
  }
  submit() {
    src_app_util_AppFormHelper__WEBPACK_IMPORTED_MODULE_2__.AppFormHelper.trimInputField(this.complaintFeedback);
    src_app_util_AppFormHelper__WEBPACK_IMPORTED_MODULE_2__.AppFormHelper.convertApostropheAndTabField(this.complaintFeedback);
    if (this.form.invalid) {
      (0,_cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_10__.revealAllErrors)(this.form);
      this.focusService.requestFocus(src_app_app_component__WEBPACK_IMPORTED_MODULE_1__.ERROR_HEADER_ID);
    } else {
      this.infoService.complaint.next(this.buildCurrentComplaint());
      if (this.getGeneralInfo.feedbackType.split(",").includes('suggestion')) {
        this.infoService.suggestion.value.canActive = true;
        this.router.navigateByUrl('/suggestion');
      } else if (this.getGeneralInfo.feedbackType.split(",").includes('compliment')) {
        this.infoService.compliment.value.canActive = true;
        this.router.navigateByUrl('/compliment');
      } else {
        this.infoService.review.value.canActive = true;
        this.router.navigateByUrl('/review');
      }
    }
  }
  buildCurrentComplaint() {
    this.currentComplaint = new src_app_model_complaint__WEBPACK_IMPORTED_MODULE_0__.Complaint();
    this.currentComplaint.complaintFeedback = this.complaintFeedback.value;
    return this.currentComplaint;
  }
}
ComplaintComponent.ɵfac = function ComplaintComponent_Factory(t) {
  return new (t || ComplaintComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](src_app_services_result_result_service__WEBPACK_IMPORTED_MODULE_4__.ResultService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_12__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](src_app_services_validation_validation_service__WEBPACK_IMPORTED_MODULE_5__.ValidationService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_cra_arc_rccr_core__WEBPACK_IMPORTED_MODULE_13__.FocusService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_14__.TranslateService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_cra_arc_rccr_core__WEBPACK_IMPORTED_MODULE_13__.WindowService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_angular_platform_browser__WEBPACK_IMPORTED_MODULE_15__.Meta));
};
ComplaintComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdefineComponent"]({
  type: ComplaintComponent,
  selectors: [["app-complaint"]],
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵInheritDefinitionFeature"]],
  decls: 8,
  vars: 23,
  consts: [[3, "titleKey", "headingKey"], ["autocomplete", "off", 3, "formGroup", "ngSubmit"], [3, "form", "id"], ["ngDefaultControl", "", 3, "form", "formControlName", "labelKey", "required", "labelContainsMarkup", "attributes", "inlineHelpKey", "subtextKey"], [3, "back", "next"], [3, "screenId"]],
  template: function ComplaintComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](0, "rccr-page-heading", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](1, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](2, "form", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("ngSubmit", function ComplaintComponent_Template_form_ngSubmit_2_listener() {
        return ctx.submit();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](3, "rccr-error-aggregator", 2)(4, "denotes-required")(5, "rccr-textarea", 3)(6, "app-back-next-buttongroup", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](7, "app-page-details-local", 5);
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("titleKey", "complaint.details.title")("headingKey", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind2"](1, 16, "complaint.details.step", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction2"](19, _c0, ctx.getStepNum(), ctx.getStepTotal())));
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("formGroup", ctx.form);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("form", ctx.form)("id", "errorHeader");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("form", ctx.form)("formControlName", "complaintFeedback")("labelKey", "complaint.label")("required", true)("labelContainsMarkup", true)("attributes", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction0"](22, _c1))("inlineHelpKey", "entry.specChar")("subtextKey", "complaint.maxText");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("back", ctx.previous())("next", ctx.getProceed());
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("screenId", "UISP-RC193-COMPLAINT");
    }
  },
  dependencies: [_angular_forms__WEBPACK_IMPORTED_MODULE_9__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_9__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.RequiredValidator, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormControlName, _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_10__.PageHeadingComponent, _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_10__.ErrorAggregatorComponent, _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_10__.TextareaComponent, _templates_back_next_buttongroup_back_next_buttongroup_component__WEBPACK_IMPORTED_MODULE_6__.BackNextButtongroupComponent, _templates_page_details_local_page_details_local_component__WEBPACK_IMPORTED_MODULE_7__.PageDetailsLocalComponent, _templates_denotes_required_denotes_required_component__WEBPACK_IMPORTED_MODULE_8__.DenotesRequiredComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_14__.TranslatePipe],
  encapsulation: 2
});

/***/ }),

/***/ 5605:
/*!***************************************************************!*\
  !*** ./src/app/components/compliment/compliment.component.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ComplimentComponent: () => (/* binding */ ComplimentComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/forms */ 8849);
/* harmony import */ var _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @cra-arc/rccr-wet */ 399);
/* harmony import */ var src_app_model_compliment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/model/compliment */ 4597);
/* harmony import */ var src_app_app_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/app.component */ 6401);
/* harmony import */ var src_app_util_AppFormHelper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/util/AppFormHelper */ 5664);
/* harmony import */ var _base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../base */ 6608);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var src_app_services_result_result_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/result/result.service */ 1392);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/router */ 7947);
/* harmony import */ var src_app_services_validation_validation_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/validation/validation.service */ 1109);
/* harmony import */ var _cra_arc_rccr_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @cra-arc/rccr-core */ 838);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ngx-translate/core */ 5939);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/platform-browser */ 6480);
/* harmony import */ var _templates_back_next_buttongroup_back_next_buttongroup_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../templates/back-next-buttongroup/back-next-buttongroup.component */ 672);
/* harmony import */ var _templates_page_details_local_page_details_local_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../templates/page-details-local/page-details-local.component */ 9704);
/* harmony import */ var _templates_denotes_required_denotes_required_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../templates/denotes-required/denotes-required.component */ 1284);


















const _c0 = function (a0, a1) {
  return {
    stepNum: a0,
    stepTotal: a1
  };
};
const _c1 = function () {
  return {
    "rows": "10",
    "cols": "130",
    "maxLength": "10000"
  };
};
class ComplimentComponent extends _base__WEBPACK_IMPORTED_MODULE_3__.BaseComponent {
  constructor(infoService, router, validationService, focusService, translateService, windowService, metaService) {
    super(translateService, infoService, windowService, metaService);
    this.router = router;
    this.validationService = validationService;
    this.focusService = focusService;
    this.translateService = translateService;
    infoService.generalInfo.subscribe(resp => {
      this.getGeneralInfo = resp;
    });
    infoService.compliment.subscribe(resp => {
      this.compliment = resp;
    });
  }
  ngOnInit() {
    this.updateMeta(this.translateService.instant('compliment.details.title'));
    this.adobeDLPush(this.translateService.instant('compliment.details.title'));
    this.form = new _angular_forms__WEBPACK_IMPORTED_MODULE_9__.UntypedFormGroup({
      complimentFeedback: new _angular_forms__WEBPACK_IMPORTED_MODULE_9__.UntypedFormControl({
        value: this.compliment.complimentFeedback,
        disabled: false
      }, {
        validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.maxLength(10000), this.validationService.feedbackDetailValidator()],
        updateOn: 'change'
      })
    });
  }
  get complimentFeedback() {
    return this.form.get('complimentFeedback');
  }
  getStepTotal() {
    var stepTotal = this.getGeneralInfo.feedbackType.split(",").length + 2;
    return stepTotal;
  }
  getStepNum() {
    var stepNum = this.getGeneralInfo.feedbackType.split(",").indexOf('compliment') + 1;
    return stepNum;
  }
  previous() {
    if (this.getGeneralInfo.feedbackType?.split(",").includes('suggestion')) {
      this.infoService.suggestion.value.canActive = true;
      return '/suggestion';
    } else if (this.getGeneralInfo.feedbackType?.split(",").includes('complaint')) {
      this.infoService.complaint.value.canActive = true;
      return '/complaint';
    } else {
      this.infoService.entry.value.hasStart = true;
      return '/generalinfo';
    }
  }
  submit() {
    src_app_util_AppFormHelper__WEBPACK_IMPORTED_MODULE_2__.AppFormHelper.trimInputField(this.complimentFeedback);
    src_app_util_AppFormHelper__WEBPACK_IMPORTED_MODULE_2__.AppFormHelper.convertApostropheAndTabField(this.complimentFeedback);
    if (this.form.invalid) {
      (0,_cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_10__.revealAllErrors)(this.form);
      this.focusService.requestFocus(src_app_app_component__WEBPACK_IMPORTED_MODULE_1__.ERROR_HEADER_ID);
    } else {
      this.infoService.compliment.next(this.buildCurrentCompliment());
      this.infoService.review.value.canActive = true;
      this.router.navigateByUrl('/review');
    }
  }
  buildCurrentCompliment() {
    this.currentCompliment = new src_app_model_compliment__WEBPACK_IMPORTED_MODULE_0__.Compliment();
    this.currentCompliment.complimentFeedback = this.complimentFeedback.value;
    return this.currentCompliment;
  }
}
ComplimentComponent.ɵfac = function ComplimentComponent_Factory(t) {
  return new (t || ComplimentComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](src_app_services_result_result_service__WEBPACK_IMPORTED_MODULE_4__.ResultService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_12__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](src_app_services_validation_validation_service__WEBPACK_IMPORTED_MODULE_5__.ValidationService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_cra_arc_rccr_core__WEBPACK_IMPORTED_MODULE_13__.FocusService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_14__.TranslateService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_cra_arc_rccr_core__WEBPACK_IMPORTED_MODULE_13__.WindowService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_angular_platform_browser__WEBPACK_IMPORTED_MODULE_15__.Meta));
};
ComplimentComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdefineComponent"]({
  type: ComplimentComponent,
  selectors: [["app-compliment"]],
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵInheritDefinitionFeature"]],
  decls: 8,
  vars: 22,
  consts: [[3, "titleKey", "headingKey"], ["autocomplete", "off", 3, "formGroup", "ngSubmit"], [3, "form", "id"], ["ngDefaultControl", "", 3, "form", "formControlName", "labelKey", "required", "labelContainsMarkup", "attributes", "inlineHelpKey", "subtextKey"], [3, "back"], [3, "screenId"]],
  template: function ComplimentComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](0, "rccr-page-heading", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](1, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](2, "form", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("ngSubmit", function ComplimentComponent_Template_form_ngSubmit_2_listener() {
        return ctx.submit();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](3, "rccr-error-aggregator", 2)(4, "denotes-required")(5, "rccr-textarea", 3)(6, "app-back-next-buttongroup", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](7, "app-page-details-local", 5);
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("titleKey", "compliment.details.title")("headingKey", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind2"](1, 15, "compliment.details.step", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction2"](18, _c0, ctx.getStepNum(), ctx.getStepTotal())));
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("formGroup", ctx.form);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("form", ctx.form)("id", "errorHeader");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("form", ctx.form)("formControlName", "complimentFeedback")("labelKey", "compliment.label")("required", true)("labelContainsMarkup", true)("attributes", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction0"](21, _c1))("inlineHelpKey", "entry.specChar")("subtextKey", "complaint.maxText");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("back", ctx.previous());
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("screenId", "UISP-RC193-COMPLIMENT");
    }
  },
  dependencies: [_angular_forms__WEBPACK_IMPORTED_MODULE_9__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_9__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.RequiredValidator, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormControlName, _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_10__.PageHeadingComponent, _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_10__.ErrorAggregatorComponent, _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_10__.TextareaComponent, _templates_back_next_buttongroup_back_next_buttongroup_component__WEBPACK_IMPORTED_MODULE_6__.BackNextButtongroupComponent, _templates_page_details_local_page_details_local_component__WEBPACK_IMPORTED_MODULE_7__.PageDetailsLocalComponent, _templates_denotes_required_denotes_required_component__WEBPACK_IMPORTED_MODULE_8__.DenotesRequiredComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_14__.TranslatePipe],
  encapsulation: 2
});

/***/ }),

/***/ 2603:
/*!*******************************************************************!*\
  !*** ./src/app/components/confirmation/confirmation.component.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ConfirmationComponent: () => (/* binding */ ConfirmationComponent)
/* harmony export */ });
/* harmony import */ var src_app_model_review__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/model/review */ 2127);
/* harmony import */ var _base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../base */ 6608);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var src_app_services_result_result_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/result/result.service */ 1392);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ 5939);
/* harmony import */ var _cra_arc_rccr_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @cra-arc/rccr-core */ 838);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/platform-browser */ 6480);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ 6575);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/router */ 7947);
/* harmony import */ var _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @cra-arc/rccr-wet */ 399);
/* harmony import */ var _templates_page_details_local_page_details_local_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../templates/page-details-local/page-details-local.component */ 9704);
/* harmony import */ var _templates_print_save_icon_print_save_icon_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../templates/print-save-icon/print-save-icon.component */ 6297);












function ConfirmationComponent_div_25_dt_19_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, "genInfo.sin"));
  }
}
function ConfirmationComponent_div_25_dd_20_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r7.generalInfo.sin);
  }
}
function ConfirmationComponent_div_25_dt_21_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, "genInfo.otherAccntNum"));
  }
}
function ConfirmationComponent_div_25_dd_22_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r9.generalInfo.otherAccntNum);
  }
}
function ConfirmationComponent_div_25_dt_23_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, "genInfo.isCanada"));
  }
}
function ConfirmationComponent_div_25_dd_24_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, "genInfo.canada"));
  }
}
function ConfirmationComponent_div_25_dt_25_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, "genInfo.isCanada"));
  }
}
function ConfirmationComponent_div_25_dd_26_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"]("", ctx_r13.generalInfo.country, " ");
  }
}
function ConfirmationComponent_div_25_dt_37_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, "genInfo.province"));
  }
}
function ConfirmationComponent_div_25_dd_38_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, ctx_r15.generalInfo.province));
  }
}
function ConfirmationComponent_div_25_dt_39_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, "genInfo.postalCanada"));
  }
}
function ConfirmationComponent_div_25_dd_40_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r17.generalInfo.postalCode);
  }
}
function ConfirmationComponent_div_25_dt_41_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, "genInfo.postalOutsideCanada"), "");
  }
}
function ConfirmationComponent_div_25_dd_42_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r19.generalInfo.postalCode);
  }
}
function ConfirmationComponent_div_25_dt_48_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, "review.altPhone"));
  }
}
function ConfirmationComponent_div_25_dd_49_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r21.generalInfo.altPhone);
  }
}
function ConfirmationComponent_div_25_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 11)(1, "div", 12)(2, "div", 13)(3, "h2", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](5, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](6, "hr", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](7, "div", 16)(8, "dl", 17)(9, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](11, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](12, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](13);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](14, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](15);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](16, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](17, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](19, ConfirmationComponent_div_25_dt_19_Template, 3, 3, "dt", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](20, ConfirmationComponent_div_25_dd_20_Template, 2, 1, "dd", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](21, ConfirmationComponent_div_25_dt_21_Template, 3, 3, "dt", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](22, ConfirmationComponent_div_25_dd_22_Template, 2, 1, "dd", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](23, ConfirmationComponent_div_25_dt_23_Template, 3, 3, "dt", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](24, ConfirmationComponent_div_25_dd_24_Template, 3, 3, "dd", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](25, ConfirmationComponent_div_25_dt_25_Template, 3, 3, "dt", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](26, ConfirmationComponent_div_25_dd_26_Template, 2, 1, "dd", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](27, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](28);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](29, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](30, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](31);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](32, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](33);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](34, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](35, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](36);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](37, ConfirmationComponent_div_25_dt_37_Template, 3, 3, "dt", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](38, ConfirmationComponent_div_25_dd_38_Template, 3, 3, "dd", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](39, ConfirmationComponent_div_25_dt_39_Template, 3, 3, "dt", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](40, ConfirmationComponent_div_25_dd_40_Template, 2, 1, "dd", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](41, ConfirmationComponent_div_25_dt_41_Template, 3, 3, "dt", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](42, ConfirmationComponent_div_25_dd_42_Template, 2, 1, "dd", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](43, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](44);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](45, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](46, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](47);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](48, ConfirmationComponent_div_25_dt_48_Template, 3, 3, "dt", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](49, ConfirmationComponent_div_25_dd_49_Template, 2, 1, "dd", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](5, 27, "genInfo.IndividualInfo"));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](11, 29, "genInfo.firstName"));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r0.generalInfo.firstName);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](16, 31, "genInfo.lastName"));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r0.generalInfo.lastName);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r0.generalInfo.sin);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r0.generalInfo.sin);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r0.generalInfo.otherAccntNum);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r0.generalInfo.otherAccntNum);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r0.generalInfo.isCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r0.generalInfo.isCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r0.generalInfo.isCanada === "genInfo.outsideCanada");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r0.generalInfo.isCanada === "genInfo.outsideCanada");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](29, 33, "genInfo.mailingAddress"));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r0.generalInfo.mailingAddress);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](34, 35, "genInfo.city"));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r0.generalInfo.city);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r0.generalInfo.isCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r0.generalInfo.isCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r0.generalInfo.isCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r0.generalInfo.isCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r0.generalInfo.isCanada === "genInfo.outsideCanada");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r0.generalInfo.isCanada === "genInfo.outsideCanada");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](45, 37, "review.phone"));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r0.generalInfo.mainPhone);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r0.generalInfo.altPhone);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r0.generalInfo.altPhone);
  }
}
function ConfirmationComponent_div_26_dt_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, "genInfo.firstName"));
  }
}
function ConfirmationComponent_div_26_dd_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r23 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r23.generalInfo.firstName);
  }
}
function ConfirmationComponent_div_26_dt_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, "genInfo.lastName"));
  }
}
function ConfirmationComponent_div_26_dd_12_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r25 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r25.generalInfo.lastName);
  }
}
function ConfirmationComponent_div_26_dt_23_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, "genInfo.isCanada"));
  }
}
function ConfirmationComponent_div_26_dd_24_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, "genInfo.canada"));
  }
}
function ConfirmationComponent_div_26_dt_25_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, "genInfo.isCanada"));
  }
}
function ConfirmationComponent_div_26_dd_26_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r29 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"]("", ctx_r29.generalInfo.country, " ");
  }
}
function ConfirmationComponent_div_26_dt_37_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, "genInfo.province"));
  }
}
function ConfirmationComponent_div_26_dd_38_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r31 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, ctx_r31.generalInfo.province));
  }
}
function ConfirmationComponent_div_26_dt_39_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, "genInfo.postalCanada"));
  }
}
function ConfirmationComponent_div_26_dd_40_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r33 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r33.generalInfo.postalCode);
  }
}
function ConfirmationComponent_div_26_dt_41_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, "genInfo.postalOutsideCanada"), "");
  }
}
function ConfirmationComponent_div_26_dd_42_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r35 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r35.generalInfo.postalCode);
  }
}
function ConfirmationComponent_div_26_dt_48_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, "review.altPhone"));
  }
}
function ConfirmationComponent_div_26_dd_49_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r37 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r37.generalInfo.altPhone);
  }
}
function ConfirmationComponent_div_26_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 11)(1, "div", 12)(2, "div", 13)(3, "h2", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](5, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](6, "hr", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](7, "div", 16)(8, "dl", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](9, ConfirmationComponent_div_26_dt_9_Template, 3, 3, "dt", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](10, ConfirmationComponent_div_26_dd_10_Template, 2, 1, "dd", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](11, ConfirmationComponent_div_26_dt_11_Template, 3, 3, "dt", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](12, ConfirmationComponent_div_26_dd_12_Template, 2, 1, "dd", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](13, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](14);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](15, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](16, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](17);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](18, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](19);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](20, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](21, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](22);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](23, ConfirmationComponent_div_26_dt_23_Template, 3, 3, "dt", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](24, ConfirmationComponent_div_26_dd_24_Template, 3, 3, "dd", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](25, ConfirmationComponent_div_26_dt_25_Template, 3, 3, "dt", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](26, ConfirmationComponent_div_26_dd_26_Template, 2, 1, "dd", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](27, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](28);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](29, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](30, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](31);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](32, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](33);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](34, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](35, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](36);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](37, ConfirmationComponent_div_26_dt_37_Template, 3, 3, "dt", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](38, ConfirmationComponent_div_26_dd_38_Template, 3, 3, "dd", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](39, ConfirmationComponent_div_26_dt_39_Template, 3, 3, "dt", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](40, ConfirmationComponent_div_26_dd_40_Template, 2, 1, "dd", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](41, ConfirmationComponent_div_26_dt_41_Template, 3, 3, "dt", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](42, ConfirmationComponent_div_26_dd_42_Template, 2, 1, "dd", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](43, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](44);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](45, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](46, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](47);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](48, ConfirmationComponent_div_26_dt_48_Template, 3, 3, "dt", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](49, ConfirmationComponent_div_26_dd_49_Template, 2, 1, "dd", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](5, 27, "genInfo.BusinessInfo"));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r1.generalInfo.firstName);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r1.generalInfo.firstName);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r1.generalInfo.lastName);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r1.generalInfo.lastName);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](15, 29, "genInfo.businessName"));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r1.generalInfo.businessName);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](20, 31, "genInfo.businessNum"));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r1.generalInfo.businessNum);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r1.generalInfo.isCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r1.generalInfo.isCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r1.generalInfo.isCanada === "genInfo.outsideCanada");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r1.generalInfo.isCanada === "genInfo.outsideCanada");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](29, 33, "genInfo.mailingAddress"));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r1.generalInfo.mailingAddress);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](34, 35, "genInfo.city"));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r1.generalInfo.city);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r1.generalInfo.isCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r1.generalInfo.isCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r1.generalInfo.isCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r1.generalInfo.isCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r1.generalInfo.isCanada === "genInfo.outsideCanada");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r1.generalInfo.isCanada === "genInfo.outsideCanada");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](45, 37, "review.phone"));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r1.generalInfo.mainPhone);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r1.generalInfo.altPhone);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r1.generalInfo.altPhone);
  }
}
function ConfirmationComponent_div_27_dt_12_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, "genInfo.firstName"));
  }
}
function ConfirmationComponent_div_27_dd_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r39 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r39.generalInfo.firstName);
  }
}
function ConfirmationComponent_div_27_dt_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, "genInfo.lastName"));
  }
}
function ConfirmationComponent_div_27_dd_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r41 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r41.generalInfo.lastName);
  }
}
function ConfirmationComponent_div_27_dt_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, "genInfo.businessName"));
  }
}
function ConfirmationComponent_div_27_dd_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r43 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r43.generalInfo.businessName);
  }
}
function ConfirmationComponent_div_27_dt_18_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, "genInfo.businessNum"));
  }
}
function ConfirmationComponent_div_27_dd_19_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r45 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r45.generalInfo.businessNum);
  }
}
function ConfirmationComponent_div_27_dt_20_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, "genInfo.sin"));
  }
}
function ConfirmationComponent_div_27_dd_21_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r47 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r47.generalInfo.sin);
  }
}
function ConfirmationComponent_div_27_dt_22_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, "genInfo.otherAccntNum"));
  }
}
function ConfirmationComponent_div_27_dd_23_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r49 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r49.generalInfo.otherAccntNum);
  }
}
function ConfirmationComponent_div_27_dt_24_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, "genInfo.isCanada"));
  }
}
function ConfirmationComponent_div_27_dd_25_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, "genInfo.canada"));
  }
}
function ConfirmationComponent_div_27_dt_26_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, "genInfo.isCanada"));
  }
}
function ConfirmationComponent_div_27_dd_27_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r53 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"]("", ctx_r53.generalInfo.country, " ");
  }
}
function ConfirmationComponent_div_27_dt_38_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, "genInfo.province"));
  }
}
function ConfirmationComponent_div_27_dd_39_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r55 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, ctx_r55.generalInfo.province));
  }
}
function ConfirmationComponent_div_27_dt_40_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, "genInfo.postalCanada"));
  }
}
function ConfirmationComponent_div_27_dd_41_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r57 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r57.generalInfo.postalCode);
  }
}
function ConfirmationComponent_div_27_dt_42_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, "genInfo.postalOutsideCanada"), "");
  }
}
function ConfirmationComponent_div_27_dd_43_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r59 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r59.generalInfo.postalCode);
  }
}
function ConfirmationComponent_div_27_dt_49_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, "review.altPhone"));
  }
}
function ConfirmationComponent_div_27_dd_50_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r61 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r61.generalInfo.altPhone);
  }
}
function ConfirmationComponent_div_27_dt_66_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, "genInfo.businessName"));
  }
}
function ConfirmationComponent_div_27_dd_67_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r63 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r63.generalInfo.repBusinessName);
  }
}
function ConfirmationComponent_div_27_dt_68_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, "genInfo.businessNum"));
  }
}
function ConfirmationComponent_div_27_dd_69_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r65 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r65.generalInfo.repBusinessNum);
  }
}
function ConfirmationComponent_div_27_dt_70_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, "genInfo.repNum"));
  }
}
function ConfirmationComponent_div_27_dd_71_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r67 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r67.generalInfo.repNum);
  }
}
function ConfirmationComponent_div_27_dt_72_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, "genInfo.isCanada"));
  }
}
function ConfirmationComponent_div_27_dd_73_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, "genInfo.canada"));
  }
}
function ConfirmationComponent_div_27_dt_74_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, "genInfo.isCanada"), " ");
  }
}
function ConfirmationComponent_div_27_dd_75_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r71 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", ctx_r71.generalInfo.repCountry, "");
  }
}
function ConfirmationComponent_div_27_dt_86_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, "genInfo.province"));
  }
}
function ConfirmationComponent_div_27_dd_87_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r73 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, ctx_r73.generalInfo.repProvince), " ");
  }
}
function ConfirmationComponent_div_27_dt_88_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, "genInfo.postalCanada"));
  }
}
function ConfirmationComponent_div_27_dd_89_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r75 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r75.generalInfo.repPostalCode);
  }
}
function ConfirmationComponent_div_27_dt_90_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, "genInfo.postalOutsideCanada"), "");
  }
}
function ConfirmationComponent_div_27_dd_91_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r77 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r77.generalInfo.repPostalCode);
  }
}
function ConfirmationComponent_div_27_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 11)(1, "div", 12)(2, "div", 13)(3, "h2", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](5, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](6, "hr", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](7, "div", 16)(8, "h3", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](10, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](11, "dl", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](12, ConfirmationComponent_div_27_dt_12_Template, 3, 3, "dt", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](13, ConfirmationComponent_div_27_dd_13_Template, 2, 1, "dd", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](14, ConfirmationComponent_div_27_dt_14_Template, 3, 3, "dt", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](15, ConfirmationComponent_div_27_dd_15_Template, 2, 1, "dd", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](16, ConfirmationComponent_div_27_dt_16_Template, 3, 3, "dt", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](17, ConfirmationComponent_div_27_dd_17_Template, 2, 1, "dd", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](18, ConfirmationComponent_div_27_dt_18_Template, 3, 3, "dt", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](19, ConfirmationComponent_div_27_dd_19_Template, 2, 1, "dd", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](20, ConfirmationComponent_div_27_dt_20_Template, 3, 3, "dt", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](21, ConfirmationComponent_div_27_dd_21_Template, 2, 1, "dd", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](22, ConfirmationComponent_div_27_dt_22_Template, 3, 3, "dt", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](23, ConfirmationComponent_div_27_dd_23_Template, 2, 1, "dd", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](24, ConfirmationComponent_div_27_dt_24_Template, 3, 3, "dt", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](25, ConfirmationComponent_div_27_dd_25_Template, 3, 3, "dd", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](26, ConfirmationComponent_div_27_dt_26_Template, 3, 3, "dt", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](27, ConfirmationComponent_div_27_dd_27_Template, 2, 1, "dd", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](28, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](29);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](30, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](31, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](32);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](33, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](34);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](35, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](36, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](37);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](38, ConfirmationComponent_div_27_dt_38_Template, 3, 3, "dt", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](39, ConfirmationComponent_div_27_dd_39_Template, 3, 3, "dd", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](40, ConfirmationComponent_div_27_dt_40_Template, 3, 3, "dt", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](41, ConfirmationComponent_div_27_dd_41_Template, 2, 1, "dd", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](42, ConfirmationComponent_div_27_dt_42_Template, 3, 3, "dt", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](43, ConfirmationComponent_div_27_dd_43_Template, 2, 1, "dd", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](44, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](45);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](46, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](47, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](48);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](49, ConfirmationComponent_div_27_dt_49_Template, 3, 3, "dt", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](50, ConfirmationComponent_div_27_dd_50_Template, 2, 1, "dd", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](51, "hr", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](52, "h3", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](53);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](54, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](55, "dl", 17)(56, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](57);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](58, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](59, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](60);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](61, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](62);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](63, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](64, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](65);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](66, ConfirmationComponent_div_27_dt_66_Template, 3, 3, "dt", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](67, ConfirmationComponent_div_27_dd_67_Template, 2, 1, "dd", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](68, ConfirmationComponent_div_27_dt_68_Template, 3, 3, "dt", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](69, ConfirmationComponent_div_27_dd_69_Template, 2, 1, "dd", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](70, ConfirmationComponent_div_27_dt_70_Template, 3, 3, "dt", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](71, ConfirmationComponent_div_27_dd_71_Template, 2, 1, "dd", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](72, ConfirmationComponent_div_27_dt_72_Template, 3, 3, "dt", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](73, ConfirmationComponent_div_27_dd_73_Template, 3, 3, "dd", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](74, ConfirmationComponent_div_27_dt_74_Template, 3, 3, "dt", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](75, ConfirmationComponent_div_27_dd_75_Template, 2, 1, "dd", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](76, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](77);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](78, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](79, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](80);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](81, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](82);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](83, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](84, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](85);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](86, ConfirmationComponent_div_27_dt_86_Template, 3, 3, "dt", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](87, ConfirmationComponent_div_27_dd_87_Template, 3, 3, "dd", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](88, ConfirmationComponent_div_27_dt_88_Template, 3, 3, "dt", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](89, ConfirmationComponent_div_27_dd_89_Template, 2, 1, "dd", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](90, ConfirmationComponent_div_27_dt_90_Template, 3, 3, "dt", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](91, ConfirmationComponent_div_27_dd_91_Template, 2, 1, "dd", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](92, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](93);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](94, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](95, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](96);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](5, 59, "review.rep.info"));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](10, 61, "genInfo.clientInfo"));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.firstName);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.firstName);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.lastName);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.lastName);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.businessName);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.businessName);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.businessNum);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.businessNum);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.sin);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.sin);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.otherAccntNum);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.otherAccntNum);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.isCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.isCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.isCanada === "genInfo.outsideCanada");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.isCanada === "genInfo.outsideCanada");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](30, 63, "genInfo.mailingAddress"));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r2.generalInfo.mailingAddress);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](35, 65, "genInfo.city"));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r2.generalInfo.city);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.isCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.isCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.isCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.isCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.isCanada === "genInfo.outsideCanada");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.isCanada === "genInfo.outsideCanada");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](46, 67, "review.phone"));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r2.generalInfo.mainPhone);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.altPhone);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.altPhone);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](54, 69, "review.rep.subtitleB"));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](58, 71, "genInfo.firstName"));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r2.generalInfo.repFirstName);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](63, 73, "genInfo.lastName"));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r2.generalInfo.repLastName);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.repBusinessName);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.repBusinessName);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.repBusinessNum);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.repBusinessNum);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.repNum);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.repNum);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.repIsCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.repIsCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.repIsCanada === "genInfo.outsideCanada");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.repIsCanada === "genInfo.outsideCanada");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](78, 75, "genInfo.mailingAddress"));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r2.generalInfo.repMailingAddress);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](83, 77, "genInfo.city"));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r2.generalInfo.repCity);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.repIsCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.repIsCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.repIsCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.repIsCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.repIsCanada === "genInfo.outsideCanada");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.repIsCanada === "genInfo.outsideCanada");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](94, 79, "review.phone"));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r2.generalInfo.repMainPhone);
  }
}
function ConfirmationComponent_div_32_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 11)(1, "div", 12)(2, "div", 13)(3, "h3", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](5, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](6, "hr", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](7, "p", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](5, 2, "review.complaint"));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r3.complaint.complaintFeedback);
  }
}
function ConfirmationComponent_div_33_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 11)(1, "div", 12)(2, "div", 13)(3, "h3", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](5, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](6, "hr", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](7, "p", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](5, 2, "review.suggestion"));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r4.suggestion.suggestionFeedback);
  }
}
function ConfirmationComponent_div_34_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 11)(1, "div", 12)(2, "div", 13)(3, "h3", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](5, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](6, "hr", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](7, "p", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](5, 2, "review.compliment"));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](ctx_r5.compliment.complimentFeedback);
  }
}
const _c0 = function (a0) {
  return {
    stepTotal: a0
  };
};
class ConfirmationComponent extends _base__WEBPACK_IMPORTED_MODULE_1__.BaseComponent {
  constructor(infoService, translateService, windowService, metaService) {
    super(translateService, infoService, windowService, metaService);
    this.translateService = translateService;
    infoService.generalInfo.subscribe(resp => {
      this.generalInfo = resp;
    });
    infoService.complaint.subscribe(resp => {
      this.complaint = resp;
    });
    infoService.suggestion.subscribe(resp => {
      this.suggestion = resp;
    });
    infoService.compliment.subscribe(resp => {
      this.compliment = resp;
    });
    infoService.review.subscribe(resp => {
      this.review = resp;
    });
  }
  ngOnInit() {
    this.updateMeta(this.translateService.instant('confirmation.details.title'));
    this.adobeDLPush(this.translateService.instant('confirmation.details.title'));
    // Reset Captcha
    this.review.captchaToken = undefined;
    this.infoService.review.next(this.review);
  }
  getStepTotal() {
    var stepTotal = this.generalInfo.feedbackType?.split(",").length + 2;
    return stepTotal;
  }
  enableComplaint() {
    if (this.generalInfo.feedbackType != null && this.generalInfo.feedbackType?.split(",").includes('complaint')) {
      return true;
    }
    return false;
  }
  enableSuggestion() {
    if (this.generalInfo.feedbackType != null && this.generalInfo.feedbackType?.split(",").includes('suggestion')) {
      return true;
    }
    return false;
  }
  enableCompliment() {
    if (this.generalInfo.feedbackType != null && this.generalInfo.feedbackType?.split(",").includes('compliment')) {
      return true;
    }
    return false;
  }
  enablePersonal() {
    if (this.generalInfo.onBehalf != null && this.generalInfo.onBehalf?.includes('myself')) {
      return true;
    }
    return false;
  }
  enableBusiness() {
    if (this.generalInfo.onBehalf != null && this.generalInfo.onBehalf?.includes('business')) {
      return true;
    }
    return false;
  }
  enableRep() {
    if (this.generalInfo.onBehalf != null && this.generalInfo.onBehalf?.includes('representative')) {
      return true;
    }
    return false;
  }
  enableProvince() {
    if (this.generalInfo.isCanada?.includes('genInfo.canada')) {
      return true;
    }
    return false;
  }
  enableCountry() {
    if (this.generalInfo.isCanada?.includes('genInfo.outsideCanada')) {
      return true;
    }
    return false;
  }
  resetForm() {
    this.infoService.review.next(new src_app_model_review__WEBPACK_IMPORTED_MODULE_0__.Review());
    return this.infoService.reset();
  }
}
ConfirmationComponent.ɵfac = function ConfirmationComponent_Factory(t) {
  return new (t || ConfirmationComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_services_result_result_service__WEBPACK_IMPORTED_MODULE_2__.ResultService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslateService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_cra_arc_rccr_core__WEBPACK_IMPORTED_MODULE_7__.WindowService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_platform_browser__WEBPACK_IMPORTED_MODULE_8__.Meta));
};
ConfirmationComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
  type: ConfirmationComponent,
  selectors: [["app-confirmation"]],
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵInheritDefinitionFeature"]],
  decls: 46,
  vars: 46,
  consts: [[3, "titleKey", "headingKey"], [1, "alert", "alert-success"], [1, "mrgn-lft-lg"], ["class", "mrgn-tp-lg well well-secondary", 4, "ngIf"], [1, "mrgn-tp-lg", "hidden-print"], ["rel", "noopener noreferrer", 3, "href"], ["onclick", "resetForm()", 1, "btn", "btn-default"], [1, "mrgn-tp-md", "hidden-print"], ["rel", "noopener noreferrer", 3, "routerLink", "click"], [3, "innerHTML"], [3, "screenId"], [1, "mrgn-tp-lg", "well", "well-secondary"], [1, "row", "nav"], [1, "col-sm-10", "col-xs-7"], [1, "h3", "mrgn-tp-0", "mrgn-bttm-0"], [1, "solid-line"], [1, "mrgn-lft-md", "mrgn-tp-lg"], [1, "dl-horizontal", "brdr-0", "dl-col-5", "nopadding"], [4, "ngIf"], [1, "mrgn-bttm"], [1, "mrgn-tp-0", "mrgn-bttm-0"], [1, "wordWrap"]],
  template: function ConfirmationComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](0, "rccr-page-heading", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](1, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](2, "app-print-save-icon");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](3, "section", 1)(4, "h2")(5, "strong");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](7, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](8, "p", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](9);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](10, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](11, "p", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](12);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](13, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](14, "strong");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](15);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](16, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](17);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](18, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](19, "p", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](20);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](21, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](22, "strong");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](23);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](24, "div");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](25, ConfirmationComponent_div_25_Template, 50, 39, "div", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](26, ConfirmationComponent_div_26_Template, 50, 39, "div", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](27, ConfirmationComponent_div_27_Template, 97, 81, "div", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](28, "h2");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](29);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](30, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](31, "div");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](32, ConfirmationComponent_div_32_Template, 9, 4, "div", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](33, ConfirmationComponent_div_33_Template, 9, 4, "div", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](34, ConfirmationComponent_div_34_Template, 9, 4, "div", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](35, "div", 4)(36, "a", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](37, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](38, "button", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](39);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](40, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](41, "div", 7)(42, "a", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function ConfirmationComponent_Template_a_click_42_listener() {
        return ctx.resetForm();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](43, "span", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](44, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](45, "app-page-details-local", 10);
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("titleKey", "confirmation.details.title")("headingKey", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind2"](1, 21, "confirmation.details.step", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction1"](44, _c0, ctx.getStepTotal())));
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](7, 24, "confirmation.info.1"), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](10, 26, "confirmation.info.2"), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](13, 28, "confirmation.info.3.a"), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](16, 30, "confirmation.info.3.b"), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](18, 32, "confirmation.info.3.c"), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](21, 34, "confirmation.info.4"), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", ctx.review.confirmationNumber, " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.enablePersonal());
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.enableBusiness());
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.enableRep());
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](30, 36, "review.feedback.label"));
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.enableComplaint());
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.enableSuggestion());
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.enableCompliment());
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpropertyInterpolate"]("href", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](37, 38, "submit.exit.link"), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵsanitizeUrl"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](40, 40, "submit.exit.label"));
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("routerLink", "/entry");
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("innerHTML", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](44, 42, "submit.another.form"), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵsanitizeHtml"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("screenId", "UISP-RC193-CONFIRMATION");
    }
  },
  dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_9__.NgIf, _angular_router__WEBPACK_IMPORTED_MODULE_10__.RouterLink, _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_11__.PageHeadingComponent, _templates_page_details_local_page_details_local_component__WEBPACK_IMPORTED_MODULE_3__.PageDetailsLocalComponent, _templates_print_save_icon_print_save_icon_component__WEBPACK_IMPORTED_MODULE_4__.PrintSaveIconComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslatePipe],
  styles: ["nav[_ngcontent-%COMP%]{\n    display:inline !important;\n}\n.glyphicon[_ngcontent-%COMP%]{\n    display: inline !important;\n}\n.solid-line[_ngcontent-%COMP%]{\n    border-top: solid 1px;\n    border-top-color: slategray;\n}\ndt[_ngcontent-%COMP%]{\n    font-weight: 600;\n}\ndd[_ngcontent-%COMP%], .wordWrap[_ngcontent-%COMP%]{\n    word-wrap: break-word;\n    white-space: pre-line;\n}\n.mrgn-bttm[_ngcontent-%COMP%]{\n    margin-bottom: 20px;\n}\n\n\n\n@media all and (min-width:768px) {\n    \n\n        .dl-col-4[_ngcontent-%COMP%], .dl-col-5[_ngcontent-%COMP%], .dl-col-6[_ngcontent-%COMP%], .dl-col-7[_ngcontent-%COMP%], .dl-col-8[_ngcontent-%COMP%], .dl-col-9[_ngcontent-%COMP%], .dl-col-10[_ngcontent-%COMP%] {\n            width:100%;\n            margin-top:15px;\n        }\n    \n\n        .nopadding[_ngcontent-%COMP%]   dd[_ngcontent-%COMP%], .nopadding[_ngcontent-%COMP%]   dt[_ngcontent-%COMP%]\n        {\n            padding-bottom:0px;\n            padding-top:0px;\n        }\n    \n\n        .dl-col-4[_ngcontent-%COMP%]    > dt[_ngcontent-%COMP%] {\n            width: 33.3333333333%;\n        }\n        .dl-col-5[_ngcontent-%COMP%]    > dt[_ngcontent-%COMP%]{\n            width: 41.6666666667%;\n        }\n        .dl-col-6[_ngcontent-%COMP%]    > dt[_ngcontent-%COMP%] {\n            width: 50%;\n        }\n        .dl-col-7[_ngcontent-%COMP%]    > dt[_ngcontent-%COMP%] {\n            width: 58.3333333333%;\n        }\n        .dl-col-8[_ngcontent-%COMP%]    > dt[_ngcontent-%COMP%] {\n            width: 66.6666666667%;\n        }\n        .dl-col-9[_ngcontent-%COMP%]    > dt[_ngcontent-%COMP%] {\n            width: 75%;\n        }\n        .dl-col-10[_ngcontent-%COMP%]    > dt[_ngcontent-%COMP%] {\n            width: 83.3333333333%;\n        }\n        .dl-horizontal[_ngcontent-%COMP%]   dt.dt-bttm-0[_ngcontent-%COMP%] {\n            margin-bottom: 0;\n        }\n        .dl-horizontal[_ngcontent-%COMP%]   dd[_ngcontent-%COMP%] {\n            margin-left: 600px;\n        }\n}\n.dl-horizontal[_ngcontent-%COMP%]   dd.dd-bttm-0[_ngcontent-%COMP%] {\n    margin-bottom: 0;\n}\n\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29tcG9uZW50cy9jb25maXJtYXRpb24vY29uZmlybWF0aW9uLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSx5QkFBeUI7QUFDN0I7QUFDQTtJQUNJLDBCQUEwQjtBQUM5QjtBQUNBO0lBQ0kscUJBQXFCO0lBQ3JCLDJCQUEyQjtBQUMvQjtBQUNBO0lBQ0ksZ0JBQWdCO0FBQ3BCO0FBQ0E7SUFDSSxxQkFBcUI7SUFDckIscUJBQXFCO0FBQ3pCO0FBQ0E7SUFDSSxtQkFBbUI7QUFDdkI7O0FBRUEsNkVBQTZFO0FBQzdFO0lBQ0ksb0hBQW9IO1FBQ2hIOzs7Ozs7O1lBT0ksVUFBVTtZQUNWLGVBQWU7UUFDbkI7SUFDSix1QkFBdUI7UUFDbkI7O1lBRUksa0JBQWtCO1lBQ2xCLGVBQWU7UUFDbkI7SUFDSixxQ0FBcUM7UUFDakM7WUFDSSxxQkFBcUI7UUFDekI7UUFDQTtZQUNJLHFCQUFxQjtRQUN6QjtRQUNBO1lBQ0ksVUFBVTtRQUNkO1FBQ0E7WUFDSSxxQkFBcUI7UUFDekI7UUFDQTtZQUNJLHFCQUFxQjtRQUN6QjtRQUNBO1lBQ0ksVUFBVTtRQUNkO1FBQ0E7WUFDSSxxQkFBcUI7UUFDekI7UUFDQTtZQUNJLGdCQUFnQjtRQUNwQjtRQUNBO1lBQ0ksa0JBQWtCO1FBQ3RCO0FBQ1I7QUFDQTtJQUNJLGdCQUFnQjtBQUNwQjtBQUNBLGtDQUFrQyIsInNvdXJjZXNDb250ZW50IjpbIm5hdntcclxuICAgIGRpc3BsYXk6aW5saW5lICFpbXBvcnRhbnQ7XHJcbn1cclxuLmdseXBoaWNvbntcclxuICAgIGRpc3BsYXk6IGlubGluZSAhaW1wb3J0YW50O1xyXG59XHJcbi5zb2xpZC1saW5le1xyXG4gICAgYm9yZGVyLXRvcDogc29saWQgMXB4O1xyXG4gICAgYm9yZGVyLXRvcC1jb2xvcjogc2xhdGVncmF5O1xyXG59XHJcbmR0e1xyXG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcclxufVxyXG5kZCwgLndvcmRXcmFwe1xyXG4gICAgd29yZC13cmFwOiBicmVhay13b3JkO1xyXG4gICAgd2hpdGUtc3BhY2U6IHByZS1saW5lO1xyXG59XHJcbi5tcmduLWJ0dG17XHJcbiAgICBtYXJnaW4tYm90dG9tOiAyMHB4O1xyXG59XHJcblxyXG4vKiAtLS0gc3RhcnQgRGVzY3JpcHRpb24gTGlzdHMgKCBhZGRpbmcgZ3JpZHMgdG8gdGhlIFdFVCBkZWZhdWx0IGNsYXNzICktLS0gKi9cclxuQG1lZGlhIGFsbCBhbmQgKG1pbi13aWR0aDo3NjhweCkge1xyXG4gICAgLyogV2lkdGggb2YgZGwgaXMgMTAwJSB0byBzcGFuIG92ZXIgdGhlIGVudGlyZSB3aWR0aCwgYW5kIG1hcmdpbiB0b3AgdG8gZ2l2ZSBzcGFjZSBiZXR3ZWVuIGhlYWRpbmcgYW5kIHRoZSBjb250ZW50ICovXHJcbiAgICAgICAgLmRsLWNvbC00LFxyXG4gICAgICAgIC5kbC1jb2wtNSxcclxuICAgICAgICAuZGwtY29sLTYsXHJcbiAgICAgICAgLmRsLWNvbC03LFxyXG4gICAgICAgIC5kbC1jb2wtOCxcclxuICAgICAgICAuZGwtY29sLTksXHJcbiAgICAgICAgLmRsLWNvbC0xMCB7XHJcbiAgICAgICAgICAgIHdpZHRoOjEwMCU7XHJcbiAgICAgICAgICAgIG1hcmdpbi10b3A6MTVweDtcclxuICAgICAgICB9XHJcbiAgICAvKiBObyBwYWRkaW5nIGNsYXNzZXMgKi9cclxuICAgICAgICAubm9wYWRkaW5nIGRkLCAubm9wYWRkaW5nIGR0XHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBwYWRkaW5nLWJvdHRvbTowcHg7XHJcbiAgICAgICAgICAgIHBhZGRpbmctdG9wOjBweDtcclxuICAgICAgICB9XHJcbiAgICAvKiBXaWR0aCBvZiBkbCBiYXNlZCBvbiBncmlkIHN5c3RlbSAqL1xyXG4gICAgICAgIC5kbC1jb2wtNCA+IGR0IHtcclxuICAgICAgICAgICAgd2lkdGg6IDMzLjMzMzMzMzMzMzMlO1xyXG4gICAgICAgIH1cclxuICAgICAgICAuZGwtY29sLTUgPiBkdHtcclxuICAgICAgICAgICAgd2lkdGg6IDQxLjY2NjY2NjY2NjclO1xyXG4gICAgICAgIH1cclxuICAgICAgICAuZGwtY29sLTYgPiBkdCB7XHJcbiAgICAgICAgICAgIHdpZHRoOiA1MCU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5kbC1jb2wtNyA+IGR0IHtcclxuICAgICAgICAgICAgd2lkdGg6IDU4LjMzMzMzMzMzMzMlO1xyXG4gICAgICAgIH1cclxuICAgICAgICAuZGwtY29sLTggPiBkdCB7XHJcbiAgICAgICAgICAgIHdpZHRoOiA2Ni42NjY2NjY2NjY3JTtcclxuICAgICAgICB9XHJcbiAgICAgICAgLmRsLWNvbC05ID4gZHQge1xyXG4gICAgICAgICAgICB3aWR0aDogNzUlO1xyXG4gICAgICAgIH1cclxuICAgICAgICAuZGwtY29sLTEwID4gZHQge1xyXG4gICAgICAgICAgICB3aWR0aDogODMuMzMzMzMzMzMzMyU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5kbC1ob3Jpem9udGFsIGR0LmR0LWJ0dG0tMCB7XHJcbiAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDA7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5kbC1ob3Jpem9udGFsIGRkIHtcclxuICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IDYwMHB4O1xyXG4gICAgICAgIH1cclxufVxyXG4uZGwtaG9yaXpvbnRhbCBkZC5kZC1idHRtLTAge1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMDtcclxufVxyXG4vKiAtLS0gZW5kIERlc2NyaXB0aW9uIExpc3RzIC0tLSAqLyJdLCJzb3VyY2VSb290IjoiIn0= */"]
});

/***/ }),

/***/ 6882:
/*!*****************************************************!*\
  !*** ./src/app/components/entry/entry.component.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   EntryComponent: () => (/* binding */ EntryComponent)
/* harmony export */ });
/* harmony import */ var src_app_model_entry__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/model/entry */ 6404);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 6575);
/* harmony import */ var src_app_app_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/app-routing.module */ 3966);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ 1527);
/* harmony import */ var _base__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../base */ 6608);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 7947);
/* harmony import */ var src_app_services_result_result_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/result/result.service */ 1392);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngx-translate/core */ 5939);
/* harmony import */ var _cra_arc_rccr_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @cra-arc/rccr-core */ 838);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/platform-browser */ 6480);
/* harmony import */ var _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @cra-arc/rccr-wet */ 399);
/* harmony import */ var _templates_page_heading_local_page_heading_local_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../templates/page-heading-local/page-heading-local.component */ 3641);
/* harmony import */ var _templates_page_details_local_page_details_local_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../templates/page-details-local/page-details-local.component */ 9704);














class EntryComponent extends _base__WEBPACK_IMPORTED_MODULE_2__.BaseComponent {
  constructor(router, resultService, translate, activeRoute, windowService, metaService, document) {
    super(translate, resultService, windowService, metaService);
    this.router = router;
    this.resultService = resultService;
    this.translate = translate;
    this.activeRoute = activeRoute;
    this.windowService = windowService;
    this.metaService = metaService;
    this.document = document;
    this.entry = new src_app_model_entry__WEBPACK_IMPORTED_MODULE_0__.Entry();
    this.entryNext = new src_app_model_entry__WEBPACK_IMPORTED_MODULE_0__.Entry();
    // Initialize language
    let langParam = this.activeRoute.snapshot.params[src_app_app_routing_module__WEBPACK_IMPORTED_MODULE_1__.LANGUAGE_PARAMETER];
    if (langParam) {
      this.router.navigate([src_app_app_routing_module__WEBPACK_IMPORTED_MODULE_1__.ENTRY_PAGE], {
        replaceUrl: true
      });
      if (langParam === src_app_app_routing_module__WEBPACK_IMPORTED_MODULE_1__.LANGUAGE_ENGLISH || langParam === src_app_app_routing_module__WEBPACK_IMPORTED_MODULE_1__.LANGUAGE_FRENCH) {
        this.translate.use(langParam).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.take)(1)).subscribe(() => this.document.documentElement.lang = langParam);
      }
    }
    resultService.entry.subscribe(resp => {
      this.entry = resp;
    });
  }
  ngOnInit() {
    this.updateMeta(this.translate.instant('title'));
    this.adobeDLPush(this.translate.instant('title'));
  }
  start() {
    this.resultService.reset();
    this.resultService.entry.next(this.buildEntryNext());
    this.router.navigateByUrl('/generalinfo');
  }
  buildEntryNext() {
    this.entryNext = new src_app_model_entry__WEBPACK_IMPORTED_MODULE_0__.Entry();
    this.entryNext.hasStart = true;
    return this.entryNext;
  }
}
EntryComponent.ɵfac = function EntryComponent_Factory(t) {
  return new (t || EntryComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_8__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](src_app_services_result_result_service__WEBPACK_IMPORTED_MODULE_3__.ResultService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__.TranslateService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_8__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_cra_arc_rccr_core__WEBPACK_IMPORTED_MODULE_10__.WindowService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_angular_platform_browser__WEBPACK_IMPORTED_MODULE_11__.Meta), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_angular_common__WEBPACK_IMPORTED_MODULE_12__.DOCUMENT));
};
EntryComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineComponent"]({
  type: EntryComponent,
  selectors: [["app-entry"]],
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵInheritDefinitionFeature"]],
  decls: 93,
  vars: 86,
  consts: [["translate", "", 3, "pageHeading"], [1, "alert", "alert-warning", "mrgn-tp-lg"], [3, "innerHTML"], ["target", "_blank", "rel", "noopener noreferrer", 3, "href"], ["aria-hidden", "true", "title", "external link icon", 1, "fas", "fa-external-link-alt"], [1, "wb-inv"], [1, "h3"], ["rccrWetDetails", ""], ["id", "detailsummary"], [1, "mrgn-tp-md"], [1, "list-unstyled"], [1, "mrgn-tp-lg"], [1, "row", "mrgn-tp-lg", "mrgn-bttm-lg", "text-center"], [1, "btn", "btn-primary", "btn-lg", 3, "click"], [1, "mrgn-tp-xl", "disclaimer"], [3, "screenId"]],
  template: function EntryComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](0, "app-page-heading-local", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](1, "div")(2, "section", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](3, "p", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](4, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](5, "p");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](7, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](8, "p")(9, "strong");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](10);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](11, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](12);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](13, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](14, "p");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](15);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](16, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](17, "p");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](18);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](19, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](20, "a", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](21, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](22, "span", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](23, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](24, "i", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](25, "span", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](26);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](27, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](28, ". ");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](29, "h2", 6)(30, "strong");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](31);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](32, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](33, "div")(34, "details", 7)(35, "summary", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](36);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](37, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](38, "div", 9)(39, "ul", 10)(40, "li");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](41);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](42, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](43, "li");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](44);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](45, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](46, "li");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](47);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](48, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](49, "li");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](50);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](51, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](52, "li");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](53);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](54, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](55, "li");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](56);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](57, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](58, "li");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](59);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](60, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](61, "li");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](62);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](63, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](64, "p", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](65);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](66, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](67, "a", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](68, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](69, "span", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](70, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](71, "i", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](72, "span", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](73);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](74, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](75, ". ");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()()()();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](76, "div", 12)(77, "button", 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function EntryComponent_Template_button_click_77_listener() {
        return ctx.start();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](78);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](79, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](80, "p", 14);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](81);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](82, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](83, "a", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](84, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](85, "span", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](86, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](87, "i", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](88, "span", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](89);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipe"](90, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](91, ".\n");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](92, "app-page-details-local", 15);
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("pageHeading", "title");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("innerHTML", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](4, 30, "entry.maintenance.alert"), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵsanitizeHtml"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](7, 32, "entry.main.texta1"));
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](11, 34, "entry.main.texta2"));
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](13, 36, "entry.main.texta3"), "");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](16, 38, "entry.main.textb2"));
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](19, 40, "entry.main.textb3"), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("href", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](21, 42, "entry.main.textb3.link"), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵsanitizeUrl"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("innerHTML", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](23, 44, "entry.main.textb3.label"), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵsanitizeHtml"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](27, 46, "newWindow"), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](32, 48, "summaryComponent.label"));
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](37, 50, "summaryComponent.text"), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](42, 52, "summaryComponent.text.main.1"), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](45, 54, "summaryComponent.text.main.2"), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](48, 56, "summaryComponent.text.main.3"), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](51, 58, "summaryComponent.text.main.4"), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](54, 60, "summaryComponent.text.main.5"), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](57, 62, "summaryComponent.text.main.6"), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](60, 64, "summaryComponent.text.main.7"), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](63, 66, "summaryComponent.text.main.8"), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](66, 68, "summaryComponent.text.note"), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("href", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](68, 70, "summaryComponent.text.note.link"), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵsanitizeUrl"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("innerHTML", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](70, 72, "summaryComponent.text.note.label"), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵsanitizeHtml"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](74, 74, "newWindow"), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](79, 76, "start"));
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](82, 78, "entry.main.textc"), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("href", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](84, 80, "entry.main.textc.link"), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵsanitizeUrl"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("innerHTML", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](86, 82, "entry.main.textc.label"), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵsanitizeHtml"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵpipeBind1"](90, 84, "newWindow"), "");
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("screenId", "UISP-RC193-ENTRY");
    }
  },
  dependencies: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__.TranslateDirective, _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_13__.WetDetailsDirective, _templates_page_heading_local_page_heading_local_component__WEBPACK_IMPORTED_MODULE_4__.PageHeadingLocalComponent, _templates_page_details_local_page_details_local_component__WEBPACK_IMPORTED_MODULE_5__.PageDetailsLocalComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__.TranslatePipe],
  styles: [".disclaimer[_ngcontent-%COMP%]{\n    font-size: 16px;\n    line-height: 130%;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29tcG9uZW50cy9lbnRyeS9lbnRyeS5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksZUFBZTtJQUNmLGlCQUFpQjtBQUNyQiIsInNvdXJjZXNDb250ZW50IjpbIi5kaXNjbGFpbWVye1xyXG4gICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgbGluZS1oZWlnaHQ6IDEzMCU7XHJcbn0iXSwic291cmNlUm9vdCI6IiJ9 */"]
});

/***/ }),

/***/ 3133:
/*!*********************************************************************************!*\
  !*** ./src/app/components/general-information/general-information.component.ts ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GeneralInformationComponent: () => (/* binding */ GeneralInformationComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/forms */ 8849);
/* harmony import */ var _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @cra-arc/rccr-wet */ 399);
/* harmony import */ var src_app_model_generalInformation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/model/generalInformation */ 2984);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs */ 1523);
/* harmony import */ var src_app_app_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/app.component */ 6401);
/* harmony import */ var src_app_util_AppFormHelper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/util/AppFormHelper */ 5664);
/* harmony import */ var _base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../base */ 6608);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var src_app_services_result_result_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/result/result.service */ 1392);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/router */ 7947);
/* harmony import */ var src_app_services_validation_validation_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/validation/validation.service */ 1109);
/* harmony import */ var _cra_arc_rccr_core__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @cra-arc/rccr-core */ 838);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @ngx-translate/core */ 5939);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/platform-browser */ 6480);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/common */ 6575);
/* harmony import */ var _templates_back_next_buttongroup_back_next_buttongroup_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../templates/back-next-buttongroup/back-next-buttongroup.component */ 672);
/* harmony import */ var _templates_select_local_select_local_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../templates/select-local/select-local.component */ 1434);
/* harmony import */ var _templates_page_heading_local_page_heading_local_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../templates/page-heading-local/page-heading-local.component */ 3641);
/* harmony import */ var _templates_page_details_local_page_details_local_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../templates/page-details-local/page-details-local.component */ 9704);
/* harmony import */ var _templates_multiselect_button_group_multiselect_button_group_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../templates/multiselect-button-group/multiselect-button-group.component */ 8564);
/* harmony import */ var _templates_denotes_required_denotes_required_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../templates/denotes-required/denotes-required.component */ 1284);























function GeneralInformationComponent_div_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "div")(1, "rccr-button-group", 9)(2, "rccr-button-toggle", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](5, "\u00A0 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](6, "rccr-button-toggle", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipe"](8, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("id", "isRepondSuggestion")("form", ctx_r0.form)("required", true)("containsMarkup", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("form", ctx_r0.form)("formControlName", "isRepondSuggestion")("id", "isRepondSuggestionYes")("value", "yes");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipeBind1"](4, 14, "yes"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("form", ctx_r0.form)("formControlName", "isRepondSuggestion")("id", "isRepondSuggestionNo")("value", "no");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipeBind1"](8, 16, "no"), " ");
  }
}
function GeneralInformationComponent_div_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "div")(1, "rccr-button-group", 11)(2, "rccr-button-toggle", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](5, "\u00A0 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](6, "rccr-button-toggle", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipe"](8, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("id", "isRepondCompliment")("form", ctx_r1.form)("required", true)("containsMarkup", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("form", ctx_r1.form)("formControlName", "isRepondCompliment")("id", "isRepondComplimentYes")("value", "yes");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipeBind1"](4, 14, "yes"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("form", ctx_r1.form)("formControlName", "isRepondCompliment")("id", "isRepondComplimentNo")("value", "no");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipeBind1"](8, 16, "no"), " ");
  }
}
function GeneralInformationComponent_rccr_button_group_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "rccr-button-group", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipe"](1, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](3, "rccr-button-toggle", 13)(4, "div", 14)(5, "span", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](6, "i", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](7, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipe"](9, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](10, "rccr-button-toggle", 13)(11, "div", 14)(12, "span", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](13, "i", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](14, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](15);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipe"](16, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](17, "rccr-button-toggle", 13)(18, "div", 14)(19, "span", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](20, "i", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](21, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](22);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipe"](23, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpropertyInterpolate2"]("helpAccessibleTextKey", "", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipeBind1"](1, 18, "help.title"), " ", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipeBind1"](2, 20, "genInfo.submitOnBehalf"), "");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("form", ctx_r2.form)("required", true)("containsMarkup", true)("inlineHelpKey", "genInfo.onBehalfRep.help");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("form", ctx_r2.form)("formControlName", "onBehalf")("value", ctx_r2.onBehalfList[0]);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipeBind1"](9, 22, "genInfo.onBehalfMyself"));
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("form", ctx_r2.form)("formControlName", "onBehalf")("value", ctx_r2.onBehalfList[1]);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipeBind1"](16, 24, "genInfo.onBehalfBusiness"));
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("form", ctx_r2.form)("formControlName", "onBehalf")("value", ctx_r2.onBehalfList[2]);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipeBind1"](23, 26, "genInfo.onBehalfRep"));
  }
}
function GeneralInformationComponent_div_8_div_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "div")(1, "rccr-button-group", 26)(2, "rccr-radio-button", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](5, "rccr-radio-button", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipe"](7, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("form", ctx_r5.form)("containsMarkup", true)("controlName", "isIndividualOrBusiness")("id", "isIndividualOrBusiness")("legendKey", "genInfo.isIndividualOrBusiness")("required", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("id", "isIndividualOrBusinessIndividual")("value", "genInfo.isIndividual");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipeBind1"](4, 12, "genInfo.isIndividual"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("id", "isIndividualOrBusinessBusiness")("value", "genInfo.isEntreprise");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipeBind1"](7, 14, "genInfo.isEntreprise"), " ");
  }
}
const _c0 = function () {
  return {
    "size": "40",
    "maxlength": "25"
  };
};
function GeneralInformationComponent_div_8_div_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "div", 24)(1, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](2, "rccr-text-input", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](3, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](4, "rccr-text-input", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("form", ctx_r6.form)("formControlName", "firstName")("required", ctx_r6.requireFirstLastNameInfo())("labelKey", "genInfo.firstName")("labelContainsMarkup", true)("attributes", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction0"](12, _c0));
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("form", ctx_r6.form)("formControlName", "lastName")("required", ctx_r6.requireFirstLastNameInfo())("labelKey", "genInfo.lastName")("labelContainsMarkup", true)("attributes", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction0"](13, _c0));
  }
}
const _c1 = function () {
  return {
    "size": "40",
    "maxlength": "125"
  };
};
const _c2 = function () {
  return {
    "size": "40",
    "maxlength": "15"
  };
};
function GeneralInformationComponent_div_8_div_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "div", 24)(1, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](2, "rccr-text-input", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](3, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](4, "rccr-text-input", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("form", ctx_r7.form)("formControlName", "businessName")("required", true)("labelKey", "genInfo.businessName")("labelContainsMarkup", true)("attributes", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction0"](12, _c1));
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("form", ctx_r7.form)("formControlName", "businessNum")("required", true)("labelKey", "genInfo.businessNum")("labelContainsMarkup", true)("attributes", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction0"](13, _c2));
  }
}
function GeneralInformationComponent_div_8_div_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "div")(1, "rccr-button-group", 26)(2, "rccr-radio-button", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](5, "rccr-radio-button", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipe"](7, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("form", ctx_r8.form)("containsMarkup", true)("controlName", "isSINorOtherAccountNum")("id", "isSINorOtherAccountNum")("legendKey", "genInfo.isSINorOtherAccountNum")("required", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("id", "isSINorOtherAccountNumSIN")("value", "genInfo.isSIN");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipeBind1"](4, 12, "genInfo.isSIN"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("id", "isSINorOtherAccountNumOther")("value", "genInfo.isOtherAccountNum");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipeBind1"](7, 14, "genInfo.isOtherAccountNum"), " ");
  }
}
const _c3 = function () {
  return {
    "size": "40",
    "maxlength": "9"
  };
};
function GeneralInformationComponent_div_8_div_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](1, "rccr-text-input", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("form", ctx_r9.form)("formControlName", "sin")("required", true)("labelKey", "genInfo.sin")("labelContainsMarkup", true)("attributes", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction0"](6, _c3));
  }
}
function GeneralInformationComponent_div_8_div_12_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](1, "rccr-text-input", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("form", ctx_r10.form)("formControlName", "otherAccntNum")("required", true)("labelKey", "genInfo.otherAccntNum")("labelContainsMarkup", true)("attributes", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction0"](6, _c2));
  }
}
const _c4 = function () {
  return {
    "size": "40",
    "maxlength": "150"
  };
};
function GeneralInformationComponent_div_8_div_13_div_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](1, "rccr-text-input", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("form", ctx_r12.form)("formControlName", "country")("required", true)("labelKey", "genInfo.country")("labelContainsMarkup", true)("attributes", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction0"](6, _c4));
  }
}
function GeneralInformationComponent_div_8_div_13_div_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](1, "app-select-local", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("form", ctx_r13.form)("labelKey", "genInfo.province")("selectList", ctx_r13.provinceList)("selectLocal", "province");
  }
}
const _c5 = function () {
  return {
    "size": "40",
    "maxlength": "7"
  };
};
function GeneralInformationComponent_div_8_div_13_div_16_rccr_text_input_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](0, "rccr-text-input", 29);
  }
  if (rf & 2) {
    const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("form", ctx_r15.form)("formControlName", "postalCode")("required", true)("labelKey", "genInfo.postalCanada")("labelContainsMarkup", true)("attributes", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction0"](6, _c5));
  }
}
const _c6 = function () {
  return {
    "size": "40",
    "maxlength": "20"
  };
};
function GeneralInformationComponent_div_8_div_13_div_16_rccr_text_input_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](0, "rccr-text-input", 29);
  }
  if (rf & 2) {
    const ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("form", ctx_r16.form)("formControlName", "postalCode")("required", true)("labelKey", "genInfo.postalOutsideCanada")("labelContainsMarkup", true)("attributes", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction0"](6, _c6));
  }
}
function GeneralInformationComponent_div_8_div_13_div_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](1, GeneralInformationComponent_div_8_div_13_div_16_rccr_text_input_1_Template, 1, 7, "rccr-text-input", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](2, GeneralInformationComponent_div_8_div_13_div_16_rccr_text_input_2_Template, 1, 7, "rccr-text-input", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngIf", ctx_r14.province.enabled);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngIf", ctx_r14.country.enabled);
  }
}
const _c7 = function () {
  return {
    "size": "40",
    "maxlength": "100"
  };
};
function GeneralInformationComponent_div_8_div_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "div")(1, "rccr-button-group", 26)(2, "rccr-radio-button", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](5, "rccr-radio-button", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipe"](7, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](8, "div", 24)(9, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](10, "rccr-text-input", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](11, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](12, "rccr-text-input", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](13, "div", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](14, GeneralInformationComponent_div_8_div_13_div_14_Template, 2, 7, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](15, GeneralInformationComponent_div_8_div_13_div_15_Template, 2, 4, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](16, GeneralInformationComponent_div_8_div_13_div_16_Template, 3, 2, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](17, "div", 24)(18, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](19, "rccr-text-input", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](20, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](21, "rccr-text-input", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("form", ctx_r11.form)("containsMarkup", true)("controlName", "isCanada")("id", "isCanada")("legendKey", "genInfo.isCanada")("required", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("id", "isCanadaYes")("value", "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipeBind1"](4, 39, "genInfo.canada"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("id", "isCanadaNo")("value", "genInfo.outsideCanada");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipeBind1"](7, 41, "genInfo.outsideCanada"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("form", ctx_r11.form)("formControlName", "mailingAddress")("required", true)("labelKey", "genInfo.mailingAddress")("labelContainsMarkup", true)("attributes", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction0"](43, _c4));
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("form", ctx_r11.form)("formControlName", "city")("required", true)("labelKey", "genInfo.city")("labelContainsMarkup", true)("attributes", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction0"](44, _c7));
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngIf", ctx_r11.country.enabled);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngIf", ctx_r11.province.enabled);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngIf", ctx_r11.postalCode.enabled);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("form", ctx_r11.form)("formControlName", "mainPhone")("required", true)("labelKey", "genInfo.phone")("labelContainsMarkup", true)("attributes", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction0"](45, _c6));
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("form", ctx_r11.form)("formControlName", "altPhone")("required", false)("labelKey", "genInfo.altPhone")("labelContainsMarkup", true)("attributes", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction0"](46, _c6));
  }
}
function GeneralInformationComponent_div_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "div", 21)(1, "fieldset")(2, "legend", 22)(3, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipe"](5, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](6, GeneralInformationComponent_div_8_div_6_Template, 8, 16, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](7, GeneralInformationComponent_div_8_div_7_Template, 5, 14, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](8, GeneralInformationComponent_div_8_div_8_Template, 5, 14, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](9, GeneralInformationComponent_div_8_div_9_Template, 8, 16, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](10, "div", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](11, GeneralInformationComponent_div_8_div_11_Template, 2, 7, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](12, GeneralInformationComponent_div_8_div_12_Template, 2, 7, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](13, GeneralInformationComponent_div_8_div_13_Template, 22, 47, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipeBind1"](5, 8, ctx_r3.repFirstName.enabled ? "genInfo.clientInfo" : ctx_r3.businessName.enabled ? "genInfo.BusinessInfo" : "genInfo.IndividualInfo"));
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngIf", ctx_r3.repFirstName.enabled);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngIf", ctx_r3.firstName.enabled);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngIf", ctx_r3.businessName.enabled);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngIf", ctx_r3.requireFirstLastNameInfo());
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngIf", ctx_r3.sin.enabled);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngIf", ctx_r3.otherAccntNum.enabled);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngIf", ctx_r3.isCanada.enabled);
  }
}
function GeneralInformationComponent_div_9_rccr_text_input_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](0, "rccr-text-input", 31);
  }
  if (rf & 2) {
    const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("form", ctx_r17.form)("formControlName", "repNum")("required", false)("labelKey", "genInfo.repNum")("labelContainsMarkup", true)("attributes", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction0"](6, _c5));
  }
}
function GeneralInformationComponent_div_9_div_16_div_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](1, "rccr-text-input", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("form", ctx_r19.form)("formControlName", "repCountry")("required", true)("labelKey", "genInfo.country")("labelContainsMarkup", true)("attributes", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction0"](6, _c4));
  }
}
function GeneralInformationComponent_div_9_div_16_div_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](1, "app-select-local", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r20 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("form", ctx_r20.form)("labelKey", "genInfo.province")("selectList", ctx_r20.provinceList)("selectLocal", "repProvince");
  }
}
function GeneralInformationComponent_div_9_div_16_div_16_rccr_text_input_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](0, "rccr-text-input", 29);
  }
  if (rf & 2) {
    const ctx_r22 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("form", ctx_r22.form)("formControlName", "repPostalCode")("required", true)("labelKey", "genInfo.postalCanada")("labelContainsMarkup", true)("attributes", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction0"](6, _c5));
  }
}
function GeneralInformationComponent_div_9_div_16_div_16_rccr_text_input_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](0, "rccr-text-input", 29);
  }
  if (rf & 2) {
    const ctx_r23 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("form", ctx_r23.form)("formControlName", "repPostalCode")("required", true)("labelKey", "genInfo.postalOutsideCanada")("labelContainsMarkup", true)("attributes", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction0"](6, _c6));
  }
}
function GeneralInformationComponent_div_9_div_16_div_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](1, GeneralInformationComponent_div_9_div_16_div_16_rccr_text_input_1_Template, 1, 7, "rccr-text-input", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](2, GeneralInformationComponent_div_9_div_16_div_16_rccr_text_input_2_Template, 1, 7, "rccr-text-input", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngIf", ctx_r21.repProvince.enabled);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngIf", ctx_r21.repCountry.enabled);
  }
}
function GeneralInformationComponent_div_9_div_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "div")(1, "rccr-button-group", 26)(2, "rccr-radio-button", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](5, "rccr-radio-button", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipe"](7, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](8, "div", 24)(9, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](10, "rccr-text-input", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](11, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](12, "rccr-text-input", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](13, "div", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](14, GeneralInformationComponent_div_9_div_16_div_14_Template, 2, 7, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](15, GeneralInformationComponent_div_9_div_16_div_15_Template, 2, 4, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](16, GeneralInformationComponent_div_9_div_16_div_16_Template, 3, 2, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](17, "div", 24)(18, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](19, "rccr-text-input", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("form", ctx_r18.form)("containsMarkup", true)("controlName", "repIsCanada")("id", "repIsCanada")("legendKey", "genInfo.isCanada")("required", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("id", "repIsCanadaYes")("value", "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipeBind1"](4, 33, "genInfo.canada"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("id", "repIsCanadaNo")("value", "genInfo.outsideCanada");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipeBind1"](7, 35, "genInfo.outsideCanada"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("form", ctx_r18.form)("formControlName", "repMailingAddress")("required", true)("labelKey", "genInfo.mailingAddress")("labelContainsMarkup", true)("attributes", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction0"](37, _c4));
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("form", ctx_r18.form)("formControlName", "repCity")("required", true)("labelKey", "genInfo.city")("labelContainsMarkup", true)("attributes", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction0"](38, _c7));
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngIf", ctx_r18.repCountry.enabled);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngIf", ctx_r18.repProvince.enabled);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngIf", ctx_r18.repPostalCode.enabled);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("form", ctx_r18.form)("formControlName", "repMainPhone")("required", true)("labelKey", "genInfo.phone")("labelContainsMarkup", true)("attributes", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction0"](39, _c6));
  }
}
function GeneralInformationComponent_div_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "div", 21)(1, "fieldset")(2, "legend", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](5, "div", 24)(6, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](7, "rccr-text-input", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](8, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](9, "rccr-text-input", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](10, "div", 24)(11, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](12, "rccr-text-input", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](13, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](14, "rccr-text-input", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](15, GeneralInformationComponent_div_9_rccr_text_input_15_Template, 1, 7, "rccr-text-input", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](16, GeneralInformationComponent_div_9_div_16_Template, 20, 40, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipeBind1"](4, 27, "genInfo.repInfo"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("form", ctx_r4.form)("formControlName", "repFirstName")("required", true)("labelKey", "genInfo.firstName")("labelContainsMarkup", true)("attributes", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction0"](29, _c0));
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("form", ctx_r4.form)("formControlName", "repLastName")("required", true)("labelKey", "genInfo.lastName")("labelContainsMarkup", true)("attributes", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction0"](30, _c0));
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("form", ctx_r4.form)("formControlName", "repBusinessName")("required", false)("labelKey", "genInfo.busiNameIfapplicable")("labelContainsMarkup", true)("attributes", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction0"](31, _c1));
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("form", ctx_r4.form)("formControlName", "repBusinessNum")("required", false)("labelKey", "genInfo.busiNumIfapplicable")("labelContainsMarkup", true)("attributes", _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpureFunction0"](32, _c2));
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngIf", ctx_r4.repNum.enabled);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngIf", ctx_r4.repIsCanada.enabled);
  }
}
class GeneralInformationComponent extends _base__WEBPACK_IMPORTED_MODULE_3__.BaseComponent {
  constructor(fb, infoService, router, validationService, focusService, translateService, windowService, metaService) {
    super(translateService, infoService, windowService, metaService);
    this.fb = fb;
    this.router = router;
    this.validationService = validationService;
    this.focusService = focusService;
    this.translateService = translateService;
    this.generalInfo = new src_app_model_generalInformation__WEBPACK_IMPORTED_MODULE_0__.GeneralInformation();
    this.generalInfoNext = new src_app_model_generalInformation__WEBPACK_IMPORTED_MODULE_0__.GeneralInformation();
    this.feedbackTypeList = ['complaint', 'suggestion', 'compliment'];
    this.onBehalfList = ['myself', 'business', 'representative'];
    this.isCanadaList = ['genInfo.canada', 'genInfo.outsideCanada'];
    this.isIndividualOrBusinessList = ['genInfo.isIndividual', 'genInfo.isEntreprise'];
    this.isSINorOtherAccountNumList = ['genInfo.isSIN', 'genInfo.isOtherAccountNum'];
    this.feedBackTypeSubscription = new rxjs__WEBPACK_IMPORTED_MODULE_13__.Subscription();
    this.onBehalfSubscription = new rxjs__WEBPACK_IMPORTED_MODULE_13__.Subscription();
    this.isIndividualOrBusinessSubscription = new rxjs__WEBPACK_IMPORTED_MODULE_13__.Subscription();
    this.isCanadaSubscription = new rxjs__WEBPACK_IMPORTED_MODULE_13__.Subscription();
    this.repIsCanadaSubscription = new rxjs__WEBPACK_IMPORTED_MODULE_13__.Subscription();
    this.isRepondSuggestionSubscription = new rxjs__WEBPACK_IMPORTED_MODULE_13__.Subscription();
    this.isRepondComplimentSubscription = new rxjs__WEBPACK_IMPORTED_MODULE_13__.Subscription();
    this.isSINorOtherAccountNumSubscription = new rxjs__WEBPACK_IMPORTED_MODULE_13__.Subscription();
    this.postalCodeCASubscription = new rxjs__WEBPACK_IMPORTED_MODULE_13__.Subscription();
    this.repPostalCodeCASubscription = new rxjs__WEBPACK_IMPORTED_MODULE_13__.Subscription();
    this.feedbackTypeInput = [];
    this.provinceList = ['AB', 'BC', 'MB', 'NB', 'NL', 'NT', 'NS', 'NU', 'ON', 'PE', 'QC', 'SK', 'YT'];
    infoService.generalInfo.subscribe(resp => {
      this.generalInfo = resp;
    });
  }
  ngOnInit() {
    this.updateMeta(this.translateService.instant('genInfo.title'));
    this.adobeDLPush(this.translateService.instant('genInfo.title'));
    this.form = this.fb.group({
      feedbackType: new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.UntypedFormControl({
        value: this.generalInfo.feedbackType,
        disabled: false
      }, {
        validators: _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required,
        updateOn: 'change'
      }),
      isRepondSuggestion: new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.UntypedFormControl({
        value: this.generalInfo.isRepondSuggestion,
        disabled: !this.enableIsRepondSuggestion()
      }, {
        validators: _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required,
        updateOn: 'change'
      }),
      isRepondCompliment: new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.UntypedFormControl({
        value: this.generalInfo.isRepondCompliment,
        disabled: !this.enableIsRepondCompliment()
      }, {
        validators: _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required,
        updateOn: 'change'
      }),
      onBehalf: new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.UntypedFormControl({
        value: this.generalInfo.onBehalf,
        disabled: !this.enableOnBehalf()
      }, {
        validators: _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required,
        updateOn: 'change'
      }),
      isIndividualOrBusiness: new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.UntypedFormControl({
        value: this.generalInfo.isIndividualOrBusiness,
        disabled: !this.enableRepInfo()
      }, {
        validators: _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required,
        updateOn: 'change'
      }),
      firstName: new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.UntypedFormControl({
        value: this.generalInfo.firstName,
        disabled: !this.enableFirstLastNameInfo()
      }, {
        validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.maxLength(25), this.noNumbersValidator(), this.noSpecialCharsbutFrenchHyphenValidator()],
        updateOn: 'blur'
      }),
      lastName: new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.UntypedFormControl({
        value: this.generalInfo.lastName,
        disabled: !this.enableFirstLastNameInfo()
      }, {
        validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.maxLength(25), this.noNumbersValidator(), this.noSpecialCharsbutFrenchHyphenValidator()],
        updateOn: 'blur'
      }),
      businessName: new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.UntypedFormControl({
        value: this.generalInfo.businessName,
        disabled: !this.enableBusinessInfo()
      }, {
        validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.maxLength(125), this.validationService.noSpecialCharsStrictValidator()],
        updateOn: 'blur'
      }),
      businessNum: new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.UntypedFormControl({
        value: this.generalInfo.businessNum,
        disabled: !this.enableBusinessInfo()
      }, {
        validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.maxLength(15), this.businessNumValidator()],
        updateOn: 'blur'
      }),
      isSINorOtherAccountNum: new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.UntypedFormControl({
        value: this.generalInfo.isSINorOtherAccountNum,
        disabled: !this.enableIsSINorOtherAccountNum()
      }, {
        validators: _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required,
        updateOn: 'change'
      }),
      sin: new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.UntypedFormControl({
        value: this.generalInfo.sin,
        disabled: !this.enableSIN()
      }, {
        validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.maxLength(9), this.sinValidator()],
        updateOn: 'blur'
      }),
      otherAccntNum: new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.UntypedFormControl({
        value: this.generalInfo.otherAccntNum,
        disabled: !this.enableOtherAccntNum()
      }, {
        validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.maxLength(15), this.otherAccntNumValidator()],
        updateOn: 'blur'
      }),
      isCanada: new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.UntypedFormControl({
        value: this.generalInfo.isCanada,
        disabled: !this.enableCommonInfo()
      }, {
        validators: _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required,
        updateOn: 'change'
      }),
      mailingAddress: new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.UntypedFormControl({
        value: this.generalInfo.mailingAddress,
        disabled: !this.enableCommonInfo()
      }, {
        validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.maxLength(150), this.mailingAddressValidator()],
        updateOn: 'blur'
      }),
      city: new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.UntypedFormControl({
        value: this.generalInfo.city,
        disabled: !this.enableCommonInfo()
      }, {
        validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.maxLength(100), this.noNumbersValidator(), this.noSpecialCharsbutFrenchHyphenValidator()],
        updateOn: 'blur'
      }),
      country: new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.UntypedFormControl({
        value: this.generalInfo.country,
        disabled: !this.enableCountry()
      }, {
        validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.maxLength(150), this.noNumbersValidator(), this.noSpecialCharsbutFrenchHyphenValidator()],
        updateOn: 'blur'
      }),
      province: new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.UntypedFormControl({
        value: this.generalInfo.province,
        disabled: !this.enableProvince()
      }, {
        validators: _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required,
        updateOn: 'change'
      }),
      postalCode: new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.UntypedFormControl({
        value: this.generalInfo.postalCode,
        disabled: !this.enablePostalCode()
      }, {
        validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.maxLength(20)],
        updateOn: 'blur'
      }),
      mainPhone: new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.UntypedFormControl({
        value: this.generalInfo.mainPhone,
        disabled: !this.enableCommonInfo()
      }, {
        validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.maxLength(20), this.noLetterValidator(), this.phoneValidator()],
        updateOn: 'blur'
      }),
      altPhone: new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.UntypedFormControl({
        value: this.generalInfo.altPhone,
        disabled: !this.enableCommonInfo()
      }, {
        validators: [this.noLetterValidator(), _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.maxLength(20), this.phoneValidator()],
        updateOn: 'blur'
      }),
      repFirstName: new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.UntypedFormControl({
        value: this.generalInfo.repFirstName,
        disabled: !this.enableRepInfo()
      }, {
        validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.maxLength(25), this.noNumbersValidator(), this.noSpecialCharsbutFrenchHyphenValidator()],
        updateOn: 'blur'
      }),
      repLastName: new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.UntypedFormControl({
        value: this.generalInfo.repLastName,
        disabled: !this.enableRepInfo()
      }, {
        validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.maxLength(25), this.noNumbersValidator(), this.noSpecialCharsbutFrenchHyphenValidator()],
        updateOn: 'blur'
      }),
      repBusinessName: new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.UntypedFormControl({
        value: this.generalInfo.repBusinessName,
        disabled: !this.enableRepInfo()
      }, {
        validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.maxLength(125), this.validationService.noSpecialCharsStrictValidator()],
        updateOn: 'change'
      }),
      repBusinessNum: new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.UntypedFormControl({
        value: this.generalInfo.repBusinessNum,
        disabled: !this.enableRepInfo()
      }, {
        validators: [this.businessNumValidator(), _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.maxLength(15)],
        updateOn: 'blur'
      }),
      repNum: new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.UntypedFormControl({
        value: this.generalInfo.repNum,
        disabled: !this.enableRepInfo()
      }, {
        validators: [this.repNumValidator(), _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.maxLength(7)],
        updateOn: 'blur'
      }),
      repIsCanada: new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.UntypedFormControl({
        value: this.generalInfo.repIsCanada,
        disabled: !this.enableRepInfo()
      }, {
        validators: _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required,
        updateOn: 'change'
      }),
      repMailingAddress: new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.UntypedFormControl({
        value: this.generalInfo.repMailingAddress,
        disabled: !this.enableRepInfo()
      }, {
        validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.maxLength(150), this.mailingAddressValidator()],
        updateOn: 'blur'
      }),
      repCity: new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.UntypedFormControl({
        value: this.generalInfo.repCity,
        disabled: !this.enableRepInfo()
      }, {
        validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.maxLength(100), this.noNumbersValidator(), this.noSpecialCharsbutFrenchHyphenValidator()],
        updateOn: 'blur'
      }),
      repCountry: new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.UntypedFormControl({
        value: this.generalInfo.repCountry,
        disabled: !this.enableRepCountry()
      }, {
        validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.maxLength(150), this.noNumbersValidator(), this.noSpecialCharsbutFrenchHyphenValidator()],
        updateOn: 'blur'
      }),
      repProvince: new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.UntypedFormControl({
        value: this.generalInfo.repProvince,
        disabled: !this.enableRepProvince()
      }, {
        validators: _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required,
        updateOn: 'change'
      }),
      repPostalCode: new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.UntypedFormControl({
        value: this.generalInfo.repPostalCode,
        disabled: !this.enableRepPostalCode()
      }, {
        validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.maxLength(20)],
        updateOn: 'blur'
      }),
      repMainPhone: new _angular_forms__WEBPACK_IMPORTED_MODULE_14__.UntypedFormControl({
        value: this.generalInfo.repMainPhone,
        disabled: !this.enableRepInfo()
      }, {
        validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.maxLength(20), this.noLetterValidator(), this.phoneValidator()],
        updateOn: 'blur'
      })
    });
    this.setInitialValidation();
    this.onChanges();
  }
  setInitialValidation() {
    if (this.isCanada.value == null || this.isCanada.value.length == 0) {
      this.postalCode?.setValidators([]);
    } else if (this.isCanada.value == this.isCanadaList[0]) {
      this.postalCode?.setValidators([_angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.maxLength(7), this.postalCodeCanadaValidator()]);
    } else if (this.isCanada.value == this.isCanadaList[1]) {
      this.postalCode?.setValidators([_angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.maxLength(20), this.postalCodeOutsideCanadaValidator()]);
    }
    this.postalCode?.updateValueAndValidity();
    if (this.repIsCanada.value == null || this.repIsCanada.value.length == 0) {
      this.repPostalCode?.setValidators([]);
    } else if (this.repIsCanada.value == this.isCanadaList[0]) {
      this.repPostalCode?.setValidators([_angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.maxLength(7), this.postalCodeCanadaValidator()]);
    } else if (this.repIsCanada.value == this.isCanadaList[1]) {
      this.repPostalCode?.setValidators([_angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.maxLength(20), this.postalCodeOutsideCanadaValidator()]);
    }
    this.repPostalCode?.updateValueAndValidity();
  }
  onChanges() {
    this.feedBackTypeSubscription = this.feedbackType.valueChanges.subscribe(selectedfeedbackType => {
      if (selectedfeedbackType) {
        const orderedfeedbackTypeList = this.feedbackTypeList;
        const newFeedbackTypeArray = selectedfeedbackType.split(",").sort(function (a, b) {
          return orderedfeedbackTypeList.indexOf(a) - orderedfeedbackTypeList.indexOf(b);
        });
        this.feedbackType.patchValue(newFeedbackTypeArray.join(','), {
          emitEvent: false,
          onlySelf: true
        });
      } else {
        this.hideFormControl(this.form, 'onBehalf');
      }
      if (selectedfeedbackType?.split(',')?.includes(this.feedbackTypeList[1])) {
        this.showFormControl(this.form, 'isRepondSuggestion');
      } else {
        this.hideFormControl(this.form, 'isRepondSuggestion');
      }
      if (selectedfeedbackType?.split(',')?.includes(this.feedbackTypeList[2])) {
        this.showFormControl(this.form, 'isRepondCompliment');
      } else {
        this.hideFormControl(this.form, 'isRepondCompliment');
      }
      if (selectedfeedbackType?.split(',')?.includes(this.feedbackTypeList[0])) {
        this.showFormControl(this.form, 'onBehalf');
      } else if (selectedfeedbackType?.split(',')?.includes(this.feedbackTypeList[1]) && this.isRepondSuggestion?.value == 'yes' || selectedfeedbackType?.split(',')?.includes(this.feedbackTypeList[2]) && this.isRepondCompliment?.value == 'yes') {
        this.showFormControl(this.form, 'onBehalf');
      } else {
        this.hideFormControl(this.form, 'onBehalf');
      }
    });
    this.isRepondSuggestionSubscription = this.isRepondSuggestion.valueChanges.subscribe(selectedIsRepondSuggestion => {
      if (this.feedbackType?.value?.split(',')?.includes(this.feedbackTypeList[0])) {
        this.showFormControl(this.form, 'onBehalf');
      } else if (this.feedbackType?.value?.split(',')?.includes(this.feedbackTypeList[1]) && selectedIsRepondSuggestion == 'yes' || this.feedbackType?.value?.split(',')?.includes(this.feedbackTypeList[2]) && this.isRepondCompliment?.value == 'yes') {
        this.showFormControl(this.form, 'onBehalf');
      } else {
        this.hideFormControl(this.form, 'onBehalf');
      }
    });
    this.isRepondComplimentSubscription = this.isRepondCompliment.valueChanges.subscribe(selectedIsRepondCompliment => {
      if (this.feedbackType?.value?.split(',')?.includes(this.feedbackTypeList[0])) {
        this.showFormControl(this.form, 'onBehalf');
      } else if (this.feedbackType?.value?.split(',')?.includes(this.feedbackTypeList[1]) && this.isRepondSuggestion?.value == 'yes' || this.feedbackType?.value?.split(',')?.includes(this.feedbackTypeList[2]) && selectedIsRepondCompliment == 'yes') {
        this.showFormControl(this.form, 'onBehalf');
      } else {
        this.hideFormControl(this.form, 'onBehalf');
      }
    });
    this.onBehalfSubscription = this.onBehalf.valueChanges.subscribe(selectedOnBehalf => {
      if (!selectedOnBehalf) {
        this.hideFormControl(this.form, 'firstName');
        this.hideFormControl(this.form, 'lastName');
        this.hideFormControl(this.form, 'sin');
        this.hideFormControl(this.form, 'otherAccntNum');
        this.hideFormControl(this.form, 'businessName');
        this.hideFormControl(this.form, 'businessNum');
        this.hideFormControl(this.form, 'isCanada');
        this.hideFormControl(this.form, 'mailingAddress');
        this.hideFormControl(this.form, 'city');
        this.hideFormControl(this.form, 'country');
        this.hideFormControl(this.form, 'province');
        this.hideFormControl(this.form, 'postalCode');
        this.hideFormControl(this.form, 'mainPhone');
        this.hideFormControl(this.form, 'altPhone');
        this.hideFormControl(this.form, 'isSINorOtherAccountNum');
        this.showHideRepInfo(false);
      } else {
        this.showFormControl(this.form, 'isCanada');
        this.showFormControl(this.form, 'mailingAddress');
        this.showFormControl(this.form, 'city');
        this.showFormControl(this.form, 'mainPhone');
        this.showFormControl(this.form, 'altPhone');
      }
      if (selectedOnBehalf && selectedOnBehalf == this.onBehalfList[0]) {
        this.showFormControl(this.form, 'firstName');
        this.firstName.setValidators([_angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.maxLength(25), this.noNumbersValidator(), this.noSpecialCharsbutFrenchHyphenValidator()]);
        this.showFormControl(this.form, 'lastName');
        this.lastName.setValidators([_angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.maxLength(25), this.noNumbersValidator(), this.noSpecialCharsbutFrenchHyphenValidator()]);
        this.showFormControl(this.form, 'isSINorOtherAccountNum');
        if (!this.isSINorOtherAccountNum?.value) {
          this.hideFormControl(this.form, 'sin');
          this.hideFormControl(this.form, 'otherAccntNum');
        } else if (this.isSINorOtherAccountNum?.value == this.isSINorOtherAccountNumList[0]) {
          this.showFormControl(this.form, 'sin');
          this.hideFormControl(this.form, 'otherAccntNum');
        } else if (this.isSINorOtherAccountNum?.value == this.isSINorOtherAccountNumList[1]) {
          this.hideFormControl(this.form, 'sin');
          this.showFormControl(this.form, 'otherAccntNum');
        }
        this.hideFormControl(this.form, 'businessName');
        this.hideFormControl(this.form, 'businessNum');
        this.showHideRepInfo(false);
      } else if (selectedOnBehalf && selectedOnBehalf == this.onBehalfList[1]) {
        this.showFormControl(this.form, 'firstName');
        this.firstName.setValidators([_angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.maxLength(25), this.noNumbersValidator(), this.noSpecialCharsbutFrenchHyphenValidator()]);
        this.showFormControl(this.form, 'lastName');
        this.lastName.setValidators([_angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.maxLength(25), this.noNumbersValidator(), this.noSpecialCharsbutFrenchHyphenValidator()]);
        this.hideFormControl(this.form, 'sin');
        this.hideFormControl(this.form, 'otherAccntNum');
        this.hideFormControl(this.form, 'isSINorOtherAccountNum');
        this.showFormControl(this.form, 'businessName');
        this.showFormControl(this.form, 'businessNum');
        this.showHideRepInfo(false);
      } else if (selectedOnBehalf && selectedOnBehalf == this.onBehalfList[2]) {
        this.hideFormControl(this.form, 'firstName');
        this.hideFormControl(this.form, 'lastName');
        this.hideFormControl(this.form, 'sin');
        this.hideFormControl(this.form, 'otherAccntNum');
        this.hideFormControl(this.form, 'isSINorOtherAccountNum');
        this.hideFormControl(this.form, 'businessName');
        this.hideFormControl(this.form, 'businessNum');
        this.showHideRepInfo(true);
      }
      this.firstName?.updateValueAndValidity();
      this.lastName?.updateValueAndValidity();
      this.sin?.updateValueAndValidity();
      this.otherAccntNum?.updateValueAndValidity();
      this.businessName?.updateValueAndValidity();
      this.businessNum?.updateValueAndValidity();
      this.isSINorOtherAccountNum?.updateValueAndValidity();
    });
    this.isIndividualOrBusinessSubscription = this.isIndividualOrBusiness?.valueChanges?.subscribe(isIndividualOrBusiness => {
      if (!isIndividualOrBusiness && this.onBehalf.value == this.onBehalfList[2]) {
        this.hideFormControl(this.form, 'firstName');
        this.hideFormControl(this.form, 'lastName');
        this.hideFormControl(this.form, 'sin');
        this.hideFormControl(this.form, 'otherAccntNum');
        this.hideFormControl(this.form, 'isSINorOtherAccountNum');
        this.hideFormControl(this.form, 'businessName');
        this.hideFormControl(this.form, 'businessNum');
      } else if (isIndividualOrBusiness == this.isIndividualOrBusinessList[0]) {
        this.showFormControl(this.form, 'firstName');
        this.firstName.setValidators([_angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.maxLength(25), this.noNumbersValidator(), this.noSpecialCharsbutFrenchHyphenValidator()]);
        this.showFormControl(this.form, 'lastName');
        this.lastName.setValidators([_angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.maxLength(25), this.noNumbersValidator(), this.noSpecialCharsbutFrenchHyphenValidator()]);
        this.hideFormControl(this.form, 'sin');
        this.hideFormControl(this.form, 'otherAccntNum');
        this.showFormControl(this.form, 'isSINorOtherAccountNum');
        this.hideFormControl(this.form, 'businessName');
        this.hideFormControl(this.form, 'businessNum');
      } else if (isIndividualOrBusiness == this.isIndividualOrBusinessList[1]) {
        this.hideFormControl(this.form, 'firstName');
        this.hideFormControl(this.form, 'lastName');
        this.hideFormControl(this.form, 'sin');
        this.hideFormControl(this.form, 'otherAccntNum');
        this.hideFormControl(this.form, 'isSINorOtherAccountNum');
        this.showFormControl(this.form, 'businessName');
        this.showFormControl(this.form, 'businessNum');
      }
      this.firstName?.updateValueAndValidity();
      this.lastName?.updateValueAndValidity();
      this.sin?.updateValueAndValidity();
      this.otherAccntNum?.updateValueAndValidity();
      this.businessName?.updateValueAndValidity();
      this.businessNum?.updateValueAndValidity();
      this.isSINorOtherAccountNum?.updateValueAndValidity();
    });
    this.isSINorOtherAccountNumSubscription = this.isSINorOtherAccountNum?.valueChanges?.subscribe(isSINorOtherAccountNum => {
      if (!isSINorOtherAccountNum) {
        this.hideFormControl(this.form, 'sin');
        this.hideFormControl(this.form, 'otherAccntNum');
      } else if (isSINorOtherAccountNum == this.isSINorOtherAccountNumList[0]) {
        this.showFormControl(this.form, 'sin');
        this.hideFormControl(this.form, 'otherAccntNum');
      } else if (isSINorOtherAccountNum == this.isSINorOtherAccountNumList[1]) {
        this.hideFormControl(this.form, 'sin');
        this.showFormControl(this.form, 'otherAccntNum');
      }
      this.sin?.updateValueAndValidity();
      this.otherAccntNum?.updateValueAndValidity();
    });
    this.postalCodeCASubscription = this.postalCode?.valueChanges?.subscribe(postalCodeCA => {
      if (postalCodeCA && this.isCanada.value == this.isCanadaList[0] && postalCodeCA.length == 6 && !postalCodeCA.includes(" ")) {
        const data = postalCodeCA.substring(0, postalCodeCA.length - 3) + ' ' + postalCodeCA.substring(postalCodeCA.length - 3);
        this.form.get('postalCode').patchValue(data, {
          emitEvent: false
        });
      }
    });
    this.repPostalCodeCASubscription = this.repPostalCode?.valueChanges?.subscribe(repPostalCodeCA => {
      if (repPostalCodeCA && this.repIsCanada.value == this.isCanadaList[0] && repPostalCodeCA.length == 6 && !repPostalCodeCA.includes(" ")) {
        const data = repPostalCodeCA.substring(0, repPostalCodeCA.length - 3) + ' ' + repPostalCodeCA.substring(repPostalCodeCA.length - 3);
        this.form.get('repPostalCode').patchValue(data, {
          emitEvent: false
        });
      }
    });
    this.isCanadaSubscription = this.isCanada.valueChanges.subscribe(selectedIsCanada => {
      if (selectedIsCanada == null || selectedIsCanada.length == 0) {
        this.hideFormControl(this.form, 'country');
        this.hideFormControl(this.form, 'province');
        this.hideFormControl(this.form, 'postalCode');
        this.postalCode?.setValidators([]);
      } else if (selectedIsCanada == this.isCanadaList[0]) {
        this.hideFormControl(this.form, 'country');
        this.showFormControl(this.form, 'province');
        this.showFormControl(this.form, 'postalCode');
        this.postalCode?.setValidators([_angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.maxLength(7), this.postalCodeCanadaValidator()]);
      } else if (selectedIsCanada == this.isCanadaList[1]) {
        this.hideFormControl(this.form, 'province');
        this.showFormControl(this.form, 'country');
        this.showFormControl(this.form, 'postalCode');
        this.postalCode?.setValidators([_angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.maxLength(20), this.postalCodeOutsideCanadaValidator()]);
      }
      this.postalCode?.updateValueAndValidity();
    });
    this.repIsCanadaSubscription = this.repIsCanada.valueChanges.subscribe(selectedrepIsCanada => {
      if (selectedrepIsCanada == null || selectedrepIsCanada.length == 0) {
        this.hideFormControl(this.form, 'repCountry');
        this.hideFormControl(this.form, 'repProvince');
        this.hideFormControl(this.form, 'repPostalCode');
        this.repPostalCode?.setValidators([]);
      } else if (selectedrepIsCanada == this.isCanadaList[0]) {
        this.hideFormControl(this.form, 'repCountry');
        this.showFormControl(this.form, 'repProvince');
        this.showFormControl(this.form, 'repPostalCode');
        this.repPostalCode?.setValidators([_angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.maxLength(7), this.postalCodeCanadaValidator()]);
      } else if (selectedrepIsCanada == this.isCanadaList[1]) {
        this.hideFormControl(this.form, 'repProvince');
        this.showFormControl(this.form, 'repCountry');
        this.showFormControl(this.form, 'repPostalCode');
        this.repPostalCode?.setValidators([_angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.Validators.maxLength(20), this.postalCodeOutsideCanadaValidator()]);
      }
      this.repPostalCode?.updateValueAndValidity();
    });
  }
  getSortFeedbackType(selectedFeedbackType) {
    if (!selectedFeedbackType) {
      return selectedFeedbackType;
    }
    const previouFeedbackType = selectedFeedbackType.split(",");
    let newFeedbackTypeArray = previouFeedbackType.sort(function (a, b) {
      return this.feedbackTypeList.indexOf(a) - this.feedbackTypeList.indexOf(b);
    });
    return newFeedbackTypeArray.join(',');
  }
  showHideRepInfo(isDisplay) {
    if (isDisplay) {
      this.showFormControl(this.form, 'repFirstName');
      this.showFormControl(this.form, 'repLastName');
      this.showFormControl(this.form, 'repBusinessName');
      this.showFormControl(this.form, 'repBusinessNum');
      this.showFormControl(this.form, 'repNum');
      this.showFormControl(this.form, 'repIsCanada');
      this.showFormControl(this.form, 'repMailingAddress');
      this.showFormControl(this.form, 'repCity');
      this.showFormControl(this.form, 'repMainPhone');
      this.showFormControl(this.form, 'isIndividualOrBusiness');
    } else {
      this.hideFormControl(this.form, 'repFirstName');
      this.hideFormControl(this.form, 'repLastName');
      this.hideFormControl(this.form, 'repBusinessName');
      this.hideFormControl(this.form, 'repBusinessNum');
      this.hideFormControl(this.form, 'repNum');
      this.hideFormControl(this.form, 'repIsCanada');
      this.hideFormControl(this.form, 'repMailingAddress');
      this.hideFormControl(this.form, 'repCity');
      this.hideFormControl(this.form, 'repMainPhone');
      this.hideFormControl(this.form, 'isIndividualOrBusiness');
    }
  }
  sinValidator() {
    return control => {
      if (control?.value) {
        const valid = control.value.match('^[0-9]{9}$');
        return !valid ? {
          error_enter_ident: {
            value: control.value
          }
        } : null;
      }
      return null;
    };
  }
  otherAccntNumValidator() {
    return control => {
      if (control?.value) {
        const valid = control.value.match('^[a-zA-Z0-9]+$');
        return !valid ? {
          error_no_specialChar: {
            value: control.value
          }
        } : null;
      }
      return null;
    };
  }
  noLetterValidator() {
    return control => {
      if (control?.value) {
        const invalid = control.value.match('.*[a-zA-Z].*');
        return invalid ? {
          error_no_letter: {
            value: control.value
          }
        } : null;
      }
      return null;
    };
  }
  phoneValidator() {
    return control => {
      if (control?.value) {
        const valid = control.value.match('^[A-Za-z\\d]+$');
        return !valid ? {
          error_no_specialChar: {
            value: control.value
          }
        } : null;
      }
      return null;
    };
  }
  postalCodeOutsideCanadaValidator() {
    return control => {
      if (control?.value) {
        const valid = control.value.match('^[A-Za-z\\d\\u0020]+$');
        return !valid ? {
          error_no_specialChar: {
            value: control.value
          }
        } : null;
      }
      return null;
    };
  }
  postalCodeCanadaValidator() {
    return control => {
      if (control?.value) {
        const valid = control.value.match('^[A-Za-z][0-9][A-Za-z][ ][0-9][A-Za-z][0-9]$');
        return !valid ? {
          error_wrong_canadaPostalCode: {
            value: control.value
          }
        } : null;
      }
      return null;
    };
  }
  noNumbersValidator() {
    return control => {
      if (control?.value) {
        const invalid = control.value.match('.*[0-9].*');
        return invalid ? {
          error_no_numbers: {
            value: control.value
          }
        } : null;
      }
      return null;
    };
  }
  noSpecialCharsbutFrenchHyphenValidator() {
    return control => {
      if (control?.value) {
        const valid = control.value.match('^[A-Za-z\\d\\u0020\\u002D\\u00E0\\u00E2\\u00E7\\u00E8\\u00E9\\u00EA\\u00EB\\u00EE\\u00EF\\u00F4\\u00F6\\u00F9\\u00FB\\u00FC\\u00C0\\u00C2\\u00C7\\u00C8\\u00C9\\u00CA\\u00CB\\u00CE\\u00CF\\u00D4\\u00D6\\u00D9\\u00DB\\u00DC\\u0027\\u2019]+$');
        return !valid ? {
          error_no_specialChar: {
            value: control.value
          }
        } : null;
      }
      return null;
    };
  }
  mailingAddressValidator() {
    return control => {
      if (control?.value) {
        const valid = control.value.match('^[A-Za-z\\d\\u0020\\u002D\\u0023\\u002C\\u002E\\u00E0\\u00E2\\u00E7\\u00E8\\u00E9\\u00EA\\u00EB\\u00EE\\u00EF\\u00F4\\u00F6\\u00F9\\u00FB\\u00FC\\u00C0\\u00C2\\u00C7\\u00C8\\u00C9\\u00CA\\u00CB\\u00CE\\u00CF\\u00D4\\u00D6\\u00D9\\u00DB\\u00DC\\u0027\\u2019]+$');
        return !valid ? {
          error_no_specialChar: {
            value: control.value
          }
        } : null;
      }
      return null;
    };
  }
  businessNumValidator() {
    return control => {
      if (control?.value) {
        const valid = control.value.match('^\\d{9}([A-Za-z]{2})(\\d{4})$');
        return !valid ? {
          error_wrong_bn: {
            value: control.value
          }
        } : null;
      }
      return null;
    };
  }
  repNumValidator() {
    return control => {
      if (control?.value) {
        const valid = control.value.match('^[A-Za-z0-9]{7}$');
        return !valid ? {
          error_wrong_repNum: {
            value: control.value
          }
        } : null;
      }
      return null;
    };
  }
  ngOnDestroy() {
    this.feedBackTypeSubscription?.unsubscribe();
    this.onBehalfSubscription?.unsubscribe();
    this.isIndividualOrBusinessSubscription?.unsubscribe();
    this.isSINorOtherAccountNumSubscription?.unsubscribe();
    this.postalCodeCASubscription?.unsubscribe();
    this.repPostalCodeCASubscription?.unsubscribe();
    this.isCanadaSubscription?.unsubscribe();
    this.repIsCanadaSubscription?.unsubscribe();
    this.isRepondSuggestionSubscription?.unsubscribe();
    this.isRepondComplimentSubscription?.unsubscribe();
  }
  submit() {
    src_app_util_AppFormHelper__WEBPACK_IMPORTED_MODULE_2__.AppFormHelper.trimInputFields([this.firstName, this.lastName, this.businessName, this.mailingAddress, this.city, this.country, this.postalCode, this.repFirstName, this.repLastName, this.repBusinessName, this.repMailingAddress, this.repCity, this.repCountry, this.repPostalCode]);
    src_app_util_AppFormHelper__WEBPACK_IMPORTED_MODULE_2__.AppFormHelper.convertApostropheAndTabFields([this.firstName, this.lastName, this.mailingAddress, this.city, this.country, this.repFirstName, this.repLastName, this.repMailingAddress, this.repCity, this.repCountry]);
    if (this.form.invalid) {
      (0,_cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_15__.revealAllErrors)(this.form);
      this.focusService.requestFocus(src_app_app_component__WEBPACK_IMPORTED_MODULE_1__.ERROR_HEADER_ID);
    } else {
      this.infoService.generalInfo.next(this.buildgeneralInfoNext());
      if (this.feedbackType?.value.includes(this.feedbackTypeList[0])) {
        this.infoService.complaint.value.canActive = true;
        this.router.navigateByUrl('/complaint');
      } else if (this.feedbackType?.value.includes(this.feedbackTypeList[1])) {
        this.infoService.suggestion.value.canActive = true;
        this.router.navigateByUrl('/suggestion');
      } else if (this.feedbackType?.value.includes(this.feedbackTypeList[2])) {
        this.infoService.compliment.value.canActive = true;
        this.router.navigateByUrl('/compliment');
      }
    }
  }
  get feedbackType() {
    return this.form.get('feedbackType');
  }
  get isRepondSuggestion() {
    return this.form.get('isRepondSuggestion');
  }
  get isRepondCompliment() {
    return this.form.get('isRepondCompliment');
  }
  get onBehalf() {
    return this.form.get('onBehalf');
  }
  get isIndividualOrBusiness() {
    return this.form.get('isIndividualOrBusiness');
  }
  get isSINorOtherAccountNum() {
    return this.form.get('isSINorOtherAccountNum');
  }
  get firstName() {
    return this.form.get('firstName');
  }
  get lastName() {
    return this.form.get('lastName');
  }
  get businessName() {
    return this.form.get('businessName');
  }
  get businessNum() {
    return this.form.get('businessNum');
  }
  get sin() {
    return this.form.get('sin');
  }
  get otherAccntNum() {
    return this.form.get('otherAccntNum');
  }
  get isCanada() {
    return this.form.get('isCanada');
  }
  get country() {
    return this.form.get('country');
  }
  get mailingAddress() {
    return this.form.get('mailingAddress');
  }
  get city() {
    return this.form.get('city');
  }
  get province() {
    return this.form.get('province');
  }
  get postalCode() {
    return this.form.get('postalCode');
  }
  get mainPhone() {
    return this.form.get('mainPhone');
  }
  get altPhone() {
    return this.form.get('altPhone');
  }
  get repFirstName() {
    return this.form.get('repFirstName');
  }
  get repLastName() {
    return this.form.get('repLastName');
  }
  get repBusinessName() {
    return this.form.get('repBusinessName');
  }
  get repBusinessNum() {
    return this.form.get('repBusinessNum');
  }
  get repIsCanada() {
    return this.form.get('repIsCanada');
  }
  get repNum() {
    return this.form.get('repNum');
  }
  get repCountry() {
    return this.form.get('repCountry');
  }
  get repMailingAddress() {
    return this.form.get('repMailingAddress');
  }
  get repCity() {
    return this.form.get('repCity');
  }
  get repProvince() {
    return this.form.get('repProvince');
  }
  get repPostalCode() {
    return this.form.get('repPostalCode');
  }
  get repMainPhone() {
    return this.form.get('repMainPhone');
  }
  buildgeneralInfoNext() {
    this.generalInfoNext = new src_app_model_generalInformation__WEBPACK_IMPORTED_MODULE_0__.GeneralInformation();
    this.generalInfoNext.feedbackType = this.feedbackType.value ?? '';
    this.generalInfoNext.isRepondSuggestion = this.isRepondSuggestion.value ?? '';
    this.generalInfoNext.isRepondCompliment = this.isRepondCompliment.value ?? '';
    this.generalInfoNext.onBehalf = this.onBehalf.value ?? '';
    this.generalInfoNext.isIndividualOrBusiness = this.isIndividualOrBusiness.value ?? '';
    this.generalInfoNext.firstName = this.firstName.value ?? '';
    this.generalInfoNext.lastName = this.lastName.value ?? '';
    this.generalInfoNext.businessName = this.businessName.value ?? '';
    this.generalInfoNext.businessNum = this.businessNum.value ?? '';
    this.generalInfoNext.isCanada = this.isCanada.value ?? '';
    this.generalInfoNext.country = this.country.value ?? '';
    this.generalInfoNext.mailingAddress = this.mailingAddress.value ?? '';
    this.generalInfoNext.city = this.city.value ?? '';
    this.generalInfoNext.province = this.province.value ?? '';
    this.generalInfoNext.postalCode = this.postalCode.value ?? '';
    this.generalInfoNext.mainPhone = this.mainPhone.value ?? '';
    this.generalInfoNext.altPhone = this.altPhone.value ?? '';
    this.generalInfoNext.isSINorOtherAccountNum = this.isSINorOtherAccountNum.value ?? '';
    this.generalInfoNext.sin = this.sin.value ?? '';
    this.generalInfoNext.otherAccntNum = this.otherAccntNum.value ?? '';
    this.generalInfoNext.repFirstName = this.repFirstName.value ?? '';
    this.generalInfoNext.repLastName = this.repLastName.value ?? '';
    this.generalInfoNext.repBusinessName = this.repBusinessName.value ?? '';
    this.generalInfoNext.repBusinessNum = this.repBusinessNum.value ?? '';
    this.generalInfoNext.repMailingAddress = this.repMailingAddress.value ?? '';
    this.generalInfoNext.repCity = this.repCity.value ?? '';
    this.generalInfoNext.repProvince = this.repProvince.value ?? '';
    this.generalInfoNext.repNum = this.repNum.value ?? '';
    this.generalInfoNext.repIsCanada = this.repIsCanada.value ?? '';
    this.generalInfoNext.repCountry = this.repCountry.value ?? '';
    this.generalInfoNext.repPostalCode = this.repPostalCode.value ?? '';
    this.generalInfoNext.repMainPhone = this.repMainPhone.value ?? '';
    return this.generalInfoNext;
  }
  previous() {
    return '/entry';
  }
  showFormControl(form, control) {
    form.get(control).enable();
  }
  hideFormControl(form, control) {
    form.get(control).reset();
    form.get(control).disable();
  }
  enableIsRepondSuggestion() {
    if (this.generalInfo.feedbackType != null && this.generalInfo.feedbackType?.split(',')?.includes(this.feedbackTypeList[1])) {
      return true;
    }
    return false;
  }
  enableIsRepondCompliment() {
    if (this.generalInfo.feedbackType != null && this.generalInfo.feedbackType?.split(',')?.includes(this.feedbackTypeList[2])) {
      return true;
    }
    return false;
  }
  enableOnBehalf() {
    if (this.generalInfo.feedbackType != null && this.generalInfo.feedbackType?.split(',')?.includes(this.feedbackTypeList[0])) {
      return true;
    } else if (this.generalInfo.feedbackType != null && (this.generalInfo.feedbackType?.split(',')?.includes(this.feedbackTypeList[1]) && this.generalInfo.isRepondSuggestion == 'yes' || this.generalInfo.feedbackType?.split(',')?.includes(this.feedbackTypeList[2]) && this.generalInfo.isRepondCompliment == 'yes')) {
      return true;
    }
    return false;
  }
  enableFirstLastNameInfo() {
    if (this.generalInfo?.onBehalf != null && this.generalInfo.onBehalf?.split(',')?.includes(this.onBehalfList[0])) {
      return true;
    } else if (this.generalInfo?.onBehalf != null && this.generalInfo.onBehalf?.split(',')?.includes(this.onBehalfList[1])) {
      return true;
    } else if (this.generalInfo?.onBehalf != null && this.generalInfo.onBehalf?.split(',')?.includes(this.onBehalfList[2]) && this.generalInfo?.isIndividualOrBusiness == this.isIndividualOrBusinessList[0]) {
      return true;
    }
    return false;
  }
  enableIsSINorOtherAccountNum() {
    if (this.generalInfo?.onBehalf != null && this.generalInfo.onBehalf?.split(',')?.includes(this.onBehalfList[0])) {
      return true;
    } else if (this.generalInfo?.onBehalf != null && this.generalInfo.onBehalf?.split(',')?.includes(this.onBehalfList[1])) {
      return false;
    } else if (this.generalInfo?.onBehalf != null && this.generalInfo.onBehalf?.split(',')?.includes(this.onBehalfList[2]) && this.generalInfo?.isIndividualOrBusiness == this.isIndividualOrBusinessList[0]) {
      return true;
    }
    return false;
  }
  requireFirstLastNameInfo() {
    if (this.onBehalf != null && this.onBehalf?.value.split(',')?.includes(this.onBehalfList[0])) {
      return true;
    } else if (this.onBehalf != null && this.onBehalf?.value.split(',')?.includes(this.onBehalfList[1])) {
      return false;
    } else if (this.onBehalf != null && this.onBehalf?.value.split(',')?.includes(this.onBehalfList[2]) && this.isIndividualOrBusiness.value == this.isIndividualOrBusinessList[0]) {
      return true;
    }
    return false;
  }
  enableCommonInfo() {
    if (this.generalInfo?.onBehalf != null && this.generalInfo?.onBehalf != '') {
      return true;
    }
    return false;
  }
  enableSIN() {
    if (this.generalInfo?.isSINorOtherAccountNum != null && this.generalInfo?.isSINorOtherAccountNum == this.isSINorOtherAccountNumList[0]) {
      return true;
    }
    return false;
  }
  enableOtherAccntNum() {
    if (this.generalInfo?.isSINorOtherAccountNum != null && this.generalInfo?.isSINorOtherAccountNum == this.isSINorOtherAccountNumList[1]) {
      return true;
    }
    return false;
  }
  enableBusinessInfo() {
    if (this.generalInfo?.feedbackType != null && this.generalInfo?.onBehalf?.split(',')?.includes(this.onBehalfList[1])) {
      return true;
    } else if (this.generalInfo.feedbackType != null && this.generalInfo?.onBehalf?.split(',')?.includes(this.onBehalfList[2]) && this.generalInfo?.isIndividualOrBusiness == this.isIndividualOrBusinessList[1]) {
      return true;
    }
    return false;
  }
  enableRepInfo() {
    if (this.generalInfo?.onBehalf != null && this.generalInfo?.onBehalf == this.onBehalfList[2]) {
      return true;
    }
    return false;
  }
  enableProvince() {
    if (this.generalInfo?.isCanada == this.isCanadaList[0]) {
      return true;
    }
    return false;
  }
  enableCountry() {
    if (this.generalInfo?.isCanada == this.isCanadaList[1]) {
      return true;
    }
    return false;
  }
  enableRepProvince() {
    if (this.generalInfo.repIsCanada == this.isCanadaList[0]) {
      return true;
    }
    return false;
  }
  enableRepCountry() {
    if (this.generalInfo.repIsCanada == this.isCanadaList[1]) {
      return true;
    }
    return false;
  }
  enablePostalCode() {
    if (this.generalInfo.isCanada != null && this.generalInfo.isCanada?.length != 0) {
      return true;
    }
    return false;
  }
  enableRepPostalCode() {
    if (this.generalInfo.repIsCanada != null && this.generalInfo.repIsCanada?.length != 0) {
      return true;
    }
    return false;
  }
}
GeneralInformationComponent.ɵfac = function GeneralInformationComponent_Factory(t) {
  return new (t || GeneralInformationComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_14__.UntypedFormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](src_app_services_result_result_service__WEBPACK_IMPORTED_MODULE_4__.ResultService), _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_16__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](src_app_services_validation_validation_service__WEBPACK_IMPORTED_MODULE_5__.ValidationService), _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](_cra_arc_rccr_core__WEBPACK_IMPORTED_MODULE_17__.FocusService), _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_18__.TranslateService), _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](_cra_arc_rccr_core__WEBPACK_IMPORTED_MODULE_17__.WindowService), _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](_angular_platform_browser__WEBPACK_IMPORTED_MODULE_19__.Meta));
};
GeneralInformationComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdefineComponent"]({
  type: GeneralInformationComponent,
  selectors: [["app-general-information"]],
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵInheritDefinitionFeature"]],
  decls: 12,
  vars: 15,
  consts: [["translate", "", 3, "pageHeading"], ["autocomplete", "off", 3, "formGroup", "ngSubmit"], [3, "form", "id"], ["translate", "", 3, "legendKey", "form", "controlName", "checkBoxList"], [4, "ngIf"], ["controlName", "onBehalf", "legendKey", "genInfo.submitOnBehalf", "translate", "", 3, "form", "required", "containsMarkup", "helpAccessibleTextKey", "inlineHelpKey", 4, "ngIf"], ["class", "mrgn-tp-lg solid-line", 4, "ngIf"], [3, "back"], [3, "screenId"], ["legendKey", "genInfo.respondSuggestion", "controlName", "isRepondSuggestion", 3, "id", "form", "required", "containsMarkup"], ["ngDefaultControl", "", 3, "form", "formControlName", "id", "value"], ["legendKey", "genInfo.respondCompliment", "controlName", "isRepondCompliment", 3, "id", "form", "required", "containsMarkup"], ["controlName", "onBehalf", "legendKey", "genInfo.submitOnBehalf", "translate", "", 3, "form", "required", "containsMarkup", "helpAccessibleTextKey", "inlineHelpKey"], ["ngDefaultControl", "", 1, "iconButton", 3, "form", "formControlName", "value"], [2, "text-align", "left"], [2, "font-size", "32px", "padding", "12px"], [1, "fas", "fa-user"], [2, "font-size", "32px", "padding", "10px"], [1, "fas", "fa-briefcase"], [2, "font-size", "32px", "padding", "6px"], [1, "fas", "fa-users"], [1, "mrgn-tp-lg", "solid-line"], [1, "mrgn-bttm-sm", "legendTitle"], ["class", "row", 4, "ngIf"], [1, "row"], ["class", "col-lg-6 col-md-6 col-sm-12", 4, "ngIf"], [3, "form", "containsMarkup", "controlName", "id", "legendKey", "required"], ["formControlName", "isIndividualOrBusiness", 3, "id", "value"], [1, "col-lg-6", "col-md-6", "col-sm-12"], [3, "form", "formControlName", "required", "labelKey", "labelContainsMarkup", "attributes"], ["formControlName", "isSINorOtherAccountNum", 3, "id", "value"], ["classes", "mrgn-tp-sm", 3, "form", "formControlName", "required", "labelKey", "labelContainsMarkup", "attributes"], ["formControlName", "isCanada", 3, "id", "value"], [3, "form", "labelKey", "selectList", "selectLocal"], [3, "form", "formControlName", "required", "labelKey", "labelContainsMarkup", "attributes", 4, "ngIf"], ["classes", "mrgn-tp-sm", 3, "form", "formControlName", "required", "labelKey", "labelContainsMarkup", "attributes", 4, "ngIf"], ["formControlName", "repIsCanada", 3, "id", "value"]],
  template: function GeneralInformationComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](0, "app-page-heading-local", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](1, "form", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("ngSubmit", function GeneralInformationComponent_Template_form_ngSubmit_1_listener() {
        return ctx.submit();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](2, "rccr-error-aggregator", 2)(3, "denotes-required")(4, "app-multiselect-button-group", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](5, GeneralInformationComponent_div_5_Template, 9, 18, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](6, GeneralInformationComponent_div_6_Template, 9, 18, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](7, GeneralInformationComponent_rccr_button_group_7_Template, 24, 28, "rccr-button-group", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](8, GeneralInformationComponent_div_8_Template, 14, 10, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtemplate"](9, GeneralInformationComponent_div_9_Template, 17, 33, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](10, "app-back-next-buttongroup", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](11, "app-page-details-local", 8);
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("pageHeading", "genInfo.title");
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("formGroup", ctx.form);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("form", ctx.form)("id", "errorHeader");
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("legendKey", "genInfo.selectFeedbackType")("form", ctx.form)("controlName", "feedbackType")("checkBoxList", ctx.feedbackTypeList);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngIf", ctx.isRepondSuggestion.enabled);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngIf", ctx.isRepondCompliment.enabled);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngIf", ctx.onBehalf.enabled);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngIf", ctx.isCanada == null ? null : ctx.isCanada.enabled);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("ngIf", ctx.repFirstName.enabled);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("back", ctx.previous());
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("screenId", "UISP-RC193-GENERALINFO");
    }
  },
  dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_20__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_14__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_14__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.RequiredValidator, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.FormControlName, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_18__.TranslateDirective, _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_15__.TextInputComponent, _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_15__.ErrorAggregatorComponent, _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_15__.ButtonGroupComponent, _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_15__.RadioButtonComponent, _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_15__.ButtonToggleComponent, _templates_back_next_buttongroup_back_next_buttongroup_component__WEBPACK_IMPORTED_MODULE_6__.BackNextButtongroupComponent, _templates_select_local_select_local_component__WEBPACK_IMPORTED_MODULE_7__.SelectLocalComponent, _templates_page_heading_local_page_heading_local_component__WEBPACK_IMPORTED_MODULE_8__.PageHeadingLocalComponent, _templates_page_details_local_page_details_local_component__WEBPACK_IMPORTED_MODULE_9__.PageDetailsLocalComponent, _templates_multiselect_button_group_multiselect_button_group_component__WEBPACK_IMPORTED_MODULE_10__.MultiselectButtonGroupComponent, _templates_denotes_required_denotes_required_component__WEBPACK_IMPORTED_MODULE_11__.DenotesRequiredComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_18__.TranslatePipe],
  styles: [".solid-line[_ngcontent-%COMP%]{\n    border-top: solid 1px;\n    border-top-color: slategray;\n}\n\n.legendTitle[_ngcontent-%COMP%]{\n    font-weight: 700;\n    font-size: 20px;\n}\n\n.iconButton[_ngcontent-%COMP%]{\n    display: block;\n}\n\nfieldset[_ngcontent-%COMP%]{\n    display: flex;\n    flex-direction: column;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29tcG9uZW50cy9nZW5lcmFsLWluZm9ybWF0aW9uL2dlbmVyYWwtaW5mb3JtYXRpb24uY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLHFCQUFxQjtJQUNyQiwyQkFBMkI7QUFDL0I7O0FBRUE7SUFDSSxnQkFBZ0I7SUFDaEIsZUFBZTtBQUNuQjs7QUFFQTtJQUNJLGNBQWM7QUFDbEI7O0FBRUE7SUFDSSxhQUFhO0lBQ2Isc0JBQXNCO0FBQzFCIiwic291cmNlc0NvbnRlbnQiOlsiLnNvbGlkLWxpbmV7XHJcbiAgICBib3JkZXItdG9wOiBzb2xpZCAxcHg7XHJcbiAgICBib3JkZXItdG9wLWNvbG9yOiBzbGF0ZWdyYXk7XHJcbn1cclxuXHJcbi5sZWdlbmRUaXRsZXtcclxuICAgIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbiAgICBmb250LXNpemU6IDIwcHg7XHJcbn1cclxuXHJcbi5pY29uQnV0dG9ue1xyXG4gICAgZGlzcGxheTogYmxvY2s7XHJcbn1cclxuXHJcbmZpZWxkc2V0e1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbn0iXSwic291cmNlUm9vdCI6IiJ9 */", "/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
});

/***/ }),

/***/ 3806:
/*!*******************************************************!*\
  !*** ./src/app/components/review/review.component.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ReviewComponent: () => (/* binding */ ReviewComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/forms */ 8849);
/* harmony import */ var src_app_model_review__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/model/review */ 2127);
/* harmony import */ var _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @cra-arc/rccr-wet */ 399);
/* harmony import */ var src_app_app_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/app.component */ 6401);
/* harmony import */ var src_app_app_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/app-routing.module */ 3966);
/* harmony import */ var src_app_model_submission__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/model/submission */ 9027);
/* harmony import */ var _base__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../base */ 6608);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var src_app_services_result_result_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/result/result.service */ 1392);
/* harmony import */ var _cra_arc_rccr_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @cra-arc/rccr-core */ 838);
/* harmony import */ var src_app_services_app_submission_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/app-submission.service */ 2722);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/router */ 7947);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @ngx-translate/core */ 5939);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/platform-browser */ 6480);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/common */ 6575);
/* harmony import */ var _templates_back_next_buttongroup_back_next_buttongroup_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../templates/back-next-buttongroup/back-next-buttongroup.component */ 672);
/* harmony import */ var _templates_page_details_local_page_details_local_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../templates/page-details-local/page-details-local.component */ 9704);
/* harmony import */ var _templates_denotes_required_denotes_required_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../templates/denotes-required/denotes-required.component */ 1284);
/* harmony import */ var _templates_captcha_app_review_captcha_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../templates/captcha/app-review-captcha.component */ 4831);





















function ReviewComponent_section_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "section", 8)(1, "h2", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](2, "error.header");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](3, "p", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("rccrFocusable", ctx_r0.formErrorHeaderId);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵattribute"]("id", ctx_r0.formErrorHeaderId);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("innerHTML", ctx_r0.reviewFormErrorMessage, _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵsanitizeHtml"]);
  }
}
function ReviewComponent_div_6_dt_28_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 1, "genInfo.sin"));
  }
}
function ReviewComponent_div_6_dd_29_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r8.generalInfo.sin);
  }
}
function ReviewComponent_div_6_dt_30_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 1, "genInfo.otherAccntNum"));
  }
}
function ReviewComponent_div_6_dd_31_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r10.generalInfo.otherAccntNum);
  }
}
function ReviewComponent_div_6_dt_32_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 1, "genInfo.isCanada"));
  }
}
function ReviewComponent_div_6_dd_33_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 1, "genInfo.canada"));
  }
}
function ReviewComponent_div_6_dt_34_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 1, "genInfo.isCanada"));
  }
}
function ReviewComponent_div_6_dd_35_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"]("", ctx_r14.generalInfo.country, " ");
  }
}
function ReviewComponent_div_6_dt_46_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 1, "genInfo.province"));
  }
}
function ReviewComponent_div_6_dd_47_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 1, ctx_r16.generalInfo.province));
  }
}
function ReviewComponent_div_6_dt_48_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 1, "genInfo.postalCanada"));
  }
}
function ReviewComponent_div_6_dd_49_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r18.generalInfo.postalCode);
  }
}
function ReviewComponent_div_6_dt_50_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 1, "genInfo.postalOutsideCanada"), "");
  }
}
function ReviewComponent_div_6_dd_51_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r20 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r20.generalInfo.postalCode);
  }
}
function ReviewComponent_div_6_dt_57_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 1, "review.altPhone"));
  }
}
function ReviewComponent_div_6_dd_58_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r22 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r22.generalInfo.altPhone);
  }
}
const _c0 = function () {
  return [];
};
function ReviewComponent_div_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r24 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div", 11)(1, "div", 12)(2, "div", 13)(3, "h2", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](5, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](6, "div", 15)(7, "a", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("click", function ReviewComponent_div_6_Template_a_click_7_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵrestoreView"](_r24);
      const ctx_r23 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵresetView"](ctx_r23.setGeneralInfoEdit());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](8, "span", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](9, "span", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](11, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](12, "span", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](13);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](14, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](15, "hr", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](16, "div", 21)(17, "dl", 22)(18, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](19);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](20, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](21, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](22);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](23, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](24);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](25, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](26, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](27);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](28, ReviewComponent_div_6_dt_28_Template, 3, 3, "dt", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](29, ReviewComponent_div_6_dd_29_Template, 2, 1, "dd", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](30, ReviewComponent_div_6_dt_30_Template, 3, 3, "dt", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](31, ReviewComponent_div_6_dd_31_Template, 2, 1, "dd", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](32, ReviewComponent_div_6_dt_32_Template, 3, 3, "dt", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](33, ReviewComponent_div_6_dd_33_Template, 3, 3, "dd", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](34, ReviewComponent_div_6_dt_34_Template, 3, 3, "dt", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](35, ReviewComponent_div_6_dd_35_Template, 2, 1, "dd", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](36, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](37);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](38, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](39, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](40);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](41, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](42);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](43, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](44, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](45);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](46, ReviewComponent_div_6_dt_46_Template, 3, 3, "dt", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](47, ReviewComponent_div_6_dd_47_Template, 3, 3, "dd", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](48, ReviewComponent_div_6_dt_48_Template, 3, 3, "dt", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](49, ReviewComponent_div_6_dd_49_Template, 2, 1, "dd", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](50, ReviewComponent_div_6_dt_50_Template, 3, 3, "dt", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](51, ReviewComponent_div_6_dd_51_Template, 2, 1, "dd", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](52, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](53);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](54, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](55, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](56);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](57, ReviewComponent_div_6_dt_57_Template, 3, 3, "dt", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](58, ReviewComponent_div_6_dd_58_Template, 2, 1, "dd", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](5, 30, "genInfo.IndividualInfo"));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction0"](46, _c0));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](11, 32, "review.edit"));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](14, 34, "review.edit.personal.hidden"));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](20, 36, "genInfo.firstName"));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r1.generalInfo.firstName);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](25, 38, "genInfo.lastName"));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r1.generalInfo.lastName);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r1.generalInfo.sin);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r1.generalInfo.sin);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r1.generalInfo.otherAccntNum);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r1.generalInfo.otherAccntNum);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r1.generalInfo.isCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r1.generalInfo.isCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r1.generalInfo.isCanada === "genInfo.outsideCanada");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r1.generalInfo.isCanada === "genInfo.outsideCanada");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](38, 40, "genInfo.mailingAddress"));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r1.generalInfo.mailingAddress);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](43, 42, "genInfo.city"));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r1.generalInfo.city);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r1.generalInfo.isCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r1.generalInfo.isCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r1.generalInfo.isCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r1.generalInfo.isCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r1.generalInfo.isCanada === "genInfo.outsideCanada");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r1.generalInfo.isCanada === "genInfo.outsideCanada");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](54, 44, "review.phone"));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r1.generalInfo.mainPhone);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r1.generalInfo.altPhone);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r1.generalInfo.altPhone);
  }
}
function ReviewComponent_div_7_dt_18_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 1, "genInfo.firstName"));
  }
}
function ReviewComponent_div_7_dd_19_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r26 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r26.generalInfo.firstName);
  }
}
function ReviewComponent_div_7_dt_20_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 1, "genInfo.lastName"));
  }
}
function ReviewComponent_div_7_dd_21_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r28 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r28.generalInfo.lastName);
  }
}
function ReviewComponent_div_7_dt_32_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 1, "genInfo.isCanada"));
  }
}
function ReviewComponent_div_7_dd_33_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 1, "genInfo.canada"));
  }
}
function ReviewComponent_div_7_dt_34_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 1, "genInfo.isCanada"));
  }
}
function ReviewComponent_div_7_dd_35_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r32 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"]("", ctx_r32.generalInfo.country, " ");
  }
}
function ReviewComponent_div_7_dt_46_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 1, "genInfo.province"));
  }
}
function ReviewComponent_div_7_dd_47_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r34 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 1, ctx_r34.generalInfo.province));
  }
}
function ReviewComponent_div_7_dt_48_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 1, "genInfo.postalCanada"));
  }
}
function ReviewComponent_div_7_dd_49_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r36 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r36.generalInfo.postalCode);
  }
}
function ReviewComponent_div_7_dt_50_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 1, "genInfo.postalOutsideCanada"), "");
  }
}
function ReviewComponent_div_7_dd_51_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r38 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r38.generalInfo.postalCode);
  }
}
function ReviewComponent_div_7_dt_57_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 1, "review.altPhone"));
  }
}
function ReviewComponent_div_7_dd_58_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r40 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r40.generalInfo.altPhone);
  }
}
function ReviewComponent_div_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r42 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div", 11)(1, "div", 12)(2, "div", 13)(3, "h2", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](5, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](6, "div", 15)(7, "a", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("click", function ReviewComponent_div_7_Template_a_click_7_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵrestoreView"](_r42);
      const ctx_r41 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵresetView"](ctx_r41.setGeneralInfoEdit());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](8, "span", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](9, "span", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](11, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](12, "span", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](13);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](14, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](15, "hr", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](16, "div", 21)(17, "dl", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](18, ReviewComponent_div_7_dt_18_Template, 3, 3, "dt", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](19, ReviewComponent_div_7_dd_19_Template, 2, 1, "dd", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](20, ReviewComponent_div_7_dt_20_Template, 3, 3, "dt", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](21, ReviewComponent_div_7_dd_21_Template, 2, 1, "dd", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](22, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](24, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](25, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](26);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](27, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](28);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](29, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](30, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](31);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](32, ReviewComponent_div_7_dt_32_Template, 3, 3, "dt", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](33, ReviewComponent_div_7_dd_33_Template, 3, 3, "dd", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](34, ReviewComponent_div_7_dt_34_Template, 3, 3, "dt", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](35, ReviewComponent_div_7_dd_35_Template, 2, 1, "dd", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](36, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](37);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](38, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](39, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](40);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](41, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](42);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](43, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](44, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](45);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](46, ReviewComponent_div_7_dt_46_Template, 3, 3, "dt", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](47, ReviewComponent_div_7_dd_47_Template, 3, 3, "dd", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](48, ReviewComponent_div_7_dt_48_Template, 3, 3, "dt", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](49, ReviewComponent_div_7_dd_49_Template, 2, 1, "dd", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](50, ReviewComponent_div_7_dt_50_Template, 3, 3, "dt", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](51, ReviewComponent_div_7_dd_51_Template, 2, 1, "dd", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](52, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](53);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](54, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](55, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](56);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](57, ReviewComponent_div_7_dt_57_Template, 3, 3, "dt", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](58, ReviewComponent_div_7_dd_58_Template, 2, 1, "dd", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](5, 30, "genInfo.BusinessInfo"));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction0"](46, _c0));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](11, 32, "review.edit"));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](14, 34, "review.edit.business.hidden"));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.firstName);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.firstName);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.lastName);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.lastName);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](24, 36, "genInfo.businessName"));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r2.generalInfo.businessName);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](29, 38, "genInfo.businessNum"));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r2.generalInfo.businessNum);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.isCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.isCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.isCanada === "genInfo.outsideCanada");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.isCanada === "genInfo.outsideCanada");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](38, 40, "genInfo.mailingAddress"));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r2.generalInfo.mailingAddress);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](43, 42, "genInfo.city"));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r2.generalInfo.city);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.isCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.isCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.isCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.isCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.isCanada === "genInfo.outsideCanada");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.isCanada === "genInfo.outsideCanada");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](54, 44, "review.phone"));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r2.generalInfo.mainPhone);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.altPhone);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r2.generalInfo.altPhone);
  }
}
function ReviewComponent_div_8_dt_21_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 1, "genInfo.firstName"));
  }
}
function ReviewComponent_div_8_dd_22_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r44 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r44.generalInfo.firstName);
  }
}
function ReviewComponent_div_8_dt_23_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 1, "genInfo.lastName"));
  }
}
function ReviewComponent_div_8_dd_24_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r46 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r46.generalInfo.lastName);
  }
}
function ReviewComponent_div_8_dt_25_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 1, "genInfo.businessName"));
  }
}
function ReviewComponent_div_8_dd_26_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r48 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r48.generalInfo.businessName);
  }
}
function ReviewComponent_div_8_dt_27_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 1, "genInfo.businessNum"));
  }
}
function ReviewComponent_div_8_dd_28_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r50 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r50.generalInfo.businessNum);
  }
}
function ReviewComponent_div_8_dt_29_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 1, "genInfo.sin"));
  }
}
function ReviewComponent_div_8_dd_30_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r52 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r52.generalInfo.sin);
  }
}
function ReviewComponent_div_8_dt_31_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 1, "genInfo.otherAccntNum"));
  }
}
function ReviewComponent_div_8_dd_32_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r54 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r54.generalInfo.otherAccntNum);
  }
}
function ReviewComponent_div_8_dt_33_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 1, "genInfo.isCanada"));
  }
}
function ReviewComponent_div_8_dd_34_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 1, "genInfo.canada"));
  }
}
function ReviewComponent_div_8_dt_35_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 1, "genInfo.isCanada"));
  }
}
function ReviewComponent_div_8_dd_36_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r58 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"]("", ctx_r58.generalInfo.country, " ");
  }
}
function ReviewComponent_div_8_dt_47_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 1, "genInfo.province"));
  }
}
function ReviewComponent_div_8_dd_48_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r60 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 1, ctx_r60.generalInfo.province));
  }
}
function ReviewComponent_div_8_dt_49_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 1, "genInfo.postalCanada"));
  }
}
function ReviewComponent_div_8_dd_50_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r62 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r62.generalInfo.postalCode);
  }
}
function ReviewComponent_div_8_dt_51_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 1, "genInfo.postalOutsideCanada"), "");
  }
}
function ReviewComponent_div_8_dd_52_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r64 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r64.generalInfo.postalCode);
  }
}
function ReviewComponent_div_8_dt_58_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 1, "review.altPhone"));
  }
}
function ReviewComponent_div_8_dd_59_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r66 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r66.generalInfo.altPhone);
  }
}
function ReviewComponent_div_8_dt_75_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 1, "genInfo.businessName"));
  }
}
function ReviewComponent_div_8_dd_76_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r68 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r68.generalInfo.repBusinessName);
  }
}
function ReviewComponent_div_8_dt_77_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 1, "genInfo.businessNum"));
  }
}
function ReviewComponent_div_8_dd_78_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r70 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r70.generalInfo.repBusinessNum);
  }
}
function ReviewComponent_div_8_dt_79_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 1, "genInfo.repNum"));
  }
}
function ReviewComponent_div_8_dd_80_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r72 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r72.generalInfo.repNum);
  }
}
function ReviewComponent_div_8_dt_81_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 1, "genInfo.isCanada"));
  }
}
function ReviewComponent_div_8_dd_82_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 1, "genInfo.canada"));
  }
}
function ReviewComponent_div_8_dt_83_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 1, "genInfo.isCanada"), " ");
  }
}
function ReviewComponent_div_8_dd_84_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r76 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", ctx_r76.generalInfo.repCountry, "");
  }
}
function ReviewComponent_div_8_dt_95_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 1, "genInfo.province"));
  }
}
function ReviewComponent_div_8_dd_96_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r78 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 1, ctx_r78.generalInfo.repProvince), " ");
  }
}
function ReviewComponent_div_8_dt_97_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 1, "genInfo.postalCanada"));
  }
}
function ReviewComponent_div_8_dd_98_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r80 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r80.generalInfo.repPostalCode);
  }
}
function ReviewComponent_div_8_dt_99_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](2, 1, "genInfo.postalOutsideCanada"), "");
  }
}
function ReviewComponent_div_8_dd_100_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r82 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r82.generalInfo.repPostalCode);
  }
}
function ReviewComponent_div_8_Template(rf, ctx) {
  if (rf & 1) {
    const _r84 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div", 11)(1, "div", 12)(2, "div", 13)(3, "h2", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](5, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](6, "div", 15)(7, "a", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("click", function ReviewComponent_div_8_Template_a_click_7_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵrestoreView"](_r84);
      const ctx_r83 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵresetView"](ctx_r83.setGeneralInfoEdit());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](8, "span", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](9, "span", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](11, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](12, "span", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](13);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](14, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](15, "hr", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](16, "div", 21)(17, "h3", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](18);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](19, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](20, "dl", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](21, ReviewComponent_div_8_dt_21_Template, 3, 3, "dt", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](22, ReviewComponent_div_8_dd_22_Template, 2, 1, "dd", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](23, ReviewComponent_div_8_dt_23_Template, 3, 3, "dt", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](24, ReviewComponent_div_8_dd_24_Template, 2, 1, "dd", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](25, ReviewComponent_div_8_dt_25_Template, 3, 3, "dt", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](26, ReviewComponent_div_8_dd_26_Template, 2, 1, "dd", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](27, ReviewComponent_div_8_dt_27_Template, 3, 3, "dt", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](28, ReviewComponent_div_8_dd_28_Template, 2, 1, "dd", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](29, ReviewComponent_div_8_dt_29_Template, 3, 3, "dt", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](30, ReviewComponent_div_8_dd_30_Template, 2, 1, "dd", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](31, ReviewComponent_div_8_dt_31_Template, 3, 3, "dt", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](32, ReviewComponent_div_8_dd_32_Template, 2, 1, "dd", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](33, ReviewComponent_div_8_dt_33_Template, 3, 3, "dt", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](34, ReviewComponent_div_8_dd_34_Template, 3, 3, "dd", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](35, ReviewComponent_div_8_dt_35_Template, 3, 3, "dt", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](36, ReviewComponent_div_8_dd_36_Template, 2, 1, "dd", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](37, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](38);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](39, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](40, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](41);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](42, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](43);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](44, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](45, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](46);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](47, ReviewComponent_div_8_dt_47_Template, 3, 3, "dt", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](48, ReviewComponent_div_8_dd_48_Template, 3, 3, "dd", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](49, ReviewComponent_div_8_dt_49_Template, 3, 3, "dt", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](50, ReviewComponent_div_8_dd_50_Template, 2, 1, "dd", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](51, ReviewComponent_div_8_dt_51_Template, 3, 3, "dt", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](52, ReviewComponent_div_8_dd_52_Template, 2, 1, "dd", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](53, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](54);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](55, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](56, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](57);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](58, ReviewComponent_div_8_dt_58_Template, 3, 3, "dt", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](59, ReviewComponent_div_8_dd_59_Template, 2, 1, "dd", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](60, "hr", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](61, "h3", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](62);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](63, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](64, "dl", 22)(65, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](66);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](67, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](68, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](69);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](70, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](71);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](72, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](73, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](74);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](75, ReviewComponent_div_8_dt_75_Template, 3, 3, "dt", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](76, ReviewComponent_div_8_dd_76_Template, 2, 1, "dd", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](77, ReviewComponent_div_8_dt_77_Template, 3, 3, "dt", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](78, ReviewComponent_div_8_dd_78_Template, 2, 1, "dd", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](79, ReviewComponent_div_8_dt_79_Template, 3, 3, "dt", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](80, ReviewComponent_div_8_dd_80_Template, 2, 1, "dd", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](81, ReviewComponent_div_8_dt_81_Template, 3, 3, "dt", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](82, ReviewComponent_div_8_dd_82_Template, 3, 3, "dd", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](83, ReviewComponent_div_8_dt_83_Template, 3, 3, "dt", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](84, ReviewComponent_div_8_dd_84_Template, 2, 1, "dd", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](85, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](86);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](87, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](88, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](89);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](90, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](91);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](92, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](93, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](94);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](95, ReviewComponent_div_8_dt_95_Template, 3, 3, "dt", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](96, ReviewComponent_div_8_dd_96_Template, 3, 3, "dd", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](97, ReviewComponent_div_8_dt_97_Template, 3, 3, "dt", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](98, ReviewComponent_div_8_dd_98_Template, 2, 1, "dd", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](99, ReviewComponent_div_8_dt_99_Template, 3, 3, "dt", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](100, ReviewComponent_div_8_dd_100_Template, 2, 1, "dd", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](101, "dt");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](102);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](103, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](104, "dd");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](105);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](5, 62, "review.rep.info"));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction0"](88, _c0));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](11, 64, "review.edit"));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](14, 66, "review.edit.rep.hidden"));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](19, 68, "genInfo.clientInfo"));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r3.generalInfo.firstName);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r3.generalInfo.firstName);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r3.generalInfo.lastName);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r3.generalInfo.lastName);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r3.generalInfo.businessName);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r3.generalInfo.businessName);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r3.generalInfo.businessNum);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r3.generalInfo.businessNum);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r3.generalInfo.sin);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r3.generalInfo.sin);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r3.generalInfo.otherAccntNum);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r3.generalInfo.otherAccntNum);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r3.generalInfo.isCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r3.generalInfo.isCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r3.generalInfo.isCanada === "genInfo.outsideCanada");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r3.generalInfo.isCanada === "genInfo.outsideCanada");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](39, 70, "genInfo.mailingAddress"));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r3.generalInfo.mailingAddress);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](44, 72, "genInfo.city"));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r3.generalInfo.city);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r3.generalInfo.isCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r3.generalInfo.isCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r3.generalInfo.isCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r3.generalInfo.isCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r3.generalInfo.isCanada === "genInfo.outsideCanada");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r3.generalInfo.isCanada === "genInfo.outsideCanada");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](55, 74, "review.phone"));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r3.generalInfo.mainPhone);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r3.generalInfo.altPhone);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r3.generalInfo.altPhone);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](63, 76, "review.rep.subtitleB"));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](67, 78, "genInfo.firstName"));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r3.generalInfo.repFirstName);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](72, 80, "genInfo.lastName"));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r3.generalInfo.repLastName);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r3.generalInfo.repBusinessName);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r3.generalInfo.repBusinessName);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r3.generalInfo.repBusinessNum);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r3.generalInfo.repBusinessNum);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r3.generalInfo.repNum);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r3.generalInfo.repNum);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r3.generalInfo.repIsCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r3.generalInfo.repIsCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r3.generalInfo.repIsCanada === "genInfo.outsideCanada");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r3.generalInfo.repIsCanada === "genInfo.outsideCanada");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](87, 82, "genInfo.mailingAddress"));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r3.generalInfo.repMailingAddress);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](92, 84, "genInfo.city"));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r3.generalInfo.repCity);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r3.generalInfo.repIsCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r3.generalInfo.repIsCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r3.generalInfo.repIsCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r3.generalInfo.repIsCanada === "genInfo.canada");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r3.generalInfo.repIsCanada === "genInfo.outsideCanada");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r3.generalInfo.repIsCanada === "genInfo.outsideCanada");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](103, 86, "review.phone"));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r3.generalInfo.repMainPhone);
  }
}
function ReviewComponent_div_13_Template(rf, ctx) {
  if (rf & 1) {
    const _r86 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div", 11)(1, "div", 12)(2, "div", 13)(3, "h3", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](5, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](6, "div", 15)(7, "a", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("click", function ReviewComponent_div_13_Template_a_click_7_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵrestoreView"](_r86);
      const ctx_r85 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵresetView"](ctx_r85.setComplaintEdit());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](8, "span", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](9, "span", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](11, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](12, "span", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](13);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](14, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](15, "hr", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](16, "p", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](17);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](5, 5, "review.complaint"));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction0"](11, _c0));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](11, 7, "review.edit"));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](14, 9, "review.complaint.hidden"));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r4.complaint.complaintFeedback);
  }
}
function ReviewComponent_div_14_Template(rf, ctx) {
  if (rf & 1) {
    const _r88 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div", 11)(1, "div", 12)(2, "div", 13)(3, "h3", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](5, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](6, "div", 15)(7, "a", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("click", function ReviewComponent_div_14_Template_a_click_7_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵrestoreView"](_r88);
      const ctx_r87 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵresetView"](ctx_r87.setSuggestionEdit());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](8, "span", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](9, "span", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](11, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](12, "span", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](13);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](14, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](15, "hr", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](16, "p", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](17);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](5, 5, "review.suggestion"));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction0"](11, _c0));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](11, 7, "review.edit"));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](14, 9, "review.suggestion.hidden"));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r5.suggestion.suggestionFeedback);
  }
}
function ReviewComponent_div_15_Template(rf, ctx) {
  if (rf & 1) {
    const _r90 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div", 11)(1, "div", 12)(2, "div", 13)(3, "h3", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](5, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](6, "div", 15)(7, "a", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("click", function ReviewComponent_div_15_Template_a_click_7_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵrestoreView"](_r90);
      const ctx_r89 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵresetView"](ctx_r89.setComplimentEdit());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](8, "span", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](9, "span", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](11, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](12, "span", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](13);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](14, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](15, "hr", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](16, "p", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](17);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](5, 5, "review.compliment"));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction0"](11, _c0));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](11, 7, "review.edit"));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](14, 9, "review.compliment.hidden"));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r6.compliment.complimentFeedback);
  }
}
const _c1 = function (a0, a1) {
  return {
    stepNum: a0,
    stepTotal: a1
  };
};
const ERROR_REQUEST_ALREADY_SUBMITTED = 'app.review.request.already.submitted';
const ERROR_SERVICE_UNAVAILABLE = 'app.review.service.not.available';
class ReviewComponent extends _base__WEBPACK_IMPORTED_MODULE_4__.BaseComponent {
  constructor(fb, infoService, log, submissionService, router, focusService, translateService, windowService, metaService) {
    super(translateService, infoService, windowService, metaService);
    this.fb = fb;
    this.log = log;
    this.submissionService = submissionService;
    this.router = router;
    this.focusService = focusService;
    this.translateService = translateService;
    this.submissionInProgress = false;
    infoService.generalInfo.subscribe(resp => {
      this.generalInfo = resp;
    });
    infoService.complaint.subscribe(resp => {
      this.complaint = resp;
    });
    infoService.suggestion.subscribe(resp => {
      this.suggestion = resp;
    });
    infoService.compliment.subscribe(resp => {
      this.compliment = resp;
    });
    infoService.review.subscribe(resp => {
      this.review = resp;
    });
    this.langChangeSubscription = this.translateService.onLangChange.subscribe(() => {
      if (this.reviewFormErrorMessageKey) {
        this.setFormError(this.reviewFormErrorMessageKey);
      }
    });
  }
  ngOnInit() {
    this.updateMeta(this.translateService.instant('review.details.title'));
    this.adobeDLPush(this.translateService.instant('review.details.title'));
    this.review.captchaToken = undefined;
    this.infoService.review.next(this.review);
    this.errorSubmit = false;
    this.form = this.fb.group({
      certifyBox: new _angular_forms__WEBPACK_IMPORTED_MODULE_12__.UntypedFormControl({
        value: null,
        disabled: false
      }, {
        validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.requiredTrue]
      })
    });
  }
  ngOnDestroy() {
    this.langChangeSubscription.unsubscribe();
  }
  get certifyBox() {
    return this.form.get('certifyBox');
  }
  getStepTotal() {
    var stepTotal = this.generalInfo.feedbackType.split(",").length + 2;
    return stepTotal;
  }
  getStepNum() {
    var stepNum = this.getStepTotal() - 1;
    return stepNum;
  }
  enablePersonal() {
    if (this.generalInfo.onBehalf != null && this.generalInfo.onBehalf.includes('myself')) {
      return true;
    }
    return false;
  }
  enableBusiness() {
    if (this.generalInfo.onBehalf != null && this.generalInfo.onBehalf.includes('business')) {
      return true;
    }
    return false;
  }
  enableRep() {
    if (this.generalInfo.onBehalf != null && this.generalInfo.onBehalf.includes('representative')) {
      return true;
    }
    return false;
  }
  enableProvince() {
    if (this.generalInfo.isCanada.includes('genInfo.canada')) {
      return true;
    }
    return false;
  }
  enableCountry() {
    if (this.generalInfo.isCanada.includes('genInfo.outsideCanada')) {
      return true;
    }
    return false;
  }
  enableComplaint() {
    if (this.generalInfo.feedbackType != null && this.generalInfo.feedbackType?.split(",").includes('complaint')) {
      return true;
    }
    return false;
  }
  enableSuggestion() {
    if (this.generalInfo.feedbackType != null && this.generalInfo.feedbackType?.split(",").includes('suggestion')) {
      return true;
    }
    return false;
  }
  enableCompliment() {
    if (this.generalInfo.feedbackType != null && this.generalInfo.feedbackType?.split(",").includes('compliment')) {
      return true;
    }
    return false;
  }
  setGeneralInfoEdit() {
    this.infoService.entry.value.hasStart = true;
    this.router.navigateByUrl('/generalinfo');
  }
  setComplaintEdit() {
    this.infoService.complaint.value.canActive = true;
    this.router.navigateByUrl('/complaint');
  }
  setSuggestionEdit() {
    this.infoService.suggestion.value.canActive = true;
    this.router.navigateByUrl('/suggestion');
  }
  setComplimentEdit() {
    this.infoService.compliment.value.canActive = true;
    this.router.navigateByUrl('/compliment');
  }
  previous() {
    if (this.generalInfo.feedbackType?.split(",").includes('compliment')) {
      this.infoService.compliment.value.canActive = true;
      return '/compliment';
    } else if (this.generalInfo.feedbackType?.split(",").includes('suggestion')) {
      this.infoService.suggestion.value.canActive = true;
      return '/suggestion';
    } else if (this.generalInfo.feedbackType?.split(",").includes('complaint')) {
      this.infoService.complaint.value.canActive = true;
      return '/complaint';
    } else {
      this.infoService.entry.value.hasStart = true;
      return '/generalinfo';
    }
  }
  submit() {
    if (!this.submissionInProgress) {
      this.submissionInProgress = true;
      this.submitApplication();
    }
  }
  submitApplication() {
    if (this.form.invalid) {
      // Show errors
      this.submissionInProgress = false;
      (0,_cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_13__.revealAllErrors)(this.form);
      this.focusService.requestFocus(src_app_app_component__WEBPACK_IMPORTED_MODULE_1__.ERROR_HEADER_ID);
    } else {
      let confirmationNumber = this.review.confirmationNumber;
      // If confirmation number was already generated, show error.
      if (confirmationNumber) {
        this.setFormError(ERROR_REQUEST_ALREADY_SUBMITTED).then(() => this.focusService.requestFocus(src_app_app_component__WEBPACK_IMPORTED_MODULE_1__.FORM_ERROR_HEADER_ID)).finally(() => this.submissionInProgress = false);
      } else {
        this.currentReview = new src_app_model_review__WEBPACK_IMPORTED_MODULE_0__.Review();
        this.currentReview.confirmationNumber = this.confirmationNumber;
        this.currentReview.certifyBox = this.certifyBox.value;
        this.currentReview.captchaToken = this.review.captchaToken;
        let application = new src_app_model_submission__WEBPACK_IMPORTED_MODULE_3__.Submission();
        application.captchaToken = this.review.captchaToken;
        application.feedbackType = this.generalInfo.feedbackType;
        application.isRepondSuggestion = this.generalInfo.isRepondSuggestion;
        application.isRepondCompliment = this.generalInfo.isRepondCompliment;
        application.onBehalf = this.generalInfo.onBehalf;
        application.isIndividualOrBusiness = this.generalInfo.isIndividualOrBusiness;
        application.firstName = this.generalInfo.firstName;
        application.lastName = this.generalInfo.lastName;
        application.businessName = this.generalInfo.businessName;
        application.businessNum = this.generalInfo.businessNum;
        application.isCanada = this.generalInfo.isCanada;
        application.country = this.generalInfo.country;
        application.mailingAddress = this.generalInfo.mailingAddress;
        application.city = this.generalInfo.city;
        application.province = this.generalInfo.province;
        application.postalCode = this.generalInfo.postalCode;
        application.mainPhone = this.generalInfo.mainPhone;
        application.altPhone = this.generalInfo.altPhone;
        application.isSINorOtherAccountNum = this.generalInfo.isSINorOtherAccountNum;
        application.sin = this.generalInfo.sin;
        application.otherAccntNum = this.generalInfo.otherAccntNum;
        application.repFirstName = this.generalInfo.repFirstName;
        application.repLastName = this.generalInfo.repLastName;
        application.repBusinessName = this.generalInfo.repBusinessName;
        application.repBusinessNum = this.generalInfo.repBusinessNum;
        application.repMailingAddress = this.generalInfo.repMailingAddress;
        application.repCity = this.generalInfo.repCity;
        application.repProvince = this.generalInfo.repProvince;
        application.repNum = this.generalInfo.repNum;
        application.repIsCanada = this.generalInfo.repIsCanada;
        application.repCountry = this.generalInfo.repCountry;
        application.repPostalCode = this.generalInfo.repPostalCode;
        application.repMainPhone = this.generalInfo.repMainPhone;
        application.complaintFeedback = this.complaint.complaintFeedback;
        application.suggestionFeedback = this.suggestion.suggestionFeedback;
        application.complimentFeedback = this.compliment.complimentFeedback;
        this.submissionService.submitApplication(application).then(submissionResponse => {
          this.currentReview.formSubmitted = true;
          this.currentReview.confirmationNumber = submissionResponse.confirmationNumber;
          this.infoService.review.next(this.currentReview);
          this.infoService.confirmation.value.canActive = true;
          this.router.navigate([src_app_app_routing_module__WEBPACK_IMPORTED_MODULE_2__.CONFIRMATION_PAGE]);
          this.submissionInProgress = false;
        }, () => {
          this.setFormError(ERROR_SERVICE_UNAVAILABLE).then(() => this.focusService.requestFocus(src_app_app_component__WEBPACK_IMPORTED_MODULE_1__.FORM_ERROR_HEADER_ID)).finally(() => this.submissionInProgress = false);
        });
      }
    }
  }
  setFormError(messageKey) {
    let setErrorPromise = new Promise((resolve, reject) => {
      this.translateService.get(messageKey).subscribe(message => {
        this.reviewFormErrorMessage = message;
        this.reviewFormErrorMessageKey = messageKey;
        resolve();
      }, () => reject());
    });
    return setErrorPromise;
  }
  get formErrorHeaderId() {
    return ReviewComponent.formErrorHeaderId;
  }
  get errorHeaderId() {
    return ReviewComponent.errorHeaderId;
  }
}
ReviewComponent.formErrorHeaderId = src_app_app_component__WEBPACK_IMPORTED_MODULE_1__.FORM_ERROR_HEADER_ID;
ReviewComponent.errorHeaderId = src_app_app_component__WEBPACK_IMPORTED_MODULE_1__.ERROR_HEADER_ID;
ReviewComponent.ɵfac = function ReviewComponent_Factory(t) {
  return new (t || ReviewComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_12__.UntypedFormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](src_app_services_result_result_service__WEBPACK_IMPORTED_MODULE_5__.ResultService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_cra_arc_rccr_core__WEBPACK_IMPORTED_MODULE_14__.LogService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](src_app_services_app_submission_service__WEBPACK_IMPORTED_MODULE_6__.AppSubmissionService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_15__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_cra_arc_rccr_core__WEBPACK_IMPORTED_MODULE_14__.FocusService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_16__.TranslateService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_cra_arc_rccr_core__WEBPACK_IMPORTED_MODULE_14__.WindowService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_angular_platform_browser__WEBPACK_IMPORTED_MODULE_17__.Meta));
};
ReviewComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdefineComponent"]({
  type: ReviewComponent,
  selectors: [["app-review"]],
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵInheritDefinitionFeature"]],
  decls: 19,
  vars: 27,
  consts: [[3, "titleKey", "headingKey"], ["autocomplete", "off", 3, "formGroup", "ngSubmit"], ["class", "alert alert-danger", "tabindex", "-1", 3, "rccrFocusable", 4, "ngIf"], [3, "form", "id"], ["class", "mrgn-tp-lg well well-secondary", 4, "ngIf"], [3, "cpControlName", "cpFormGroup"], [3, "back", "next", "buttonNextDisabled"], [3, "screenId"], ["tabindex", "-1", 1, "alert", "alert-danger", 3, "rccrFocusable"], ["translate", ""], [3, "innerHTML"], [1, "mrgn-tp-lg", "well", "well-secondary"], [1, "row", "nav"], [1, "col-sm-10", "col-xs-7"], [1, "h3", "mrgn-tp-0", "mrgn-bttm-0"], [1, "col-sm-2", "col-xs-5", "text-right"], [3, "routerLink", "click"], ["aria-hidden", "true", 1, "glyphicon", "glyphicon-pencil", 2, "padding-right", "5px"], ["aria-hidden", "true"], [1, "wb-inv"], [1, "solid-line"], [1, "mrgn-lft-md", "mrgn-tp-lg"], [1, "dl-horizontal", "brdr-0", "dl-col-5", "nopadding"], [4, "ngIf"], [1, "mrgn-bttm"], [1, "mrgn-tp-0", "mrgn-bttm-0"], [1, "wordWrap"]],
  template: function ReviewComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](0, "rccr-page-heading", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](1, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](2, "form", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("ngSubmit", function ReviewComponent_Template_form_ngSubmit_2_listener() {
        return ctx.submit();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](3, ReviewComponent_section_3_Template, 4, 3, "section", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](4, "rccr-error-aggregator", 3)(5, "denotes-required");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](6, ReviewComponent_div_6_Template, 59, 47, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](7, ReviewComponent_div_7_Template, 59, 47, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](8, ReviewComponent_div_8_Template, 106, 89, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](9, "h2");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](10);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](11, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](12, "div");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](13, ReviewComponent_div_13_Template, 18, 12, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](14, ReviewComponent_div_14_Template, 18, 12, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](15, ReviewComponent_div_15_Template, 18, 12, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](16, "app-review-captcha", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](17, "app-back-next-buttongroup", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](18, "app-page-details-local", 7);
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("titleKey", "review.details.title")("headingKey", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind2"](1, 19, "review.details.step", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction2"](24, _c1, ctx.getStepNum(), ctx.getStepTotal())));
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("formGroup", ctx.form);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx.reviewFormErrorMessage);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("form", ctx.form)("id", ctx.errorHeaderId);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx.enablePersonal());
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx.enableBusiness());
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx.enableRep());
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](11, 22, "review.feedback.label"));
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx.enableComplaint());
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx.enableSuggestion());
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx.enableCompliment());
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("cpControlName", "certifyBox")("cpFormGroup", ctx.form);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("back", ctx.previous())("next", "submit")("buttonNextDisabled", !ctx.review.captchaToken || ctx.submissionInProgress);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("screenId", "UISP-RC193-REVIEW");
    }
  },
  dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_18__.NgIf, _angular_router__WEBPACK_IMPORTED_MODULE_15__.RouterLink, _cra_arc_rccr_core__WEBPACK_IMPORTED_MODULE_14__.FocusableDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_12__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_12__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.FormGroupDirective, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_16__.TranslateDirective, _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_13__.PageHeadingComponent, _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_13__.ErrorAggregatorComponent, _templates_back_next_buttongroup_back_next_buttongroup_component__WEBPACK_IMPORTED_MODULE_7__.BackNextButtongroupComponent, _templates_page_details_local_page_details_local_component__WEBPACK_IMPORTED_MODULE_8__.PageDetailsLocalComponent, _templates_denotes_required_denotes_required_component__WEBPACK_IMPORTED_MODULE_9__.DenotesRequiredComponent, _templates_captcha_app_review_captcha_component__WEBPACK_IMPORTED_MODULE_10__.AppReviewCaptchaComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_16__.TranslatePipe],
  styles: ["\n\n#formErrorHeader[_ngcontent-%COMP%]:focus, #errorHeader[_ngcontent-%COMP%]:focus {\n    outline: 1px dotted black;\n}\n\nnav[_ngcontent-%COMP%]{\n    display:inline !important;\n}\n.glyphicon[_ngcontent-%COMP%]{\n    display: inline !important;\n}\n.solid-line[_ngcontent-%COMP%]{\n    border-top: solid 1px;\n    border-top-color: slategray;\n}\ndt[_ngcontent-%COMP%]{\n    font-weight: 600;\n}\ndd[_ngcontent-%COMP%], .wordWrap[_ngcontent-%COMP%]{\n    word-wrap: break-word;\n    white-space: pre-line;\n}\n.mrgn-bttm[_ngcontent-%COMP%]{\n    margin-bottom: 20px;\n}\n\n\n\n@media all and (min-width:768px) {\n    \n\n        .dl-col-4[_ngcontent-%COMP%], .dl-col-5[_ngcontent-%COMP%], .dl-col-6[_ngcontent-%COMP%], .dl-col-7[_ngcontent-%COMP%], .dl-col-8[_ngcontent-%COMP%], .dl-col-9[_ngcontent-%COMP%], .dl-col-10[_ngcontent-%COMP%] {\n            width:100%;\n            margin-top:15px;\n        }\n    \n\n        .nopadding[_ngcontent-%COMP%]   dd[_ngcontent-%COMP%], .nopadding[_ngcontent-%COMP%]   dt[_ngcontent-%COMP%]\n        {\n            padding-bottom:0px;\n            padding-top:0px;\n        }\n    \n\n        .dl-col-4[_ngcontent-%COMP%]    > dt[_ngcontent-%COMP%] {\n            width: 33.3333333333%;\n        }\n        .dl-col-5[_ngcontent-%COMP%]    > dt[_ngcontent-%COMP%]{\n            width: 41.6666666667%;\n        }\n        .dl-col-6[_ngcontent-%COMP%]    > dt[_ngcontent-%COMP%] {\n            width: 50%;\n        }\n        .dl-col-7[_ngcontent-%COMP%]    > dt[_ngcontent-%COMP%] {\n            width: 58.3333333333%;\n        }\n        .dl-col-8[_ngcontent-%COMP%]    > dt[_ngcontent-%COMP%] {\n            width: 66.6666666667%;\n        }\n        .dl-col-9[_ngcontent-%COMP%]    > dt[_ngcontent-%COMP%] {\n            width: 75%;\n        }\n        .dl-col-10[_ngcontent-%COMP%]    > dt[_ngcontent-%COMP%] {\n            width: 83.3333333333%;\n        }\n        .dl-horizontal[_ngcontent-%COMP%]   dt.dt-bttm-0[_ngcontent-%COMP%] {\n            margin-bottom: 0;\n        }\n        .dl-horizontal[_ngcontent-%COMP%]   dd[_ngcontent-%COMP%] {\n            margin-left: 600px;\n        }\n}\n.dl-horizontal[_ngcontent-%COMP%]   dd.dd-bttm-0[_ngcontent-%COMP%] {\n    margin-bottom: 0;\n}\n\n\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29tcG9uZW50cy9yZXZpZXcvcmV2aWV3LmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsNkZBQTZGO0FBQzdGOztJQUVJLHlCQUF5QjtBQUM3Qjs7QUFFQTtJQUNJLHlCQUF5QjtBQUM3QjtBQUNBO0lBQ0ksMEJBQTBCO0FBQzlCO0FBQ0E7SUFDSSxxQkFBcUI7SUFDckIsMkJBQTJCO0FBQy9CO0FBQ0E7SUFDSSxnQkFBZ0I7QUFDcEI7QUFDQTtJQUNJLHFCQUFxQjtJQUNyQixxQkFBcUI7QUFDekI7QUFDQTtJQUNJLG1CQUFtQjtBQUN2Qjs7QUFFQSw2RUFBNkU7QUFDN0U7SUFDSSxvSEFBb0g7UUFDaEg7Ozs7Ozs7WUFPSSxVQUFVO1lBQ1YsZUFBZTtRQUNuQjtJQUNKLHVCQUF1QjtRQUNuQjs7WUFFSSxrQkFBa0I7WUFDbEIsZUFBZTtRQUNuQjtJQUNKLHFDQUFxQztRQUNqQztZQUNJLHFCQUFxQjtRQUN6QjtRQUNBO1lBQ0kscUJBQXFCO1FBQ3pCO1FBQ0E7WUFDSSxVQUFVO1FBQ2Q7UUFDQTtZQUNJLHFCQUFxQjtRQUN6QjtRQUNBO1lBQ0kscUJBQXFCO1FBQ3pCO1FBQ0E7WUFDSSxVQUFVO1FBQ2Q7UUFDQTtZQUNJLHFCQUFxQjtRQUN6QjtRQUNBO1lBQ0ksZ0JBQWdCO1FBQ3BCO1FBQ0E7WUFDSSxrQkFBa0I7UUFDdEI7QUFDUjtBQUNBO0lBQ0ksZ0JBQWdCO0FBQ3BCO0FBQ0Esa0NBQWtDIiwic291cmNlc0NvbnRlbnQiOlsiLyogQ2hhbmdlIHRoZSBmb2N1cyBib3JkZXIgb2YgZXJyb3IgaGVhZGVycyB0byBhIGRvdHRlZCBsaW5lLiAoQ29uc2lzdGVudCB3aXRoIHBhZ2UgaGVhZGVyKSAqL1xyXG4jZm9ybUVycm9ySGVhZGVyOmZvY3VzLFxyXG4jZXJyb3JIZWFkZXI6Zm9jdXMge1xyXG4gICAgb3V0bGluZTogMXB4IGRvdHRlZCBibGFjaztcclxufVxyXG5cclxubmF2e1xyXG4gICAgZGlzcGxheTppbmxpbmUgIWltcG9ydGFudDtcclxufVxyXG4uZ2x5cGhpY29ue1xyXG4gICAgZGlzcGxheTogaW5saW5lICFpbXBvcnRhbnQ7XHJcbn1cclxuLnNvbGlkLWxpbmV7XHJcbiAgICBib3JkZXItdG9wOiBzb2xpZCAxcHg7XHJcbiAgICBib3JkZXItdG9wLWNvbG9yOiBzbGF0ZWdyYXk7XHJcbn1cclxuZHR7XHJcbiAgICBmb250LXdlaWdodDogNjAwO1xyXG59XHJcbmRkLCAud29yZFdyYXB7XHJcbiAgICB3b3JkLXdyYXA6IGJyZWFrLXdvcmQ7XHJcbiAgICB3aGl0ZS1zcGFjZTogcHJlLWxpbmU7XHJcbn1cclxuLm1yZ24tYnR0bXtcclxuICAgIG1hcmdpbi1ib3R0b206IDIwcHg7XHJcbn1cclxuXHJcbi8qIC0tLSBzdGFydCBEZXNjcmlwdGlvbiBMaXN0cyAoIGFkZGluZyBncmlkcyB0byB0aGUgV0VUIGRlZmF1bHQgY2xhc3MgKS0tLSAqL1xyXG5AbWVkaWEgYWxsIGFuZCAobWluLXdpZHRoOjc2OHB4KSB7XHJcbiAgICAvKiBXaWR0aCBvZiBkbCBpcyAxMDAlIHRvIHNwYW4gb3ZlciB0aGUgZW50aXJlIHdpZHRoLCBhbmQgbWFyZ2luIHRvcCB0byBnaXZlIHNwYWNlIGJldHdlZW4gaGVhZGluZyBhbmQgdGhlIGNvbnRlbnQgKi9cclxuICAgICAgICAuZGwtY29sLTQsXHJcbiAgICAgICAgLmRsLWNvbC01LFxyXG4gICAgICAgIC5kbC1jb2wtNixcclxuICAgICAgICAuZGwtY29sLTcsXHJcbiAgICAgICAgLmRsLWNvbC04LFxyXG4gICAgICAgIC5kbC1jb2wtOSxcclxuICAgICAgICAuZGwtY29sLTEwIHtcclxuICAgICAgICAgICAgd2lkdGg6MTAwJTtcclxuICAgICAgICAgICAgbWFyZ2luLXRvcDoxNXB4O1xyXG4gICAgICAgIH1cclxuICAgIC8qIE5vIHBhZGRpbmcgY2xhc3NlcyAqL1xyXG4gICAgICAgIC5ub3BhZGRpbmcgZGQsIC5ub3BhZGRpbmcgZHRcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIHBhZGRpbmctYm90dG9tOjBweDtcclxuICAgICAgICAgICAgcGFkZGluZy10b3A6MHB4O1xyXG4gICAgICAgIH1cclxuICAgIC8qIFdpZHRoIG9mIGRsIGJhc2VkIG9uIGdyaWQgc3lzdGVtICovXHJcbiAgICAgICAgLmRsLWNvbC00ID4gZHQge1xyXG4gICAgICAgICAgICB3aWR0aDogMzMuMzMzMzMzMzMzMyU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5kbC1jb2wtNSA+IGR0e1xyXG4gICAgICAgICAgICB3aWR0aDogNDEuNjY2NjY2NjY2NyU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5kbC1jb2wtNiA+IGR0IHtcclxuICAgICAgICAgICAgd2lkdGg6IDUwJTtcclxuICAgICAgICB9XHJcbiAgICAgICAgLmRsLWNvbC03ID4gZHQge1xyXG4gICAgICAgICAgICB3aWR0aDogNTguMzMzMzMzMzMzMyU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5kbC1jb2wtOCA+IGR0IHtcclxuICAgICAgICAgICAgd2lkdGg6IDY2LjY2NjY2NjY2NjclO1xyXG4gICAgICAgIH1cclxuICAgICAgICAuZGwtY29sLTkgPiBkdCB7XHJcbiAgICAgICAgICAgIHdpZHRoOiA3NSU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5kbC1jb2wtMTAgPiBkdCB7XHJcbiAgICAgICAgICAgIHdpZHRoOiA4My4zMzMzMzMzMzMzJTtcclxuICAgICAgICB9XHJcbiAgICAgICAgLmRsLWhvcml6b250YWwgZHQuZHQtYnR0bS0wIHtcclxuICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogMDtcclxuICAgICAgICB9XHJcbiAgICAgICAgLmRsLWhvcml6b250YWwgZGQge1xyXG4gICAgICAgICAgICBtYXJnaW4tbGVmdDogNjAwcHg7XHJcbiAgICAgICAgfVxyXG59XHJcbi5kbC1ob3Jpem9udGFsIGRkLmRkLWJ0dG0tMCB7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAwO1xyXG59XHJcbi8qIC0tLSBlbmQgRGVzY3JpcHRpb24gTGlzdHMgLS0tICovIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
});

/***/ }),

/***/ 7617:
/*!***************************************************************!*\
  !*** ./src/app/components/suggestion/suggestion.component.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SuggestionComponent: () => (/* binding */ SuggestionComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/forms */ 8849);
/* harmony import */ var _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @cra-arc/rccr-wet */ 399);
/* harmony import */ var src_app_model_suggestion__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/model/suggestion */ 9315);
/* harmony import */ var src_app_app_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/app.component */ 6401);
/* harmony import */ var src_app_util_AppFormHelper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/util/AppFormHelper */ 5664);
/* harmony import */ var _base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../base */ 6608);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var src_app_services_result_result_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/result/result.service */ 1392);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/router */ 7947);
/* harmony import */ var src_app_services_validation_validation_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/validation/validation.service */ 1109);
/* harmony import */ var _cra_arc_rccr_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @cra-arc/rccr-core */ 838);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ngx-translate/core */ 5939);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/platform-browser */ 6480);
/* harmony import */ var _templates_back_next_buttongroup_back_next_buttongroup_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../templates/back-next-buttongroup/back-next-buttongroup.component */ 672);
/* harmony import */ var _templates_page_details_local_page_details_local_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../templates/page-details-local/page-details-local.component */ 9704);
/* harmony import */ var _templates_denotes_required_denotes_required_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../templates/denotes-required/denotes-required.component */ 1284);


















const _c0 = function (a0, a1) {
  return {
    stepNum: a0,
    stepTotal: a1
  };
};
const _c1 = function () {
  return {
    "rows": "10",
    "cols": "130",
    "maxLength": "10000"
  };
};
class SuggestionComponent extends _base__WEBPACK_IMPORTED_MODULE_3__.BaseComponent {
  constructor(infoService, router, validationService, focusService, translateService, windowService, metaService) {
    super(translateService, infoService, windowService, metaService);
    this.router = router;
    this.validationService = validationService;
    this.focusService = focusService;
    this.translateService = translateService;
    infoService.generalInfo.subscribe(resp => {
      this.getGeneralInfo = resp;
    });
    infoService.suggestion.subscribe(resp => {
      this.suggestion = resp;
    });
  }
  ngOnInit() {
    this.updateMeta(this.translateService.instant('suggestion.details.title'));
    this.adobeDLPush(this.translateService.instant('suggestion.details.title'));
    this.form = new _angular_forms__WEBPACK_IMPORTED_MODULE_9__.UntypedFormGroup({
      suggestionFeedback: new _angular_forms__WEBPACK_IMPORTED_MODULE_9__.UntypedFormControl({
        value: this.suggestion.suggestionFeedback,
        disabled: false
      }, {
        validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.maxLength(10000), this.validationService.feedbackDetailValidator()],
        updateOn: 'change'
      })
    });
  }
  get suggestionFeedback() {
    return this.form.get('suggestionFeedback');
  }
  getStepTotal() {
    var stepTotal = this.getGeneralInfo.feedbackType.split(",").length + 2;
    return stepTotal;
  }
  getStepNum() {
    var stepNum = this.getGeneralInfo.feedbackType.split(",").indexOf('suggestion') + 1;
    return stepNum;
  }
  getProceed() {
    var CompOrSugg = "";
    if (this.getGeneralInfo?.feedbackType?.split(",").includes('compliment')) {
      CompOrSugg = 'proceedCompliment';
    } else {
      CompOrSugg = 'next';
    }
    return CompOrSugg;
  }
  previous() {
    if (this.getGeneralInfo.feedbackType.split(",").includes('complaint')) {
      this.infoService.complaint.value.canActive = true;
      return '/complaint';
    } else {
      this.infoService.entry.value.hasStart = true;
      return '/generalinfo';
    }
  }
  submit() {
    src_app_util_AppFormHelper__WEBPACK_IMPORTED_MODULE_2__.AppFormHelper.trimInputField(this.suggestionFeedback);
    src_app_util_AppFormHelper__WEBPACK_IMPORTED_MODULE_2__.AppFormHelper.convertApostropheAndTabField(this.suggestionFeedback);
    if (this.form.invalid) {
      (0,_cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_10__.revealAllErrors)(this.form);
      this.focusService.requestFocus(src_app_app_component__WEBPACK_IMPORTED_MODULE_1__.ERROR_HEADER_ID);
    } else {
      this.infoService.suggestion.next(this.buildCurrentSuggestion());
      if (this.getGeneralInfo.feedbackType.split(",").includes('compliment')) {
        this.infoService.compliment.value.canActive = true;
        this.router.navigateByUrl('/compliment');
      } else {
        this.infoService.review.value.canActive = true;
        this.router.navigateByUrl('/review');
      }
    }
  }
  buildCurrentSuggestion() {
    this.currentSuggestion = new src_app_model_suggestion__WEBPACK_IMPORTED_MODULE_0__.Suggestion();
    this.currentSuggestion.suggestionFeedback = this.suggestionFeedback.value;
    return this.currentSuggestion;
  }
}
SuggestionComponent.ɵfac = function SuggestionComponent_Factory(t) {
  return new (t || SuggestionComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](src_app_services_result_result_service__WEBPACK_IMPORTED_MODULE_4__.ResultService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_12__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](src_app_services_validation_validation_service__WEBPACK_IMPORTED_MODULE_5__.ValidationService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_cra_arc_rccr_core__WEBPACK_IMPORTED_MODULE_13__.FocusService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_14__.TranslateService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_cra_arc_rccr_core__WEBPACK_IMPORTED_MODULE_13__.WindowService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_angular_platform_browser__WEBPACK_IMPORTED_MODULE_15__.Meta));
};
SuggestionComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdefineComponent"]({
  type: SuggestionComponent,
  selectors: [["app-suggestion"]],
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵInheritDefinitionFeature"]],
  decls: 8,
  vars: 23,
  consts: [[3, "titleKey", "headingKey"], ["autocomplete", "off", 3, "formGroup", "ngSubmit"], [3, "form", "id"], ["ngDefaultControl", "", 3, "form", "formControlName", "labelKey", "required", "labelContainsMarkup", "attributes", "inlineHelpKey", "subtextKey"], [3, "back", "next"], [3, "screenId"]],
  template: function SuggestionComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](0, "rccr-page-heading", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](1, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](2, "form", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("ngSubmit", function SuggestionComponent_Template_form_ngSubmit_2_listener() {
        return ctx.submit();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](3, "rccr-error-aggregator", 2)(4, "denotes-required")(5, "rccr-textarea", 3)(6, "app-back-next-buttongroup", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](7, "app-page-details-local", 5);
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("titleKey", "suggestion.details.title")("headingKey", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind2"](1, 16, "suggestion.details.step", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction2"](19, _c0, ctx.getStepNum(), ctx.getStepTotal())));
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("formGroup", ctx.form);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("form", ctx.form)("id", "errorHeader");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("form", ctx.form)("formControlName", "suggestionFeedback")("labelKey", "suggestion.label")("required", true)("labelContainsMarkup", true)("attributes", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction0"](22, _c1))("inlineHelpKey", "entry.specChar")("subtextKey", "complaint.maxText");
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("back", ctx.previous())("next", ctx.getProceed());
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("screenId", "UISP-RC193-SUGGESTION");
    }
  },
  dependencies: [_angular_forms__WEBPACK_IMPORTED_MODULE_9__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_9__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.RequiredValidator, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormControlName, _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_10__.PageHeadingComponent, _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_10__.ErrorAggregatorComponent, _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_10__.TextareaComponent, _templates_back_next_buttongroup_back_next_buttongroup_component__WEBPACK_IMPORTED_MODULE_6__.BackNextButtongroupComponent, _templates_page_details_local_page_details_local_component__WEBPACK_IMPORTED_MODULE_7__.PageDetailsLocalComponent, _templates_denotes_required_denotes_required_component__WEBPACK_IMPORTED_MODULE_8__.DenotesRequiredComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_14__.TranslatePipe],
  encapsulation: 2
});

/***/ }),

/***/ 672:
/*!***********************************************************************************************!*\
  !*** ./src/app/components/templates/back-next-buttongroup/back-next-buttongroup.component.ts ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   BackNextButtongroupComponent: () => (/* binding */ BackNextButtongroupComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ 6575);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 7947);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngx-translate/core */ 5939);





function BackNextButtongroupComponent_span_8_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span", 7)(1, "input", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function BackNextButtongroupComponent_span_8_Template_input_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r2);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.goSummary());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpropertyInterpolate"]("value", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](2, 1, "return.summary"));
  }
}
class BackNextButtongroupComponent {
  constructor() {
    this.back = '/entry';
    this.next = 'next';
    this.showRtnSumBtn = false;
    this.buttonNextDisabled = false;
    this.goSumm = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
  }
  ngOnInit() {}
  goSummary() {
    this.goSumm.emit();
  }
}
BackNextButtongroupComponent.ɵfac = function BackNextButtongroupComponent_Factory(t) {
  return new (t || BackNextButtongroupComponent)();
};
BackNextButtongroupComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
  type: BackNextButtongroupComponent,
  selectors: [["app-back-next-buttongroup"]],
  inputs: {
    back: "back",
    next: "next",
    showRtnSumBtn: "showRtnSumBtn",
    buttonNextDisabled: "buttonNextDisabled"
  },
  outputs: {
    goSumm: "goSumm"
  },
  decls: 9,
  vars: 10,
  consts: [[1, "container", "row", "mrgn-tp-lg", "mrgn-bttm-lg"], [1, "col-xs-12"], [1, "pstn-lft-xs"], [1, "right-btn"], ["id", "nxt", "type", "submit", "name", "formSubmit", 1, "btn", "btn-primary", 3, "value", "disabled"], ["id", "prv", "type", "submit", 1, "btn", "btn-default", 3, "routerLink", "name", "value"], ["class", "mrgn-lft-sm", 4, "ngIf"], [1, "mrgn-lft-sm"], ["id", "prv", "type", "submit", 1, "btn", "btn-default", 3, "value", "click"]],
  template: function BackNextButtongroupComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "input", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](5, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](6, "input", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](7, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](8, BackNextButtongroupComponent_span_8_Template, 3, 3, "span", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpropertyInterpolate"]("value", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](5, 6, ctx.next));
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("disabled", ctx.buttonNextDisabled);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpropertyInterpolate"]("name", ctx.back);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpropertyInterpolate"]("value", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](7, 8, "back"));
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("routerLink", ctx.back);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.showRtnSumBtn);
    }
  },
  dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.NgIf, _angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterLink, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__.TranslatePipe],
  styles: [".cancel[_ngcontent-%COMP%] {\n    padding-left: 30px;\n    position: relative;\n\ttop: 9px;\n}\n\n.container[_ngcontent-%COMP%] {\n    margin-bottom: 50px;\n}\n\n@media all and (max-width:480px) {\n    .btn[_ngcontent-%COMP%] { position: relative;\n        display: inline-block;}\n    .right-btn[_ngcontent-%COMP%]{\n        float: none;\n        margin-left: 0px;\n    }\n}\n\n@media all and (min-width:480px) {\n    .right-btn[_ngcontent-%COMP%]{\n        float: right!important;\n        margin-left: 5px;\n    }\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29tcG9uZW50cy90ZW1wbGF0ZXMvYmFjay1uZXh0LWJ1dHRvbmdyb3VwL2JhY2stbmV4dC1idXR0b25ncm91cC5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksa0JBQWtCO0lBQ2xCLGtCQUFrQjtDQUNyQixRQUFRO0FBQ1Q7O0FBRUE7SUFDSSxtQkFBbUI7QUFDdkI7O0FBRUE7SUFDSSxPQUFPLGtCQUFrQjtRQUNyQixxQkFBcUIsQ0FBQztJQUMxQjtRQUNJLFdBQVc7UUFDWCxnQkFBZ0I7SUFDcEI7QUFDSjs7QUFFQTtJQUNJO1FBQ0ksc0JBQXNCO1FBQ3RCLGdCQUFnQjtJQUNwQjtBQUNKIiwic291cmNlc0NvbnRlbnQiOlsiLmNhbmNlbCB7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDMwcHg7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcblx0dG9wOiA5cHg7XHJcbn1cclxuXHJcbi5jb250YWluZXIge1xyXG4gICAgbWFyZ2luLWJvdHRvbTogNTBweDtcclxufVxyXG5cclxuQG1lZGlhIGFsbCBhbmQgKG1heC13aWR0aDo0ODBweCkge1xyXG4gICAgLmJ0biB7IHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7fVxyXG4gICAgLnJpZ2h0LWJ0bntcclxuICAgICAgICBmbG9hdDogbm9uZTtcclxuICAgICAgICBtYXJnaW4tbGVmdDogMHB4O1xyXG4gICAgfVxyXG59XHJcblxyXG5AbWVkaWEgYWxsIGFuZCAobWluLXdpZHRoOjQ4MHB4KSB7XHJcbiAgICAucmlnaHQtYnRue1xyXG4gICAgICAgIGZsb2F0OiByaWdodCFpbXBvcnRhbnQ7XHJcbiAgICAgICAgbWFyZ2luLWxlZnQ6IDVweDtcclxuICAgIH1cclxufSJdLCJzb3VyY2VSb290IjoiIn0= */", "/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
});

/***/ }),

/***/ 4831:
/*!******************************************************************************!*\
  !*** ./src/app/components/templates/captcha/app-review-captcha.component.ts ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppReviewCaptchaComponent: () => (/* binding */ AppReviewCaptchaComponent)
/* harmony export */ });
/* harmony import */ var _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @cra-arc/rccr-wet */ 399);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var _cra_arc_rccr_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @cra-arc/rccr-core */ 838);
/* harmony import */ var src_app_services_result_result_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/services/result/result.service */ 1392);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 6575);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 8849);
/* harmony import */ var _app_review_captcha_directive__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app-review-captcha.directive */ 5286);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ 5939);









const _c0 = function (a1) {
  return {
    "form-group": true,
    "has-error": a1
  };
};
class AppReviewCaptchaComponent {
  constructor(log, infoService) {
    this.log = log;
    this.infoService = infoService;
    infoService.review.subscribe(resp => {
      this.review = resp;
    });
  }
  ngOnInit() {
    if (!this.cpControlName) {
      this.log.warn('AppReviewCaptchaComponent -> cpControlName should be provided.');
    }
    if (!this.cpFormGroup) {
      this.log.warn('AppReviewCaptchaComponent -> cpFormGroup should be provided.');
    }
    this.cpId = this.cpControlName;
  }
  // --
  onClick(event) {
    if (event.checked && !this.review.captchaToken) {
      window.hcaptcha.execute();
    }
  }
  // --
  hasError() {
    return (0,_cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_2__.shouldShowErrors)(this.cpFormGroup.get(this.cpControlName));
  }
  // --
  get captchaFormControl() {
    return this.cpFormGroup.get(this.cpControlName);
  }
}
AppReviewCaptchaComponent.ɵfac = function AppReviewCaptchaComponent_Factory(t) {
  return new (t || AppReviewCaptchaComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_cra_arc_rccr_core__WEBPACK_IMPORTED_MODULE_4__.LogService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_services_result_result_service__WEBPACK_IMPORTED_MODULE_0__.ResultService));
};
AppReviewCaptchaComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
  type: AppReviewCaptchaComponent,
  selectors: [["app-review-captcha"]],
  inputs: {
    cpControlName: "cpControlName",
    cpFormGroup: "cpFormGroup"
  },
  decls: 13,
  vars: 19,
  consts: [[3, "ngClass"], [1, "mrgn-bttm-sm", "required"], [3, "innerHTML"], [3, "form", "controlName"], ["reviewCaptcha", "", 1, "checkbox", "h-captcha", 3, "formGroup"], [3, "for"], ["type", "checkbox", 3, "formControlName", "rccrFocusable", "click"]],
  template: function AppReviewCaptchaComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 0)(1, "fieldset")(2, "legend", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](4, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](5, "span", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](6, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](7, "rccr-field-error-marker", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](8, "div", 4)(9, "label", 5)(10, "input", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function AppReviewCaptchaComponent_Template_input_click_10_listener($event) {
        return ctx.onClick($event.target);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](11);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](12, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction1"](17, _c0, ctx.hasError()));
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](4, 11, "app.review.certification.title"), " \u00A0");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("innerHTML", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](6, 13, "required_label"), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsanitizeHtml"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("form", ctx.cpFormGroup)("controlName", ctx.cpControlName);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("formGroup", ctx.cpFormGroup);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpropertyInterpolate"]("for", ctx.cpId);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("formControlName", ctx.cpControlName)("rccrFocusable", ctx.cpControlName);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵattribute"]("id", ctx.cpId);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](12, 15, "app.review.certification.read.and.agreed.conditions"), " ");
    }
  },
  dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.NgClass, _cra_arc_rccr_core__WEBPACK_IMPORTED_MODULE_4__.FocusableDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.CheckboxControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormControlName, _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_2__.FieldErrorMarkerComponent, _app_review_captcha_directive__WEBPACK_IMPORTED_MODULE_1__.AppReviewCaptchaDirective, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__.TranslatePipe],
  encapsulation: 2
});

/***/ }),

/***/ 5286:
/*!******************************************************************************!*\
  !*** ./src/app/components/templates/captcha/app-review-captcha.directive.ts ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppReviewCaptchaDirective: () => (/* binding */ AppReviewCaptchaDirective)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var src_app_services_app_configuration_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/services/app-configuration.service */ 3148);
/* harmony import */ var src_app_services_result_result_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/result/result.service */ 1392);



class AppReviewCaptchaDirective {
  constructor(configurationService, elementRef, infoService, zone) {
    this.configurationService = configurationService;
    this.elementRef = elementRef;
    this.infoService = infoService;
    this.zone = zone;
    infoService.review.subscribe(resp => {
      this.review = resp;
    });
  }
  ngOnInit() {
    setTimeout(() => {
      window.hcaptcha.render(this.elementRef.nativeElement, {
        sitekey: this.configurationService.captchaKey,
        size: 'invisible',
        callback: response => {
          this.zone.run(() => {
            this.review.captchaToken = response;
            this.infoService.review.next(this.review);
          });
        }
      });
    });
  }
}
AppReviewCaptchaDirective.ɵfac = function AppReviewCaptchaDirective_Factory(t) {
  return new (t || AppReviewCaptchaDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](src_app_services_app_configuration_service__WEBPACK_IMPORTED_MODULE_0__.AppConfigurationService), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_2__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](src_app_services_result_result_service__WEBPACK_IMPORTED_MODULE_1__.ResultService), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgZone));
};
AppReviewCaptchaDirective.ɵdir = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineDirective"]({
  type: AppReviewCaptchaDirective,
  selectors: [["", "reviewCaptcha", ""]]
});

/***/ }),

/***/ 1284:
/*!*************************************************************************************!*\
  !*** ./src/app/components/templates/denotes-required/denotes-required.component.ts ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DenotesRequiredComponent: () => (/* binding */ DenotesRequiredComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ngx-translate/core */ 5939);


class DenotesRequiredComponent {
  constructor() {}
}
DenotesRequiredComponent.ɵfac = function DenotesRequiredComponent_Factory(t) {
  return new (t || DenotesRequiredComponent)();
};
DenotesRequiredComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
  type: DenotesRequiredComponent,
  selectors: [["denotes-required"]],
  decls: 2,
  vars: 3,
  consts: [["aria-hidden", "true", 1, "mrgn-bttm-lg", "mrgn-tp-md", 3, "innerHTML"]],
  template: function DenotesRequiredComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "p", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](1, "translate");
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("innerHTML", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](1, 1, "denotes_required"), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeHtml"]);
    }
  },
  dependencies: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_1__.TranslatePipe],
  encapsulation: 2
});

/***/ }),

/***/ 776:
/*!***********************************************************************!*\
  !*** ./src/app/components/templates/edit-icon/edit-icon.component.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   EditIconComponent: () => (/* binding */ EditIconComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ 7947);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngx-translate/core */ 5939);



class EditIconComponent {
  constructor() {
    this.rueLink = '/entry';
  }
  ngOnInit() {}
}
EditIconComponent.ɵfac = function EditIconComponent_Factory(t) {
  return new (t || EditIconComponent)();
};
EditIconComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
  type: EditIconComponent,
  selectors: [["app-edit-icon"]],
  inputs: {
    rueLink: "rueLink"
  },
  decls: 4,
  vars: 4,
  consts: [["type", "button", 1, "btn", "btn-default", "mrgn-rght-sm", 3, "routerLink"], [1, "fa", "fa-edit"]],
  template: function EditIconComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "button", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "span", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](3, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("routerLink", ctx.rueLink);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](3, 2, "edit"), "\n");
    }
  },
  dependencies: [_angular_router__WEBPACK_IMPORTED_MODULE_1__.RouterLink, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__.TranslatePipe],
  styles: [".editIcon[_ngcontent-%COMP%]{\n    padding-right: 2px;\n    font-size:22px;\n    color: black;\n}\n.editText[_ngcontent-%COMP%] {\n    font-weight:normal;\n    font-size:16px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29tcG9uZW50cy90ZW1wbGF0ZXMvZWRpdC1pY29uL2VkaXQtaWNvbi5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksa0JBQWtCO0lBQ2xCLGNBQWM7SUFDZCxZQUFZO0FBQ2hCO0FBQ0E7SUFDSSxrQkFBa0I7SUFDbEIsY0FBYztBQUNsQiIsInNvdXJjZXNDb250ZW50IjpbIi5lZGl0SWNvbntcclxuICAgIHBhZGRpbmctcmlnaHQ6IDJweDtcclxuICAgIGZvbnQtc2l6ZToyMnB4O1xyXG4gICAgY29sb3I6IGJsYWNrO1xyXG59XHJcbi5lZGl0VGV4dCB7XHJcbiAgICBmb250LXdlaWdodDpub3JtYWw7XHJcbiAgICBmb250LXNpemU6MTZweDtcclxufSJdLCJzb3VyY2VSb290IjoiIn0= */"]
});

/***/ }),

/***/ 3779:
/*!***********************************************************************************!*\
  !*** ./src/app/components/templates/expand-collapse/expand-collapse.component.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ExpandCollapseComponent: () => (/* binding */ ExpandCollapseComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @cra-arc/rccr-wet */ 399);


class ExpandCollapseComponent {
  ngOnInit() {}
}
ExpandCollapseComponent.ɵfac = function ExpandCollapseComponent_Factory(t) {
  return new (t || ExpandCollapseComponent)();
};
ExpandCollapseComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
  type: ExpandCollapseComponent,
  selectors: [["app-expand-collapse"]],
  inputs: {
    summaryText: "summaryText",
    mainText: "mainText"
  },
  decls: 9,
  vars: 2,
  consts: [["rccrWetDetails", ""]],
  template: function ExpandCollapseComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div")(1, "details", 0)(2, "summary")(3, "strong");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "div")(6, "p");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](7);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8, "> ");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx.summaryText);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", ctx.mainText, "");
    }
  },
  dependencies: [_cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_1__.WetDetailsDirective],
  styles: ["summary[_ngcontent-%COMP%] {\n    border-color: #58ACFA;\n    background-color: #A9F5E1;\n    \n}\n\nb[_ngcontent-%COMP%] {\n    color:black;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29tcG9uZW50cy90ZW1wbGF0ZXMvZXhwYW5kLWNvbGxhcHNlL2V4cGFuZC1jb2xsYXBzZS5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0kscUJBQXFCO0lBQ3JCLHlCQUF5Qjs7QUFFN0I7O0FBRUE7SUFDSSxXQUFXO0FBQ2YiLCJzb3VyY2VzQ29udGVudCI6WyJzdW1tYXJ5IHtcclxuICAgIGJvcmRlci1jb2xvcjogIzU4QUNGQTtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNBOUY1RTE7XHJcbiAgICBcclxufVxyXG5cclxuYiB7XHJcbiAgICBjb2xvcjpibGFjaztcclxufSJdLCJzb3VyY2VSb290IjoiIn0= */"]
});

/***/ }),

/***/ 791:
/*!***********************************************************************!*\
  !*** ./src/app/components/templates/help-icon/help-icon.component.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HelpIconComponent: () => (/* binding */ HelpIconComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @cra-arc/rccr-wet */ 399);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngx-translate/core */ 5939);



class HelpIconComponent {
  constructor() {
    this.labelKey = 'labelKey';
    this.helpKey = 'helpKey';
    this.helpText = 'helpText';
    this.id = '';
  }
  ngOnInit() {}
}
HelpIconComponent.ɵfac = function HelpIconComponent_Factory(t) {
  return new (t || HelpIconComponent)();
};
HelpIconComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
  type: HelpIconComponent,
  selectors: [["app-help-icon"]],
  inputs: {
    labelKey: "labelKey",
    helpKey: "helpKey",
    helpText: "helpText",
    form: "form",
    id: "id"
  },
  decls: 5,
  vars: 14,
  consts: [[3, "labelKey", "form", "id", "controlName", "required", "helpAccessibleTextKey", "inlineHelpKey", "containsMarkup", "showHelp"]],
  template: function HelpIconComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div")(1, "rccr-label", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("showHelp", function HelpIconComponent_Template_rccr_label_showHelp_1_listener() {
        return false;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](2, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](3, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](4, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpropertyInterpolate"]("labelKey", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](2, 8, ctx.labelKey));
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpropertyInterpolate2"]("helpAccessibleTextKey", "", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](3, 10, "help.title"), "  ", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](4, 12, ctx.labelKey), "");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("form", ctx.form)("controlName", "labelControlName")("required", false)("inlineHelpKey", ctx.helpText)("containsMarkup", true);
    }
  },
  dependencies: [_cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_1__.LabelComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__.TranslatePipe],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
});

/***/ }),

/***/ 8564:
/*!*****************************************************************************************************!*\
  !*** ./src/app/components/templates/multiselect-button-group/multiselect-button-group.component.ts ***!
  \*****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MultiselectButtonGroupComponent: () => (/* binding */ MultiselectButtonGroupComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ 6575);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 8849);
/* harmony import */ var _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @cra-arc/rccr-wet */ 399);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngx-translate/core */ 5939);





function MultiselectButtonGroupComponent_rccr_checkbox_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "rccr-checkbox", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const checkBox_r1 = ctx.$implicit;
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("form", ctx_r0.form)("formControlName", ctx_r0.controlName)("value", checkBox_r1)("id", checkBox_r1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](2, 5, checkBox_r1), " ");
  }
}
class MultiselectButtonGroupComponent {
  constructor() {
    this.legendKey = 'legendKey';
    this.helpKey = '';
    this.helpText = '';
    this.checkBoxList = ['First checkbox', 'Second checkbox'];
    this.controlName = 'checkBoxGrp';
    this.subtextKey = '';
  }
  ngOnInit() {}
}
MultiselectButtonGroupComponent.ɵfac = function MultiselectButtonGroupComponent_Factory(t) {
  return new (t || MultiselectButtonGroupComponent)();
};
MultiselectButtonGroupComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
  type: MultiselectButtonGroupComponent,
  selectors: [["app-multiselect-button-group"]],
  inputs: {
    legendKey: "legendKey",
    form: "form",
    checkBoxGrp: "checkBoxGrp",
    helpKey: "helpKey",
    helpText: "helpText",
    checkBoxList: "checkBoxList",
    controlName: "controlName",
    subtextKey: "subtextKey"
  },
  decls: 4,
  vars: 12,
  consts: [["form", "", 3, "formGroup"], [3, "legendKey", "form", "controlName", "required", "helpAccessibleTextKey", "inlineHelpKey", "containsMarkup", "id"], ["ngDefaultControl", "", 3, "form", "formControlName", "value", "id", 4, "ngFor", "ngForOf"], ["ngDefaultControl", "", 3, "form", "formControlName", "value", "id"]],
  template: function MultiselectButtonGroupComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0)(1, "rccr-button-group", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](2, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, MultiselectButtonGroupComponent_rccr_checkbox_3_Template, 3, 7, "rccr-checkbox", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("formGroup", ctx.form);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpropertyInterpolate"]("legendKey", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](2, 10, ctx.legendKey));
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("form", ctx.form)("controlName", ctx.controlName)("required", true)("helpAccessibleTextKey", ctx.helpKey)("inlineHelpKey", ctx.helpText)("containsMarkup", true)("id", ctx.controlName);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.checkBoxList);
    }
  },
  dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.NgForOf, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControlName, _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_3__.ButtonGroupComponent, _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_3__.CheckboxComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__.TranslatePipe],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
});

/***/ }),

/***/ 5386:
/*!***********************************************************************!*\
  !*** ./src/app/components/templates/need-help/need-help.component.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   NeedHelpComponent: () => (/* binding */ NeedHelpComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ngx-translate/core */ 5939);


class NeedHelpComponent {
  constructor() {
    this.needHelp = 'need.help';
    this.link = 'entry.main.contactLink';
  }
  ngOnInit() {}
}
NeedHelpComponent.ɵfac = function NeedHelpComponent_Factory(t) {
  return new (t || NeedHelpComponent)();
};
NeedHelpComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
  type: NeedHelpComponent,
  selectors: [["app-need-help"]],
  inputs: {
    needHelp: "needHelp",
    link: "link"
  },
  decls: 12,
  vars: 9,
  consts: [[2, "padding-right", "30px"], ["rel", "noopener noreferrer", "target", "_blank", 3, "href"], [1, "phoneIcon"], [1, "fa", "fa-phone"], [3, "innerHTML"], [1, "wb-inv"]],
  template: function NeedHelpComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "br")(2, "br");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "a", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](4, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "span", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](6, "i", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](7, "span", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](8, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "span", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](11, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpropertyInterpolate"]("href", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](4, 3, ctx.link), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("innerHTML", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](8, 5, ctx.needHelp), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeHtml"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](11, 7, "new.window.note"));
    }
  },
  dependencies: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_1__.TranslatePipe],
  styles: [".phoneIcon[_ngcontent-%COMP%]{\n    padding-right:5px;\n    font-size:24px;\n    color: black;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29tcG9uZW50cy90ZW1wbGF0ZXMvbmVlZC1oZWxwL25lZWQtaGVscC5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksaUJBQWlCO0lBQ2pCLGNBQWM7SUFDZCxZQUFZO0FBQ2hCIiwic291cmNlc0NvbnRlbnQiOlsiLnBob25lSWNvbntcclxuICAgIHBhZGRpbmctcmlnaHQ6NXB4O1xyXG4gICAgZm9udC1zaXplOjI0cHg7XHJcbiAgICBjb2xvcjogYmxhY2s7XHJcbn0iXSwic291cmNlUm9vdCI6IiJ9 */"]
});

/***/ }),

/***/ 9704:
/*!*****************************************************************************************!*\
  !*** ./src/app/components/templates/page-details-local/page-details-local.component.ts ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PageDetailsLocalComponent: () => (/* binding */ PageDetailsLocalComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @cra-arc/rccr-wet */ 399);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngx-translate/core */ 5939);



class PageDetailsLocalComponent {
  constructor() {
    this.version = '';
    this.date = new Date();
    this.screenId = '';
  }
  ngOnInit() {
    this.version = this.date.getFullYear() + '-' + (this.date.getMonth() + 1) + '-' + this.date.getDate();
  }
}
PageDetailsLocalComponent.ɵfac = function PageDetailsLocalComponent_Factory(t) {
  return new (t || PageDetailsLocalComponent)();
};
PageDetailsLocalComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
  type: PageDetailsLocalComponent,
  selectors: [["app-page-details-local"]],
  inputs: {
    screenId: "screenId"
  },
  decls: 2,
  vars: 4,
  consts: [[3, "screenId", "version"]],
  template: function PageDetailsLocalComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "rccr-page-details", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](1, "translate");
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpropertyInterpolate"]("screenId", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](1, 2, ctx.screenId));
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("version", "application.version");
    }
  },
  dependencies: [_cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_1__.PageDetailsComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__.TranslatePipe],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
});

/***/ }),

/***/ 3641:
/*!*****************************************************************************************!*\
  !*** ./src/app/components/templates/page-heading-local/page-heading-local.component.ts ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PageHeadingLocalComponent: () => (/* binding */ PageHeadingLocalComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @cra-arc/rccr-wet */ 399);


class PageHeadingLocalComponent {
  constructor() {
    this.pageHeading = 'Welcome';
  }
  ngOnInit() {}
}
PageHeadingLocalComponent.ɵfac = function PageHeadingLocalComponent_Factory(t) {
  return new (t || PageHeadingLocalComponent)();
};
PageHeadingLocalComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
  type: PageHeadingLocalComponent,
  selectors: [["app-page-heading-local"]],
  inputs: {
    pageHeading: "pageHeading"
  },
  decls: 1,
  vars: 1,
  consts: [[3, "titleKey"]],
  template: function PageHeadingLocalComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "rccr-page-heading", 0);
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("titleKey", ctx.pageHeading);
    }
  },
  dependencies: [_cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_1__.PageHeadingComponent],
  styles: [".titleStyle[_ngcontent-%COMP%] {\n\tcolor: #335075;\n}\n\n.greyTitle[_ngcontent-%COMP%] {\n\tcolor: lightslategray;\n\tfont-size: 25px; \n}\n\n\n\n.heading-line[_ngcontent-%COMP%] {\n\tdisplay:block;\n  }\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29tcG9uZW50cy90ZW1wbGF0ZXMvcGFnZS1oZWFkaW5nLWxvY2FsL3BhZ2UtaGVhZGluZy1sb2NhbC5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0NBQ0MsY0FBYztBQUNmOztBQUVBO0NBQ0MscUJBQXFCO0NBQ3JCLGVBQWU7QUFDaEI7O0FBRUEsaUNBQWlDO0FBQ2pDO0NBQ0MsYUFBYTtFQUNaIiwic291cmNlc0NvbnRlbnQiOlsiLnRpdGxlU3R5bGUge1xyXG5cdGNvbG9yOiAjMzM1MDc1O1xyXG59XHJcblxyXG4uZ3JleVRpdGxlIHtcclxuXHRjb2xvcjogbGlnaHRzbGF0ZWdyYXk7XHJcblx0Zm9udC1zaXplOiAyNXB4OyBcclxufVxyXG5cclxuLyogLS0tIFBhZ2UgaGVhZGluZyAoMiBwYXJ0KSAtLS0qL1xyXG4uaGVhZGluZy1saW5lIHtcclxuXHRkaXNwbGF5OmJsb2NrO1xyXG4gIH0iXSwic291cmNlUm9vdCI6IiJ9 */"]
});

/***/ }),

/***/ 5401:
/*!*************************************************************************************************!*\
  !*** ./src/app/components/templates/placeholder-text-input/placeholder-text-input.component.ts ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PlaceholderTextInputComponent: () => (/* binding */ PlaceholderTextInputComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ 6575);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 8849);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngx-translate/core */ 5939);




function PlaceholderTextInputComponent_span_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](2, 1, "error_field_req"), " ");
  }
}
class PlaceholderTextInputComponent {
  constructor() {
    this.maxLength = 150;
    this.size = 40;
    this.placeHldTxt = "Placeholder text";
  }
  ngOnInit() {}
}
PlaceholderTextInputComponent.ɵfac = function PlaceholderTextInputComponent_Factory(t) {
  return new (t || PlaceholderTextInputComponent)();
};
PlaceholderTextInputComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
  type: PlaceholderTextInputComponent,
  selectors: [["app-placeholder-text-input"]],
  inputs: {
    form: "form",
    textInput: "textInput",
    maxLength: "maxLength",
    size: "size",
    placeHldTxt: "placeHldTxt"
  },
  decls: 4,
  vars: 8,
  consts: [["form", "", 3, "formGroup"], ["class", "strong error label label-danger label-error", 4, "ngIf"], ["type", "text", "name", "placeholder", 1, "form-control", 3, "maxlength", "formControl", "size", "placeholder"], [1, "strong", "error", "label", "label-danger", "label-error"]],
  template: function PlaceholderTextInputComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, PlaceholderTextInputComponent_span_1_Template, 3, 3, "span", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "input", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](3, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("formGroup", ctx.form);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.textInput.hasError("required") && ctx.textInput.dirty);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpropertyInterpolate"]("maxlength", ctx.maxLength);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpropertyInterpolate"]("size", ctx.size);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpropertyInterpolate"]("placeholder", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](3, 6, ctx.placeHldTxt));
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("formControl", ctx.textInput);
    }
  },
  dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.MaxLengthValidator, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControlDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormGroupDirective, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__.TranslatePipe],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
});

/***/ }),

/***/ 6297:
/*!***********************************************************************************!*\
  !*** ./src/app/components/templates/print-save-icon/print-save-icon.component.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PrintSaveIconComponent: () => (/* binding */ PrintSaveIconComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ngx-translate/core */ 5939);


class PrintSaveIconComponent {}
PrintSaveIconComponent.ɵfac = function PrintSaveIconComponent_Factory(t) {
  return new (t || PrintSaveIconComponent)();
};
PrintSaveIconComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
  type: PrintSaveIconComponent,
  selectors: [["app-print-save-icon"]],
  decls: 11,
  vars: 6,
  consts: [[1, "row"], [1, "col-xs-12"], [1, "pull-right", "mrgn-tp-md", "hidden-print"], ["type", "button", "onClick", "window.print()", 1, "btn", "btn-default", "mrgn-rght-md", "hidden-print"], [1, "fa", "fa-print"], [1, "fa", "fa-save"]],
  template: function PrintSaveIconComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "button", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](4, "span", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](6, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "button", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](8, "span", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](9);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](10, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](6, 2, "print"), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](10, 4, "save"), " ");
    }
  },
  dependencies: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_1__.TranslatePipe],
  styles: [".printIcon[_ngcontent-%COMP%]{\n    padding-right:4px;\n    font-size:26px;\n    cursor: pointer;\n}\n\n.printText[_ngcontent-%COMP%]{\n    padding-right:10px;\n    cursor: pointer;\n}\n\n.saveIcon[_ngcontent-%COMP%]{\n    padding-right:4px;\n    font-size:22px;\n    font-weight: 900;\n    cursor: pointer;\n}\n\n.saveText[_ngcontent-%COMP%]{\n    padding-right:2px;\n    cursor: pointer;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29tcG9uZW50cy90ZW1wbGF0ZXMvcHJpbnQtc2F2ZS1pY29uL3ByaW50LXNhdmUtaWNvbi5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksaUJBQWlCO0lBQ2pCLGNBQWM7SUFDZCxlQUFlO0FBQ25COztBQUVBO0lBQ0ksa0JBQWtCO0lBQ2xCLGVBQWU7QUFDbkI7O0FBRUE7SUFDSSxpQkFBaUI7SUFDakIsY0FBYztJQUNkLGdCQUFnQjtJQUNoQixlQUFlO0FBQ25COztBQUVBO0lBQ0ksaUJBQWlCO0lBQ2pCLGVBQWU7QUFDbkIiLCJzb3VyY2VzQ29udGVudCI6WyIucHJpbnRJY29ue1xyXG4gICAgcGFkZGluZy1yaWdodDo0cHg7XHJcbiAgICBmb250LXNpemU6MjZweDtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG5cclxuLnByaW50VGV4dHtcclxuICAgIHBhZGRpbmctcmlnaHQ6MTBweDtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG5cclxuLnNhdmVJY29ue1xyXG4gICAgcGFkZGluZy1yaWdodDo0cHg7XHJcbiAgICBmb250LXNpemU6MjJweDtcclxuICAgIGZvbnQtd2VpZ2h0OiA5MDA7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuXHJcbi5zYXZlVGV4dHtcclxuICAgIHBhZGRpbmctcmlnaHQ6MnB4O1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG59Il0sInNvdXJjZVJvb3QiOiIifQ== */"]
});

/***/ }),

/***/ 5396:
/*!*****************************************************************************************!*\
  !*** ./src/app/components/templates/radio-button-group/radio-button-group.component.ts ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   RadioButtonGroupComponent: () => (/* binding */ RadioButtonGroupComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ 6575);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 8849);
/* harmony import */ var _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @cra-arc/rccr-wet */ 399);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngx-translate/core */ 5939);





function RadioButtonGroupComponent_rccr_radio_button_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "rccr-radio-button", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const radioBtn_r1 = ctx.$implicit;
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("form", ctx_r0.form)("formControlName", ctx_r0.controlName)("value", radioBtn_r1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](2, 4, radioBtn_r1), " ");
  }
}
class RadioButtonGroupComponent {
  constructor() {
    this.labelKey = 'labelKey';
    this.legendKey = 'legendKey';
    this.helpKey = '';
    this.helpText = '';
    this.radioBtnList = ['First Radio', 'Second Radio'];
    this.controlName = 'radioBtnGrp';
    this.subtextKey = '';
    this.isRequired = true;
  }
  ngOnInit() {}
}
RadioButtonGroupComponent.ɵfac = function RadioButtonGroupComponent_Factory(t) {
  return new (t || RadioButtonGroupComponent)();
};
RadioButtonGroupComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
  type: RadioButtonGroupComponent,
  selectors: [["app-radio-button-group"]],
  inputs: {
    labelKey: "labelKey",
    legendKey: "legendKey",
    form: "form",
    radioBtnGrp: "radioBtnGrp",
    helpKey: "helpKey",
    helpText: "helpText",
    radioBtnList: "radioBtnList",
    controlName: "controlName",
    subtextKey: "subtextKey",
    isRequired: "isRequired"
  },
  decls: 6,
  vars: 18,
  consts: [["form", "", 3, "formGroup"], [3, "id", "legendKey", "form", "controlName", "required", "helpAccessibleTextKey", "inlineHelpKey", "subtextKey", "containsMarkup"], ["ngDefaultControl", "", 3, "form", "formControlName", "value", 4, "ngFor", "ngForOf"], ["ngDefaultControl", "", 3, "form", "formControlName", "value"]],
  template: function RadioButtonGroupComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0)(1, "rccr-button-group", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](2, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](3, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](4, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, RadioButtonGroupComponent_rccr_radio_button_5_Template, 3, 6, "rccr-radio-button", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("formGroup", ctx.form);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpropertyInterpolate"]("legendKey", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](2, 12, ctx.legendKey));
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpropertyInterpolate2"]("helpAccessibleTextKey", "", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](3, 14, "help.title"), "  ", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](4, 16, ctx.legendKey), "");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("id", ctx.controlName)("form", ctx.form)("controlName", ctx.controlName)("required", ctx.isRequired)("inlineHelpKey", ctx.helpText)("subtextKey", ctx.subtextKey)("containsMarkup", true);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.radioBtnList);
    }
  },
  dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.NgForOf, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControlName, _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_3__.ButtonGroupComponent, _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_3__.RadioButtonComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__.TranslatePipe],
  styles: [".spacing[_ngcontent-%COMP%]{\n    padding-bottom: 3px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29tcG9uZW50cy90ZW1wbGF0ZXMvcmFkaW8tYnV0dG9uLWdyb3VwL3JhZGlvLWJ1dHRvbi1ncm91cC5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksbUJBQW1CO0FBQ3ZCIiwic291cmNlc0NvbnRlbnQiOlsiLnNwYWNpbmd7XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogM3B4O1xyXG59Il0sInNvdXJjZVJvb3QiOiIifQ== */"]
});

/***/ }),

/***/ 9015:
/*!*******************************************************************************************!*\
  !*** ./src/app/components/templates/return-summary-link/return-summary-link.component.ts ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ReturnSummaryLinkComponent: () => (/* binding */ ReturnSummaryLinkComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ngx-translate/core */ 5939);


class ReturnSummaryLinkComponent {
  constructor() {
    this.rueLink = '/entry';
  }
  ngOnInit() {}
}
ReturnSummaryLinkComponent.ɵfac = function ReturnSummaryLinkComponent_Factory(t) {
  return new (t || ReturnSummaryLinkComponent)();
};
ReturnSummaryLinkComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
  type: ReturnSummaryLinkComponent,
  selectors: [["app-return-summary-link"]],
  inputs: {
    rueLink: "rueLink"
  },
  decls: 2,
  vars: 3,
  consts: [["id", "prv", "type", "submit", 1, "btn", "btn-default", 3, "value"]],
  template: function ReturnSummaryLinkComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "input", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](1, "translate");
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpropertyInterpolate"]("value", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](1, 1, "return.summary"));
    }
  },
  dependencies: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_1__.TranslatePipe],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
});

/***/ }),

/***/ 1434:
/*!*****************************************************************************!*\
  !*** ./src/app/components/templates/select-local/select-local.component.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SelectLocalComponent: () => (/* binding */ SelectLocalComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ 6575);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 8849);
/* harmony import */ var _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @cra-arc/rccr-wet */ 399);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngx-translate/core */ 5939);





function SelectLocalComponent_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "option", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const selectStr_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", selectStr_r1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](3, 2, selectStr_r1));
  }
}
class SelectLocalComponent {
  constructor() {
    this.selectList = ['01', '02'];
    this.labelKey = 'labelKey';
  }
  ngOnInit() {}
}
SelectLocalComponent.ɵfac = function SelectLocalComponent_Factory(t) {
  return new (t || SelectLocalComponent)();
};
SelectLocalComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
  type: SelectLocalComponent,
  selectors: [["app-select-local"]],
  inputs: {
    selectList: "selectList",
    form: "form",
    selectLocal: "selectLocal",
    labelKey: "labelKey"
  },
  decls: 4,
  vars: 9,
  consts: [["form", "", 3, "formGroup"], ["ngDefaultControl", "", 3, "form", "formControlName", "labelKey", "required", "labelContainsMarkup"], [4, "ngFor", "ngForOf"], [3, "value"]],
  template: function SelectLocalComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0)(1, "rccr-select", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](2, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, SelectLocalComponent_ng_container_3_Template, 4, 4, "ng-container", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("formGroup", ctx.form);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpropertyInterpolate"]("labelKey", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](2, 7, ctx.labelKey));
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("form", ctx.form)("formControlName", ctx.selectLocal)("required", true)("labelContainsMarkup", true);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.selectList);
    }
  },
  dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.NgForOf, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.RequiredValidator, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControlName, _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_3__.SelectComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__.TranslatePipe],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
});

/***/ }),

/***/ 3521:
/*!***********************************************************************!*\
  !*** ./src/app/components/templates/text-area/text-area.component.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TextAreaComponent: () => (/* binding */ TextAreaComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ 8849);
/* harmony import */ var _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @cra-arc/rccr-wet */ 399);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngx-translate/core */ 5939);




const _c0 = function () {
  return {
    "rows": "3",
    "cols": "130",
    "maxLength": "250"
  };
};
class TextAreaComponent {
  constructor() {
    this.lableKey = '';
    this.helpKey = '';
    this.helpText = '';
  }
  ngOnInit() {}
}
TextAreaComponent.ɵfac = function TextAreaComponent_Factory(t) {
  return new (t || TextAreaComponent)();
};
TextAreaComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
  type: TextAreaComponent,
  selectors: [["app-text-area"]],
  inputs: {
    form: "form",
    textArea: "textArea",
    lableKey: "lableKey",
    helpKey: "helpKey",
    helpText: "helpText"
  },
  decls: 3,
  vars: 11,
  consts: [["form", "", 3, "formGroup"], ["ngDefaultControl", "", "formControlName", "textArea", 3, "form", "labelKey", "required", "labelContainsMarkup", "attributes", "helpAccessibleTextKey", "inlineHelpKey"]],
  template: function TextAreaComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "rccr-textarea", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](2, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("formGroup", ctx.form);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpropertyInterpolate"]("labelKey", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](2, 8, ctx.lableKey));
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("form", ctx.form)("required", false)("labelContainsMarkup", true)("attributes", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](10, _c0))("helpAccessibleTextKey", ctx.helpKey)("inlineHelpKey", ctx.helpText);
    }
  },
  dependencies: [_angular_forms__WEBPACK_IMPORTED_MODULE_1__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_1__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_1__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_1__.RequiredValidator, _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormControlName, _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_2__.TextareaComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__.TranslatePipe],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
});

/***/ }),

/***/ 6453:
/*!*************************************************************************************!*\
  !*** ./src/app/components/templates/text-input-local/text-input-local.component.ts ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TextInputLocalComponent: () => (/* binding */ TextInputLocalComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ 8849);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngx-translate/core */ 5939);
/* harmony import */ var _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @cra-arc/rccr-wet */ 399);




class TextInputLocalComponent {
  constructor() {
    this.labelKey = 'labelKey';
    this.type = 'text';
    this.attributes = {
      "size": "20",
      "maxLength": "5"
    };
    this.requiredTag = true;
    this.subtextKey = '';
  }
  ngOnInit() {}
}
TextInputLocalComponent.ɵfac = function TextInputLocalComponent_Factory(t) {
  return new (t || TextInputLocalComponent)();
};
TextInputLocalComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
  type: TextInputLocalComponent,
  selectors: [["app-text-input-local"]],
  inputs: {
    labelKey: "labelKey",
    form: "form",
    textInput: "textInput",
    type: "type",
    attributes: "attributes",
    requiredTag: "requiredTag",
    subtextKey: "subtextKey"
  },
  decls: 2,
  vars: 8,
  consts: [["form", "", 3, "formGroup"], ["formControlName", "textInput", "translate", "", 3, "form", "type", "labelKey", "required", "labelContainsMarkup", "attributes", "subtextKey"]],
  template: function TextInputLocalComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "rccr-text-input", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("formGroup", ctx.form);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpropertyInterpolate"]("labelKey", ctx.labelKey);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("form", ctx.form)("type", ctx.type)("required", ctx.requiredTag)("labelContainsMarkup", true)("attributes", ctx.attributes)("subtextKey", ctx.subtextKey);
    }
  },
  dependencies: [_angular_forms__WEBPACK_IMPORTED_MODULE_1__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_1__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_1__.RequiredValidator, _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormControlName, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__.TranslateDirective, _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_3__.TextInputComponent],
  styles: ["/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
});

/***/ }),

/***/ 4615:
/*!*****************************************************************************************!*\
  !*** ./src/app/components/templates/yes-no-buttongroup/yes-no-buttongroup.component.ts ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   YesNoButtongroupComponent: () => (/* binding */ YesNoButtongroupComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ 8849);
/* harmony import */ var _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @cra-arc/rccr-wet */ 399);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngx-translate/core */ 5939);




class YesNoButtongroupComponent {
  constructor() {
    this.labelKey = 'labelKey';
    this.helpKey = '';
    this.helpText = '';
  }
  ngOnInit() {}
}
YesNoButtongroupComponent.ɵfac = function YesNoButtongroupComponent_Factory(t) {
  return new (t || YesNoButtongroupComponent)();
};
YesNoButtongroupComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
  type: YesNoButtongroupComponent,
  selectors: [["app-yes-no-buttongroup"]],
  inputs: {
    labelKey: "labelKey",
    helpKey: "helpKey",
    helpText: "helpText",
    form: "form",
    yesNo: "yesNo"
  },
  decls: 12,
  vars: 25,
  consts: [["form", "", 3, "formGroup"], ["ngDefaultControl", "", 3, "form", "controlName", "legendKey", "required", "containsMarkup", "helpAccessibleTextKey", "inlineHelpKey"], ["ngDefaultControl", "", "formControlName", "yesNo", 3, "form", "value"]],
  template: function YesNoButtongroupComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0)(1, "rccr-button-group", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](2, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](3, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](4, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "rccr-button-toggle", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](7, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](8, "\u00A0\u00A0 ");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "rccr-button-toggle", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](11, "translate");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("formGroup", ctx.form);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpropertyInterpolate"]("legendKey", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](2, 15, ctx.labelKey));
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpropertyInterpolate2"]("helpAccessibleTextKey", "", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](3, 17, "help.title"), "  ", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](4, 19, ctx.labelKey), "");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("form", ctx.form)("controlName", "yesNo")("required", true)("containsMarkup", true)("inlineHelpKey", ctx.helpText);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("form", ctx.form)("value", "yes");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](7, 21, "yes"), " ");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("form", ctx.form)("value", "no");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](11, 23, "no"), " ");
    }
  },
  dependencies: [_angular_forms__WEBPACK_IMPORTED_MODULE_1__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_1__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_1__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormControlName, _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_2__.ButtonGroupComponent, _cra_arc_rccr_wet__WEBPACK_IMPORTED_MODULE_2__.ButtonToggleComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__.TranslatePipe],
  styles: ["table[_ngcontent-%COMP%]   td[_ngcontent-%COMP%] {\n    text-align: left;\n    vertical-align: text-top;\n    width: 20%;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29tcG9uZW50cy90ZW1wbGF0ZXMveWVzLW5vLWJ1dHRvbmdyb3VwL3llcy1uby1idXR0b25ncm91cC5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksZ0JBQWdCO0lBQ2hCLHdCQUF3QjtJQUN4QixVQUFVO0FBQ2QiLCJzb3VyY2VzQ29udGVudCI6WyJ0YWJsZSB0ZCB7XHJcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG4gICAgdmVydGljYWwtYWxpZ246IHRleHQtdG9wO1xyXG4gICAgd2lkdGg6IDIwJTtcclxufSJdLCJzb3VyY2VSb290IjoiIn0= */"]
});

/***/ }),

/***/ 3437:
/*!************************************!*\
  !*** ./src/app/model/complaint.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Complaint: () => (/* binding */ Complaint)
/* harmony export */ });
class Complaint {
  constructor() {
    this.complaintFeedback = '';
    this.canActive = false;
  }
}

/***/ }),

/***/ 4597:
/*!*************************************!*\
  !*** ./src/app/model/compliment.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Compliment: () => (/* binding */ Compliment)
/* harmony export */ });
class Compliment {
  constructor() {
    this.complimentFeedback = '';
    this.canActive = false;
  }
}

/***/ }),

/***/ 919:
/*!***************************************!*\
  !*** ./src/app/model/confirmation.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Confirmation: () => (/* binding */ Confirmation)
/* harmony export */ });
class Confirmation {
  constructor() {
    this.canActive = false;
  }
}

/***/ }),

/***/ 6404:
/*!********************************!*\
  !*** ./src/app/model/entry.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Entry: () => (/* binding */ Entry)
/* harmony export */ });
class Entry {
  constructor() {
    this.hasStart = false;
  }
}

/***/ }),

/***/ 2984:
/*!*********************************************!*\
  !*** ./src/app/model/generalInformation.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GeneralInformation: () => (/* binding */ GeneralInformation)
/* harmony export */ });
class GeneralInformation {
  constructor() {
    this.feedbackType = "";
    this.isRepondSuggestion = "";
    this.isRepondCompliment = "";
    this.onBehalf = "";
    this.isIndividualOrBusiness = "";
    this.firstName = "";
    this.lastName = "";
    this.businessName = "";
    this.businessNum = "";
    this.isCanada = "";
    this.country = "";
    this.mailingAddress = "";
    this.city = "";
    this.province = "";
    this.postalCode = "";
    this.mainPhone = "";
    this.altPhone = "";
    this.isSINorOtherAccountNum = "";
    this.sin = "";
    this.otherAccntNum = "";
    this.repFirstName = "";
    this.repLastName = "";
    this.repBusinessName = "";
    this.repBusinessNum = "";
    this.repMailingAddress = "";
    this.repCity = "";
    this.repProvince = "";
    this.repNum = "";
    this.repIsCanada = "";
    this.repCountry = "";
    this.repPostalCode = "";
    this.repMainPhone = "";
  }
}

/***/ }),

/***/ 2127:
/*!*********************************!*\
  !*** ./src/app/model/review.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Review: () => (/* binding */ Review)
/* harmony export */ });
class Review {
  constructor() {
    this.captchaToken = '';
    this.certifyBox = '';
    this.canActive = false;
    this.confirmationNumber = '';
    this.formSubmitted = false;
  }
}

/***/ }),

/***/ 9027:
/*!*************************************!*\
  !*** ./src/app/model/submission.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Submission: () => (/* binding */ Submission)
/* harmony export */ });
class Submission {}

/***/ }),

/***/ 9315:
/*!*************************************!*\
  !*** ./src/app/model/suggestion.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Suggestion: () => (/* binding */ Suggestion)
/* harmony export */ });
class Suggestion {
  constructor() {
    this.suggestionFeedback = '';
    this.canActive = false;
  }
}

/***/ }),

/***/ 3148:
/*!*******************************************************!*\
  !*** ./src/app/services/app-configuration.service.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppConfigurationService: () => (/* binding */ AppConfigurationService)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var _cra_arc_rccr_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @cra-arc/rccr-core */ 838);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ 4860);



const CONFIGURATION_SERVICE_URL = "/ebci/uisp/rc193/rest/api/config";
class AppConfigurationService {
  constructor(log, httpClient) {
    this.log = log;
    this.httpClient = httpClient;
  }
  getConfiguration() {
    let configPromise = new Promise((resolve, reject) => {
      this.httpClient.post(CONFIGURATION_SERVICE_URL, {}).subscribe(configuration => {
        this.captchaKey = configuration.captchaKey;
        resolve(configuration);
      }, () => {
        this.log.error("Configuration could not be retrieved.");
        reject();
      });
    });
    return configPromise;
  }
}
AppConfigurationService.ɵfac = function AppConfigurationService_Factory(t) {
  return new (t || AppConfigurationService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_cra_arc_rccr_core__WEBPACK_IMPORTED_MODULE_1__.LogService), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpClient));
};
AppConfigurationService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
  token: AppConfigurationService,
  factory: AppConfigurationService.ɵfac,
  providedIn: 'root'
});

/***/ }),

/***/ 2722:
/*!****************************************************!*\
  !*** ./src/app/services/app-submission.service.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppSubmissionService: () => (/* binding */ AppSubmissionService)
/* harmony export */ });
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common/http */ 4860);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngx-translate/core */ 5939);




const DATE_FORMAT = 'YYYY-MM-DD';
const SPACE = ' ';
const LANGUAGE_HEADER = "Accept-Language";
const SUBMISSION_SERVICE_URL = "/ebci/uisp/rc193/rest/api/submit";
class AppSubmissionService {
  constructor(httpClient, translateService) {
    this.httpClient = httpClient;
    this.translateService = translateService;
  }
  submitApplication(submission) {
    let submitPromise = new Promise((resolve, reject) => {
      const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_0__.HttpHeaders().set(LANGUAGE_HEADER, this.translateService.currentLang);
      this.httpClient.post(SUBMISSION_SERVICE_URL, submission, {
        headers: headers
      }).subscribe(submissionResponse => resolve(submissionResponse), () => reject());
    });
    return submitPromise;
  }
}
AppSubmissionService.ɵfac = function AppSubmissionService_Factory(t) {
  return new (t || AppSubmissionService)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_0__.HttpClient), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__.TranslateService));
};
AppSubmissionService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({
  token: AppSubmissionService,
  factory: AppSubmissionService.ɵfac,
  providedIn: 'root'
});

/***/ }),

/***/ 7036:
/*!************************************************************!*\
  !*** ./src/app/services/guards/complaint-grard.service.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ComplaintGrardService: () => (/* binding */ ComplaintGrardService)
/* harmony export */ });
/* harmony import */ var src_app_app_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/app-routing.module */ 3966);
/* harmony import */ var src_app_model_complaint__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/model/complaint */ 3437);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var _result_result_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../result/result.service */ 1392);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 7947);





class ComplaintGrardService {
  constructor(resultService, router) {
    this.resultService = resultService;
    this.router = router;
    this.complaint = new src_app_model_complaint__WEBPACK_IMPORTED_MODULE_1__.Complaint();
  }
  canActivate() {
    this.resultService.complaint.subscribe(resp => {
      this.complaint = resp;
    });
    if (this.complaint.canActive) {
      return true;
    } else {
      this.router.navigate([src_app_app_routing_module__WEBPACK_IMPORTED_MODULE_0__.ENTRY_PAGE]);
      return false;
    }
  }
}
ComplaintGrardService.ɵfac = function ComplaintGrardService_Factory(t) {
  return new (t || ComplaintGrardService)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_result_result_service__WEBPACK_IMPORTED_MODULE_2__.ResultService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_angular_router__WEBPACK_IMPORTED_MODULE_4__.Router));
};
ComplaintGrardService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({
  token: ComplaintGrardService,
  factory: ComplaintGrardService.ɵfac,
  providedIn: 'root'
});

/***/ }),

/***/ 4638:
/*!*************************************************************!*\
  !*** ./src/app/services/guards/compliment-grard.service.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ComplimentGrardService: () => (/* binding */ ComplimentGrardService)
/* harmony export */ });
/* harmony import */ var src_app_app_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/app-routing.module */ 3966);
/* harmony import */ var src_app_model_compliment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/model/compliment */ 4597);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var _result_result_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../result/result.service */ 1392);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 7947);





class ComplimentGrardService {
  constructor(resultService, router) {
    this.resultService = resultService;
    this.router = router;
    this.compliment = new src_app_model_compliment__WEBPACK_IMPORTED_MODULE_1__.Compliment();
  }
  canActivate() {
    this.resultService.compliment.subscribe(resp => {
      this.compliment = resp;
    });
    if (this.compliment.canActive) {
      return true;
    } else {
      this.router.navigate([src_app_app_routing_module__WEBPACK_IMPORTED_MODULE_0__.ENTRY_PAGE]);
      return false;
    }
  }
}
ComplimentGrardService.ɵfac = function ComplimentGrardService_Factory(t) {
  return new (t || ComplimentGrardService)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_result_result_service__WEBPACK_IMPORTED_MODULE_2__.ResultService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_angular_router__WEBPACK_IMPORTED_MODULE_4__.Router));
};
ComplimentGrardService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({
  token: ComplimentGrardService,
  factory: ComplimentGrardService.ɵfac,
  providedIn: 'root'
});

/***/ }),

/***/ 8521:
/*!***************************************************************!*\
  !*** ./src/app/services/guards/confirmation-grard.service.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ConfirmationGrardService: () => (/* binding */ ConfirmationGrardService)
/* harmony export */ });
/* harmony import */ var src_app_app_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/app-routing.module */ 3966);
/* harmony import */ var src_app_model_confirmation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/model/confirmation */ 919);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var _result_result_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../result/result.service */ 1392);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 7947);





class ConfirmationGrardService {
  constructor(resultService, router) {
    this.resultService = resultService;
    this.router = router;
    this.confirmation = new src_app_model_confirmation__WEBPACK_IMPORTED_MODULE_1__.Confirmation();
  }
  canActivate() {
    this.resultService.confirmation.subscribe(resp => {
      this.confirmation = resp;
    });
    if (this.confirmation.canActive) {
      return true;
    } else {
      this.router.navigate([src_app_app_routing_module__WEBPACK_IMPORTED_MODULE_0__.ENTRY_PAGE]);
      return false;
    }
  }
}
ConfirmationGrardService.ɵfac = function ConfirmationGrardService_Factory(t) {
  return new (t || ConfirmationGrardService)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_result_result_service__WEBPACK_IMPORTED_MODULE_2__.ResultService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_angular_router__WEBPACK_IMPORTED_MODULE_4__.Router));
};
ConfirmationGrardService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({
  token: ConfirmationGrardService,
  factory: ConfirmationGrardService.ɵfac,
  providedIn: 'root'
});

/***/ }),

/***/ 4055:
/*!***************************************************************!*\
  !*** ./src/app/services/guards/general-info-grard.service.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GeneralInfoGrardService: () => (/* binding */ GeneralInfoGrardService)
/* harmony export */ });
/* harmony import */ var src_app_app_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/app-routing.module */ 3966);
/* harmony import */ var src_app_model_entry__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/model/entry */ 6404);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var src_app_services_result_result_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/result/result.service */ 1392);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 7947);





class GeneralInfoGrardService {
  constructor(resultService, router) {
    this.resultService = resultService;
    this.router = router;
    this.entry = new src_app_model_entry__WEBPACK_IMPORTED_MODULE_1__.Entry();
  }
  canActivate() {
    this.resultService.entry.subscribe(resp => {
      this.entry = resp;
    });
    if (this.entry.hasStart) {
      return true;
    } else {
      this.router.navigate([src_app_app_routing_module__WEBPACK_IMPORTED_MODULE_0__.ENTRY_PAGE]);
      return false;
    }
  }
}
GeneralInfoGrardService.ɵfac = function GeneralInfoGrardService_Factory(t) {
  return new (t || GeneralInfoGrardService)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](src_app_services_result_result_service__WEBPACK_IMPORTED_MODULE_2__.ResultService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_angular_router__WEBPACK_IMPORTED_MODULE_4__.Router));
};
GeneralInfoGrardService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({
  token: GeneralInfoGrardService,
  factory: GeneralInfoGrardService.ɵfac,
  providedIn: 'root'
});

/***/ }),

/***/ 3830:
/*!*********************************************************!*\
  !*** ./src/app/services/guards/review-grard.service.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ReviewGrardService: () => (/* binding */ ReviewGrardService)
/* harmony export */ });
/* harmony import */ var src_app_app_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/app-routing.module */ 3966);
/* harmony import */ var src_app_model_review__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/model/review */ 2127);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var _result_result_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../result/result.service */ 1392);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 7947);





class ReviewGrardService {
  constructor(resultService, router) {
    this.resultService = resultService;
    this.router = router;
    this.review = new src_app_model_review__WEBPACK_IMPORTED_MODULE_1__.Review();
  }
  canActivate() {
    this.resultService.review.subscribe(resp => {
      this.review = resp;
    });
    if (this.review.canActive) {
      return true;
    } else {
      this.router.navigate([src_app_app_routing_module__WEBPACK_IMPORTED_MODULE_0__.ENTRY_PAGE]);
      return false;
    }
  }
}
ReviewGrardService.ɵfac = function ReviewGrardService_Factory(t) {
  return new (t || ReviewGrardService)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_result_result_service__WEBPACK_IMPORTED_MODULE_2__.ResultService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_angular_router__WEBPACK_IMPORTED_MODULE_4__.Router));
};
ReviewGrardService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({
  token: ReviewGrardService,
  factory: ReviewGrardService.ɵfac,
  providedIn: 'root'
});

/***/ }),

/***/ 2577:
/*!************************************************************!*\
  !*** ./src/app/services/guards/suggetion-grard.service.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SuggetionGrardService: () => (/* binding */ SuggetionGrardService)
/* harmony export */ });
/* harmony import */ var src_app_app_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/app-routing.module */ 3966);
/* harmony import */ var src_app_model_suggestion__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/model/suggestion */ 9315);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var _result_result_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../result/result.service */ 1392);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 7947);





class SuggetionGrardService {
  constructor(resultService, router) {
    this.resultService = resultService;
    this.router = router;
    this.suggestion = new src_app_model_suggestion__WEBPACK_IMPORTED_MODULE_1__.Suggestion();
  }
  canActivate() {
    this.resultService.suggestion.subscribe(resp => {
      this.suggestion = resp;
    });
    if (this.suggestion.canActive) {
      return true;
    } else {
      this.router.navigate([src_app_app_routing_module__WEBPACK_IMPORTED_MODULE_0__.ENTRY_PAGE]);
      return false;
    }
  }
}
SuggetionGrardService.ɵfac = function SuggetionGrardService_Factory(t) {
  return new (t || SuggetionGrardService)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_result_result_service__WEBPACK_IMPORTED_MODULE_2__.ResultService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_angular_router__WEBPACK_IMPORTED_MODULE_4__.Router));
};
SuggetionGrardService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({
  token: SuggetionGrardService,
  factory: SuggetionGrardService.ɵfac,
  providedIn: 'root'
});

/***/ }),

/***/ 1392:
/*!***************************************************!*\
  !*** ./src/app/services/result/result.service.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ResultService: () => (/* binding */ ResultService)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 8071);
/* harmony import */ var src_app_model_entry__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/model/entry */ 6404);
/* harmony import */ var src_app_model_generalInformation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/model/generalInformation */ 2984);
/* harmony import */ var src_app_model_complaint__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/model/complaint */ 3437);
/* harmony import */ var src_app_model_suggestion__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/model/suggestion */ 9315);
/* harmony import */ var src_app_model_compliment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/model/compliment */ 4597);
/* harmony import */ var src_app_model_review__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/model/review */ 2127);
/* harmony import */ var src_app_model_confirmation__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/model/confirmation */ 919);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 1699);









class ResultService {
  constructor() {
    this.entry = new rxjs__WEBPACK_IMPORTED_MODULE_7__.BehaviorSubject(new src_app_model_entry__WEBPACK_IMPORTED_MODULE_0__.Entry());
    this.generalInfo = new rxjs__WEBPACK_IMPORTED_MODULE_7__.BehaviorSubject(new src_app_model_generalInformation__WEBPACK_IMPORTED_MODULE_1__.GeneralInformation());
    this.complaint = new rxjs__WEBPACK_IMPORTED_MODULE_7__.BehaviorSubject(new src_app_model_complaint__WEBPACK_IMPORTED_MODULE_2__.Complaint());
    this.suggestion = new rxjs__WEBPACK_IMPORTED_MODULE_7__.BehaviorSubject(new src_app_model_suggestion__WEBPACK_IMPORTED_MODULE_3__.Suggestion());
    this.compliment = new rxjs__WEBPACK_IMPORTED_MODULE_7__.BehaviorSubject(new src_app_model_compliment__WEBPACK_IMPORTED_MODULE_4__.Compliment());
    this.review = new rxjs__WEBPACK_IMPORTED_MODULE_7__.BehaviorSubject(new src_app_model_review__WEBPACK_IMPORTED_MODULE_5__.Review());
    this.confirmation = new rxjs__WEBPACK_IMPORTED_MODULE_7__.BehaviorSubject(new src_app_model_confirmation__WEBPACK_IMPORTED_MODULE_6__.Confirmation());
  }
  reset() {
    this.entry = new rxjs__WEBPACK_IMPORTED_MODULE_7__.BehaviorSubject(new src_app_model_entry__WEBPACK_IMPORTED_MODULE_0__.Entry());
    this.generalInfo = new rxjs__WEBPACK_IMPORTED_MODULE_7__.BehaviorSubject(new src_app_model_generalInformation__WEBPACK_IMPORTED_MODULE_1__.GeneralInformation());
    this.complaint = new rxjs__WEBPACK_IMPORTED_MODULE_7__.BehaviorSubject(new src_app_model_complaint__WEBPACK_IMPORTED_MODULE_2__.Complaint());
    this.suggestion = new rxjs__WEBPACK_IMPORTED_MODULE_7__.BehaviorSubject(new src_app_model_suggestion__WEBPACK_IMPORTED_MODULE_3__.Suggestion());
    this.compliment = new rxjs__WEBPACK_IMPORTED_MODULE_7__.BehaviorSubject(new src_app_model_compliment__WEBPACK_IMPORTED_MODULE_4__.Compliment());
    this.review = new rxjs__WEBPACK_IMPORTED_MODULE_7__.BehaviorSubject(new src_app_model_review__WEBPACK_IMPORTED_MODULE_5__.Review());
    this.confirmation = new rxjs__WEBPACK_IMPORTED_MODULE_7__.BehaviorSubject(new src_app_model_confirmation__WEBPACK_IMPORTED_MODULE_6__.Confirmation());
  }
}
ResultService.ɵfac = function ResultService_Factory(t) {
  return new (t || ResultService)();
};
ResultService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineInjectable"]({
  token: ResultService,
  factory: ResultService.ɵfac,
  providedIn: 'root'
});

/***/ }),

/***/ 1109:
/*!***********************************************************!*\
  !*** ./src/app/services/validation/validation.service.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ValidationService: () => (/* binding */ ValidationService)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 1699);

class ValidationService {
  constructor() {
    this.approvedChars = /^[A-Za-z0-9\u0020\u00E0\u00E2\u00E7\u00E8\u00E9\u00EA\u00EB\u00EE\u00EF\u00F4\u00F6\u00F9\u00FB\u00FC\u00C0\u00C2\u00C7\u00C8\u00C9\u00CA\u00CB\u00CE\u00CF\u00D4\u00D6\u00D9\u00DB\u00DC\u0026\u002D\u00B0\u005E\u007B\u007D\u005C\u002F\u007E\u00A3\u00F7\u00A5\u00BC\u00BD\u0060\u00BE\u00A2\u0021\u003A\u00AB\u005B\u2014\u002E\u0024\u002C\u0023\u00BB\u005D\u002A\u0025\u0040\u00AF\u0028\u0029\u005F\u0027\u00B8\u00A8\u002B\u003B\u003D\u00B4\u007C\u003F\u0022\u00D7\u000A\u2019\u0009]+$/;
    this.disallowedCounter = 0;
  }
  noSpecialCharsStrictValidator() {
    return control => {
      if (control?.value) {
        const valid = control.value.match('^[A-Za-z\\d\\u0020\\u00E0\\u00E2\\u00E7\\u00E8\\u00E9\\u00EA\\u00EB\\u00EE\\u00EF\\u00F4\\u00F6\\u00F9\\u00FB\\u00FC\\u00C0\\u00C2\\u00C7\\u00C8\\u00C9\\u00CA\\u00CB\\u00CE\\u00CF\\u00D4\\u00D6\\u00D9\\u00DB\\u00DC\\u0026\\u002D\\u00B0\\u005E\\u007B\\u007D\\u005C\\u002F\\u007E\\u00A3\\u00F7\\u00A5\\u00BC\\u00BD\\u0060\\u00BE\\u00A2\\u0021\\u003A\\u00AB\\u005B\\u2014\\u002E\\u0024\\u002C\\u0023\\u00BB\\u005D\\u002A\\u0025\\u0040\\u00AF\\u0028\\u0029\\u005F\\u0027\\u00B8\\u00A8\\u002B\\u003B\\u003D\\u00B4\\u007C\\u003F\\u0022\\u00D7]+$');
        return !valid ? {
          error_no_specialChar: {
            value: control.value
          }
        } : null;
      }
      return null;
    };
  }
  feedbackDetailValidator() {
    return control => {
      if (control?.value) {
        const valid = control.value.match(this.approvedChars);
        if (!valid) {
          const disallowedCharacters = control.value.split('').filter(char => !this.approvedChars.test(char)).join('');
          this.disallowedCounter = disallowedCharacters.length;
          return {
            error_specialChar_ctr: {
              value: control.value,
              disallowedCount: this.disallowedCounter
            }
          };
        }
      }
      ;
      return null;
    };
  }
}
ValidationService.ɵfac = function ValidationService_Factory(t) {
  return new (t || ValidationService)();
};
ValidationService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
  token: ValidationService,
  factory: ValidationService.ɵfac,
  providedIn: 'root'
});

/***/ }),

/***/ 5664:
/*!***************************************!*\
  !*** ./src/app/util/AppFormHelper.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppFormHelper: () => (/* binding */ AppFormHelper)
/* harmony export */ });
class AppFormHelper {
  constructor() {}
  static trimInputField(inputField) {
    if (inputField) {
      let inputFieldString = inputField.value;
      if (inputFieldString) {
        inputField.setValue(inputFieldString.trim());
      }
    }
  }
  static trimInputFields(inputFields) {
    if (inputFields) {
      inputFields.forEach(inputField => this.trimInputField(inputField));
    }
  }
  static convertApostropheAndTabField(inputField) {
    if (inputField) {
      let inputFieldString = inputField.value;
      if (inputFieldString) {
        inputField.setValue(inputFieldString.replace("’", "'").replace(/[\u2019]/g, "'").replace(/\\t/g, " ").replace(/[\u0009]/g, " "));
      }
    }
  }
  static convertApostropheAndTabFields(inputFields) {
    if (inputFields) {
      inputFields.forEach(inputField => this.convertApostropheAndTabField(inputField));
    }
  }
}

/***/ }),

/***/ 553:
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   environment: () => (/* binding */ environment)
/* harmony export */ });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
  production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.

/***/ }),

/***/ 4913:
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser */ 6480);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 1699);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/app.module */ 8629);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./environments/environment */ 553);




if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.production) {
  (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.enableProdMode)();
}
_angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__.platformBrowser().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_0__.AppModule).catch(err => console.error(err));

/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, ["vendor"], () => (__webpack_exec__(4913)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=main.js.map